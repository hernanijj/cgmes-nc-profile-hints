var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __export = (target, all2) => {
  for (var name in all2)
    __defProp(target, name, { get: all2[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// ../vscode/node_modules/n3/lib/IRIs.js
var require_IRIs = __commonJS({
  "../vscode/node_modules/n3/lib/IRIs.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    exports2.default = void 0;
    var RDF = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
    var XSD = "http://www.w3.org/2001/XMLSchema#";
    var SWAP = "http://www.w3.org/2000/10/swap/";
    var _default = exports2.default = {
      xsd: {
        decimal: `${XSD}decimal`,
        boolean: `${XSD}boolean`,
        dateTime: `${XSD}dateTime`,
        double: `${XSD}double`,
        integer: `${XSD}integer`,
        string: `${XSD}string`
      },
      rdf: {
        type: `${RDF}type`,
        nil: `${RDF}nil`,
        first: `${RDF}first`,
        rest: `${RDF}rest`,
        langString: `${RDF}langString`,
        dirLangString: `${RDF}dirLangString`,
        reifies: `${RDF}reifies`
      },
      owl: {
        sameAs: "http://www.w3.org/2002/07/owl#sameAs"
      },
      r: {
        forSome: `${SWAP}reify#forSome`,
        forAll: `${SWAP}reify#forAll`
      },
      log: {
        implies: `${SWAP}log#implies`,
        isImpliedBy: `${SWAP}log#isImpliedBy`
      }
    };
  }
});

// ../vscode/node_modules/n3/lib/N3Lexer.js
var require_N3Lexer = __commonJS({
  "../vscode/node_modules/n3/lib/N3Lexer.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    exports2.default = void 0;
    var _IRIs = _interopRequireDefault(require_IRIs());
    function _interopRequireDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var {
      xsd
    } = _IRIs.default;
    var SPACE = 32;
    var TAB = 9;
    var LF = 10;
    var CR = 13;
    var HASH = 35;
    var DOT = 46;
    var COLON = 58;
    var ZERO = 48;
    var NINE = 57;
    var PERCENT = 37;
    var BACKSLASH = 92;
    function isWhitespace(charCode) {
      return charCode === SPACE || charCode >= TAB && charCode <= CR || charCode >= 160 && (charCode === 160 || charCode === 5760 || charCode >= 8192 && charCode <= 8202 || charCode === 8232 || charCode === 8233 || charCode === 8239 || charCode === 8287 || charCode === 12288 || charCode === 65279);
    }
    var asciiDelimiters = new Uint8Array(128);
    for (const char of `,;!^#()[]{}"'<> 	
\v\f\r`) asciiDelimiters[char.charCodeAt(0)] = 1;
    function isDelimiter(charCode) {
      return charCode < 128 ? asciiDelimiters[charCode] === 1 : isWhitespace(charCode);
    }
    function canEndName(input, pos, inputFinished) {
      let charCode = input.charCodeAt(pos);
      if (charCode === DOT) charCode = input.charCodeAt(++pos);
      if (pos >= input.length) return inputFinished;
      return isDelimiter(charCode);
    }
    var stringEscapeReplacements = {
      "\\": "\\",
      "'": "'",
      '"': '"',
      "n": "\n",
      "r": "\r",
      "t": "	",
      "f": "\f",
      "b": "\b"
    };
    var localNameEscapeReplacements = {
      "_": "_",
      "~": "~",
      ".": ".",
      "-": "-",
      "!": "!",
      "$": "$",
      "&": "&",
      "'": "'",
      "(": "(",
      ")": ")",
      "*": "*",
      "+": "+",
      ",": ",",
      ";": ";",
      "=": "=",
      "/": "/",
      "?": "?",
      "#": "#",
      "@": "@",
      "%": "%"
    };
    var illegalIriChars = /[\x00-\x20<>\\"\{\}\|\^\`]/;
    var PREFIX_START = 1;
    var LOCAL_START = 2;
    var NAME_CHAR = 4;
    var LOCAL_CHAR = 8;
    var LOCAL_ESCAPE = 16;
    var asciiNameClasses = new Uint8Array(128);
    for (let charCode = 0; charCode < 128; charCode++) {
      const char = String.fromCharCode(charCode);
      const letter = char >= "A" && char <= "Z" || char >= "a" && char <= "z";
      const nameChar = letter || char === "_" || char === "-" || char >= "0" && char <= "9";
      asciiNameClasses[charCode] = (letter ? PREFIX_START : 0) | (nameChar && char !== "-" || char === ":" ? LOCAL_START : 0) | (nameChar ? NAME_CHAR : 0) | (nameChar || char === ":" ? LOCAL_CHAR : 0) | (char in localNameEscapeReplacements ? LOCAL_ESCAPE : 0);
    }
    function nameCharLength(input, pos, charClass) {
      const charCode = input.charCodeAt(pos);
      if (charCode < 128) return (asciiNameClasses[charCode] & charClass) !== 0 ? 1 : 0;
      if (charCode >= 55296 && charCode <= 56191) {
        const low = input.charCodeAt(pos + 1);
        return low >= 56320 && low <= 57343 ? 2 : 0;
      }
      if (charClass >= NAME_CHAR && (charCode === 183 || charCode >= 768 && charCode <= 879 || charCode === 8255 || charCode === 8256)) return 1;
      return charCode >= 192 && charCode <= 8191 && charCode !== 215 && charCode !== 247 && (charCode < 768 || charCode >= 880 && charCode !== 894) || charCode >= 8204 && charCode <= 8205 || charCode >= 8304 && charCode <= 8591 || charCode >= 11264 && charCode <= 12271 || charCode >= 12289 && charCode <= 55295 || charCode >= 63744 && charCode <= 64975 || charCode >= 65008 && charCode <= 65533 ? 1 : 0;
    }
    function isLocalEscape(charCode) {
      return charCode < 128 && (asciiNameClasses[charCode] & LOCAL_ESCAPE) !== 0;
    }
    function isHexDigit(charCode) {
      return charCode >= ZERO && charCode <= NINE || charCode >= 65 && charCode <= 70 || charCode >= 97 && charCode <= 102;
    }
    function skipPrefix(input, pos) {
      let length = nameCharLength(input, pos, PREFIX_START);
      while (length !== 0) {
        pos += length;
        const next = input.charCodeAt(pos) === DOT ? pos + 1 : pos;
        const charCode = input.charCodeAt(next);
        length = charCode < 128 ? (asciiNameClasses[charCode] & NAME_CHAR) !== 0 ? 1 : 0 : nameCharLength(input, next, NAME_CHAR);
        if (length !== 0) pos = next;
      }
      return pos;
    }
    function skipLocalName(input, pos) {
      let end = pos, charClass = LOCAL_START;
      while (true) {
        const charCode = input.charCodeAt(pos);
        let length = charCode < 128 ? (asciiNameClasses[charCode] & charClass) !== 0 ? 1 : 0 : nameCharLength(input, pos, charClass);
        if (length === 0 && charCode === PERCENT && isHexDigit(input.charCodeAt(pos + 1)) && isHexDigit(input.charCodeAt(pos + 2))) length = 3;
        else if (length === 0 && charCode === BACKSLASH && isLocalEscape(input.charCodeAt(pos + 1))) length = 2;
        if (length !== 0) {
          end = pos += length;
          charClass = LOCAL_CHAR;
        } else if (charCode === DOT && charClass === LOCAL_CHAR) pos++;
        else return end;
      }
    }
    function skipPrefixedName(input, pos, inputFinished) {
      const colon = skipPrefix(input, pos);
      if (input.charCodeAt(colon) !== COLON) return -1;
      const end = skipLocalName(input, colon + 1);
      return canEndName(input, end, inputFinished) ? end : -1;
    }
    function isValidCodePoint(charCode) {
      return charCode <= 1114111 && (charCode < 55296 || charCode > 57343);
    }
    var lineModeRegExps = {
      _iri: true,
      _unescapedIri: true,
      _simpleQuotedString: true,
      _langcode: true,
      _blank: true,
      _commentLine: true,
      _whitespace: true
    };
    var invalidRegExp = /$0^/;
    var nonWhitespace = /\S*/y;
    function execAt(regExp, input, pos) {
      regExp.lastIndex = pos;
      return regExp.exec(input);
    }
    function testAt(regExp, input, pos) {
      regExp.lastIndex = pos;
      return regExp.test(input);
    }
    function execAtEnd(regExp, input, pos) {
      regExp.lastIndex = 0;
      return regExp.exec(`${input.slice(pos)} `);
    }
    function isSeparatorCode(code) {
      return code === SPACE || code === TAB || code === LF || code === CR || code === HASH;
    }
    var reservedWords = /^(?:prefix|base|version|graph|forsome|forall|iri|a|true|false|has|is|of|id)$/i;
    var MIN_RESCAN_LENGTH = 1024;
    var N3Lexer = class {
      constructor(options) {
        this._iri = /<((?:[^ <>{}\\]|\\[uU])+)>[ \t]*/y;
        this._unescapedIri = /<([^\x00-\x20<>\\"\{\}\|\^\`]*)>[ \t]*/y;
        this._simpleQuotedString = /"([^"\\\r\n]*)"(?=[^"])/y;
        this._simpleApostropheString = /'([^'\\\r\n]*)'(?=[^'])/y;
        this._langcode = /@([a-z]+(?:-[a-z0-9]+)*)(?=[^a-z0-9])/iy;
        this._variable = /\?(?:(?:[A-Z_a-z\xc0-\xd6\xd8-\xf6\xf8-\u02ff\u0370-\u037d\u037f-\u1fff\u200c\u200d\u2070-\u218f\u2c00-\u2fef\u3001-\ud7ff\uf900-\ufdcf\ufdf0-\ufffd]|[\ud800-\udb7f][\udc00-\udfff])(?:[\-0-9:A-Z_a-z\xb7\xc0-\xd6\xd8-\xf6\xf8-\u037d\u037f-\u1fff\u200c\u200d\u203f\u2040\u2070-\u218f\u2c00-\u2fef\u3001-\ud7ff\uf900-\ufdcf\ufdf0-\ufffd]|[\ud800-\udb7f][\udc00-\udfff])*)(?=[.,;!\^\s#()\[\]\{\}"'<>])/y;
        this._blank = /_:((?:[0-9A-Z_a-z\xc0-\xd6\xd8-\xf6\xf8-\u02ff\u0370-\u037d\u037f-\u1fff\u200c\u200d\u2070-\u218f\u2c00-\u2fef\u3001-\ud7ff\uf900-\ufdcf\ufdf0-\ufffd]|[\ud800-\udb7f][\udc00-\udfff])(?:\.?[\-0-9A-Z_a-z\xb7\xc0-\xd6\xd8-\xf6\xf8-\u037d\u037f-\u1fff\u200c\u200d\u203f\u2040\u2070-\u218f\u2c00-\u2fef\u3001-\ud7ff\uf900-\ufdcf\ufdf0-\ufffd]|[\ud800-\udb7f][\udc00-\udfff])*)(?:[ \t]+|(?=\.?[,;:!\^\s#()\[\]\{\}"'<>]))/y;
        this._number = /[\-+]?(?:(\d+\.\d*|\.?\d+)[eE][\-+]?\d+|(?=\.?\d)\d*(?:(\.)\d+)?)(?=\.?[,;:!\^\s#()\[\]\{\}"'<>])/y;
        this._boolean = /(?:true|false)(?=[.,;!\^\s#()\[\]\{\}"'<>])/y;
        this._atKeyword = /@[a-z]+(?=[\s#<:"'.])/iy;
        this._keyword = /(?:PREFIX|BASE|VERSION|GRAPH)(?=[\s#<"'])/iy;
        this._n3Verb = /(?:has|is|of)(?=[\s#()\[\]\{\}"'<>?_+\-0-9])/y;
        this._n3Id = /id(?=[\s#<])/y;
        this._shortPredicates = /a(?=[\s#()\[\]\{\}"'<>])/y;
        this._commentLine = /[ \t]*#([^\n\r]*)(?:\r\n|\n|\r)([ \t]*)/y;
        this._whitespace = /[ \t]+/y;
        options = options || {};
        this._isImpliedBy = options.isImpliedBy;
        if (this._lineMode = !!options.lineMode) {
          this._n3Mode = false;
          for (const key in this) {
            if (!(key in lineModeRegExps) && this[key] instanceof RegExp) this[key] = invalidRegExp;
          }
          this._keyword = /VERSION(?=[\s#<"])/y;
        } else {
          this._n3Mode = options.n3 !== false;
        }
        this._directive = null;
        if (options.directives && options.directives.length !== 0) {
          for (const name of options.directives) {
            if (!/^[a-z]+$/i.test(name) || reservedWords.test(name)) throw new Error(`Invalid directive name: "${name}"`);
          }
          this._directive = new RegExp(`(?:${options.directives.join("|")})(?=[\\s#<])`, "iy");
          this._directiveMaxLength = Math.max(...options.directives.map((name) => name.length));
          this._directiveStarts = options.directives.map((name) => name[0].toLowerCase() + name[0].toUpperCase()).join("");
        }
        this.comments = !!options.comments;
        this._literalClosingPos = 0;
      }
      // ## Private methods
      // ### `_tokenizeToEnd` tokenizes as for as possible, emitting tokens through the callback
      _tokenizeToEnd(callback, inputFinished) {
        const input = this._input;
        let pos = 0;
        let currentLineLength = this._linePosition + input.length;
        while (true) {
          while (true) {
            let charCode = input.charCodeAt(pos), separatorLength = 0;
            if (charCode === SPACE || charCode === TAB) {
              const next = input.charCodeAt(pos + 1);
              separatorLength = next === SPACE || next === TAB ? execAt(this._whitespace, input, pos)[0].length : 1;
              charCode = input.charCodeAt(pos + separatorLength);
            }
            if (charCode === HASH) {
              const comment = execAt(this._commentLine, input, pos);
              if (comment) {
                const commentLength = comment[0].length;
                if (!inputFinished && pos + commentLength === input.length && input.charCodeAt(input.length - 1) === CR) return this._suspend(input, pos, currentLineLength);
                if (this.comments) emitComment(comment[1], this._line, currentLineLength - (input.length - pos) + separatorLength);
                pos += commentLength;
                currentLineLength = input.length - pos + comment[2].length;
                this._line++;
              } else {
                pos += separatorLength;
                if (!inputFinished) return this._suspend(input, pos, currentLineLength);
                if (this.comments) emitComment(input.slice(pos + 1), this._line, currentLineLength - (input.length - pos));
                pos = input.length;
                break;
              }
            } else if (charCode === LF || charCode === CR) {
              if (!inputFinished && charCode === CR && pos + separatorLength + 1 === input.length) return this._suspend(input, pos, currentLineLength);
              separatorLength += charCode === CR && input.charCodeAt(pos + separatorLength + 1) === LF ? 2 : 1;
              let indentationLength = 0;
              const next = input.charCodeAt(pos + separatorLength);
              if (next === SPACE || next === TAB) {
                const following = input.charCodeAt(pos + separatorLength + 1);
                indentationLength = following === SPACE || following === TAB ? execAt(this._whitespace, input, pos + separatorLength)[0].length : 1;
              }
              pos += separatorLength + indentationLength;
              currentLineLength = input.length - pos + indentationLength;
              this._line++;
            } else {
              pos += separatorLength;
              break;
            }
          }
          if (pos >= input.length) {
            if (inputFinished && this._previousMarker === "^^") return reportSyntaxError(this, input, pos);
            this._linePosition = currentLineLength;
            if (inputFinished) {
              emitToken("eof", "", "", this._line, currentLineLength, 0);
              return this._input = null;
            }
            return this._input = "";
          }
          const line = this._line, firstChar = input[pos];
          let type = "", value = "", prefix = "", match = null, matchLength = 0, lexicalLength = 0, finalLineLength = 0, inconclusive = false, tripleQuoted = false;
          switch (firstChar) {
            case "^":
              if (this._previousMarker === "^^") return reportSyntaxError(this, input, pos);
              if (input.length - pos < 3) break;
              else if (input[pos + 1] === "^") {
                this._previousMarker = "^^";
                pos += 2;
                if (input[pos] !== "<") {
                  if (isSeparatorCode(input.charCodeAt(pos))) continue;
                  inconclusive = true;
                  break;
                }
              } else {
                if (this._n3Mode) {
                  matchLength = 1;
                  type = "^";
                }
                break;
              }
            // Fall through in case the type is an IRI
            case "<":
              if (match = execAt(this._unescapedIri, input, pos)) {
                type = "IRI", value = match[1];
                lexicalLength = match[1].length + 2;
              } else if (match = execAt(this._iri, input, pos)) {
                value = this._unescape(match[1], stringEscapeReplacements);
                if (value === null || illegalIriChars.test(value)) return reportSyntaxError(this, input, pos);
                type = "IRI";
                lexicalLength = match[1].length + 2;
              } else if (input.length - pos > 2 && input[pos + 1] === "<" && input[pos + 2] === "(") type = "<<(", matchLength = 3;
              else if (!this._lineMode && input.length - pos > (inputFinished ? 1 : 2) && input[pos + 1] === "<") type = "<<", matchLength = 2;
              else if (this._n3Mode && input.length - pos > 1 && input[pos + 1] === "=") {
                matchLength = 2;
                if (this._isImpliedBy) type = "abbreviation", value = "<";
                else type = "inverse", value = ">";
              } else if (this._n3Mode && input.length - pos > 1 && input[pos + 1] === "-") type = "inversePredicate", matchLength = 2;
              break;
            case ">":
              if (input.length - pos > 1 && input[pos + 1] === ">") type = ">>", matchLength = 2;
              break;
            case "_":
              if ((match = execAt(this._blank, input, pos)) || inputFinished && (match = execAtEnd(this._blank, input, pos))) {
                type = "blank", prefix = "_", value = match[1];
                lexicalLength = match[1].length + 2;
              }
              break;
            case '"':
              if (match = execAt(this._simpleQuotedString, input, pos)) value = match[1];
              else {
                ({
                  value,
                  matchLength,
                  finalLineLength,
                  tripleQuoted
                } = this._parseLiteral(input, pos));
                if (value === null) return reportSyntaxError(this, input, pos);
              }
              if (match !== null || matchLength !== 0) {
                type = "literal";
                this._literalClosingPos = 0;
              }
              break;
            case "'":
              if (!this._lineMode) {
                if (match = execAt(this._simpleApostropheString, input, pos)) value = match[1];
                else {
                  ({
                    value,
                    matchLength,
                    finalLineLength,
                    tripleQuoted
                  } = this._parseLiteral(input, pos));
                  if (value === null) return reportSyntaxError(this, input, pos);
                }
                if (match !== null || matchLength !== 0) {
                  type = "literal";
                  this._literalClosingPos = 0;
                }
              }
              break;
            case "?":
              if (this._n3Mode && (match = execAt(this._variable, input, pos))) type = "var", value = match[0];
              break;
            case "@":
              if (this._previousMarker === "literal" && (match = execAt(this._langcode, input, pos)) && match[1] !== "version") {
                const end = pos + match[0].length;
                if (!inputFinished && input[end] === "-" && input[end + 1] !== "-") match = null;
                else type = "langcode", value = match[1];
              } else if (match = execAt(this._atKeyword, input, pos)) type = match[0];
              break;
            case ".":
              if (input.length - pos === 1 ? inputFinished : input[pos + 1] < "0" || input[pos + 1] > "9") {
                type = ".";
                matchLength = 1;
                break;
              }
            // Fall through to numerical case (could be a decimal dot)
            case "0":
            case "1":
            case "2":
            case "3":
            case "4":
            case "5":
            case "6":
            case "7":
            case "8":
            case "9":
            case "+":
            case "-":
              if (input[pos + 1] === "-") {
                if (this._previousMarker === "langcode") {
                  if (input.startsWith("--ltr", pos)) type = "dircode", value = "ltr", matchLength = 5;
                  else if (input.startsWith("--rtl", pos)) type = "dircode", value = "rtl", matchLength = 5;
                }
                break;
              }
              if (match = execAt(this._number, input, pos) || inputFinished && (match = execAtEnd(this._number, input, pos))) {
                type = "literal", value = match[0];
                prefix = typeof match[1] === "string" ? xsd.double : typeof match[2] === "string" ? xsd.decimal : xsd.integer;
              }
              break;
            case "B":
            case "b":
            case "p":
            case "P":
            case "G":
            case "g":
            case "V":
            case "v":
              if (match = execAt(this._keyword, input, pos)) type = match[0].toUpperCase();
              else inconclusive = true;
              break;
            case "f":
            case "t":
              if (testAt(this._boolean, input, pos)) type = "literal", value = firstChar === "t" ? "true" : "false", prefix = xsd.boolean, matchLength = value.length;
              else inconclusive = true;
              break;
            case "a":
              if (testAt(this._shortPredicates, input, pos)) type = "abbreviation", value = "a", matchLength = 1;
              else inconclusive = true;
              break;
            case "h":
            case "o":
              if (this._n3Mode && (match = this._matchN3Verb(input, pos, inputFinished))) type = match[0];
              else inconclusive = true;
              break;
            case "i":
              if (this._n3Mode && testAt(this._n3Id, input, pos)) type = "id", matchLength = 2;
              else if (this._n3Mode && (match = this._matchN3Verb(input, pos, inputFinished))) type = match[0];
              else inconclusive = true;
              break;
            case "=":
              if (this._n3Mode && input.length - pos > 1) {
                type = "abbreviation";
                if (input[pos + 1] !== ">") matchLength = 1, value = "=";
                else matchLength = 2, value = ">";
              }
              break;
            case "!":
              if (!this._n3Mode) break;
            case ")":
              if (!inputFinished && (input.length - pos === 1 || input.length - pos === 2 && input[pos + 1] === ">")) {
                break;
              }
              if (input.length - pos > 2 && input[pos + 1] === ">" && input[pos + 2] === ">") {
                type = ")>>", matchLength = 3;
                break;
              }
            case ",":
            case ";":
            case "[":
            case "]":
            case "(":
            case "}":
            case "~":
              if (!this._lineMode) {
                matchLength = 1;
                type = firstChar;
              }
              break;
            case "{":
              if (!this._lineMode && input.length - pos >= 2) {
                if (input[pos + 1] === "|") type = "{|", matchLength = 2;
                else type = firstChar, matchLength = 1;
              }
              break;
            case "|":
              if (input.length - pos >= 2 && input[pos + 1] === "}") type = "|}", matchLength = 2;
              break;
            default:
              inconclusive = true;
          }
          if (inconclusive) {
            let end;
            if ((this._previousMarker === "@prefix" || this._previousMarker === "PREFIX") && input.charCodeAt(end = skipPrefix(input, pos)) === COLON && end + 1 < input.length && (input[end + 1] === "#" || input[end + 1] === "<" || isWhitespace(input.charCodeAt(end + 1)))) {
              type = "prefix", value = input.slice(pos, end);
              matchLength = end + 1 - pos;
            } else if (this._directive !== null && this._directiveStarts.includes(firstChar) && ((match = execAt(this._directive, input, pos)) || inputFinished && input.length - pos <= this._directiveMaxLength && (match = execAtEnd(this._directive, input, pos)))) type = match[0].toUpperCase();
            else if (!this._lineMode && (end = skipPrefixedName(input, pos, inputFinished)) >= 0) {
              const colon = input.indexOf(":", pos);
              type = "prefixed", prefix = input.slice(pos, colon);
              value = this._unescape(input.slice(colon + 1, end), localNameEscapeReplacements);
              matchLength = end - pos;
            }
          }
          if (this._previousMarker === "^^") {
            switch (type) {
              case "prefixed":
                type = "type";
                break;
              case "IRI":
                type = "typeIRI";
                break;
              default:
                type = "";
            }
          }
          if (!type) {
            if (inputFinished || !input.startsWith("'''", pos) && !input.startsWith('"""', pos) && /\n|\r/.test(input.slice(pos))) return reportSyntaxError(this, input, pos);
            else return this._suspend(input, pos, currentLineLength);
          }
          const length = matchLength || match[0].length;
          const start = currentLineLength - (input.length - pos);
          let token;
          if (finalLineLength) {
            token = {
              type,
              value,
              prefix,
              line,
              start,
              end: finalLineLength,
              endLine: this._line,
              tripleQuoted
            };
            callback(null, token);
          } else if (tripleQuoted) {
            token = {
              type,
              value,
              prefix,
              line,
              start,
              end: start + length,
              tripleQuoted
            };
            callback(null, token);
          } else token = emitToken(type, value, prefix, line, start, lexicalLength || length);
          this.previousToken = token;
          this._previousMarker = type === "literal" && (this._previousMarker === "VERSION" || this._previousMarker === "@version") ? "version" : type;
          pos = Math.min(pos + length, input.length);
          if (finalLineLength) currentLineLength = input.length - pos + finalLineLength;
        }
        function emitComment(value, line, start) {
          callback(null, {
            type: "comment",
            value,
            prefix: "",
            line,
            start,
            end: start + value.length + 1
          });
        }
        function emitToken(type, value, prefix, line, start, length) {
          const token = {
            type,
            value,
            prefix,
            line,
            start,
            end: start + length
          };
          callback(null, token);
          return token;
        }
        function reportSyntaxError(self, input2, pos2) {
          callback(self._syntaxError(execAt(nonWhitespace, input2, pos2)[0]));
        }
      }
      // ### `_suspend` keeps the unconsumed input until more input arrives
      _suspend(input, pos, currentLineLength) {
        this._linePosition = currentLineLength - (input.length - pos);
        return this._input = input.slice(pos);
      }
      // ### `_matchN3Verb` matches an N3 verb unless the input is a longer prefixed name
      _matchN3Verb(input, pos, inputFinished) {
        const verb = execAt(this._n3Verb, input, pos);
        if (!verb) return null;
        const next = input[pos + verb[0].length];
        if (next !== "-" && next !== "_" && (next < "0" || next > "9") && next !== "\u1680" && next !== "\uFEFF") return verb;
        if (skipPrefixedName(input, pos, true) >= 0) return null;
        if (!inputFinished && skipPrefix(input, pos) === input.length) return null;
        return verb;
      }
      // ### `_unescape` replaces N3 escape codes by their corresponding characters,
      // allowing only the fixed escape sequences from the given replacement table
      _unescape(item, replacements) {
        let backslash = item.indexOf("\\");
        if (backslash < 0) return item;
        let result = "", start = 0;
        while (backslash >= 0 && backslash + 1 < item.length) {
          const escapedChar = item[backslash + 1];
          let end = backslash + 2, replacement;
          if (escapedChar === "u" || escapedChar === "U") {
            end += escapedChar === "u" ? 4 : 8;
            if (end > item.length) return null;
            let charCode = 0;
            for (let i = backslash + 2; i < end; i++) {
              let digit = item.charCodeAt(i);
              if (digit >= 48 && digit <= 57)
                digit -= 48;
              else if (digit >= 65 && digit <= 70)
                digit -= 65 - 10;
              else if (digit >= 97 && digit <= 102)
                digit -= 97 - 10;
              else return null;
              charCode = charCode * 16 + digit;
            }
            if (!isValidCodePoint(charCode)) return null;
            replacement = String.fromCodePoint(charCode);
          } else {
            if (!(escapedChar in replacements)) return null;
            replacement = replacements[escapedChar];
          }
          result += item.slice(start, backslash) + replacement;
          start = end;
          backslash = item.indexOf("\\", start);
        }
        return result + item.slice(start);
      }
      // ### `_parseLiteral` parses a literal at the given position into an unescaped value
      _parseLiteral(input, pos) {
        if (input.length - pos >= 3) {
          const quote = input[pos];
          const openingLength = input[pos + 1] === quote && input[pos + 2] === quote ? 3 : 1;
          let opening = quote;
          if (openingLength === 3) opening = quote === '"' ? '"""' : "'''";
          let closingPos = pos + Math.max(this._literalClosingPos, openingLength);
          while ((closingPos = input.indexOf(opening, closingPos)) > pos) {
            let backslashCount = 0;
            while (input[closingPos - backslashCount - 1] === "\\") backslashCount++;
            if (backslashCount % 2 === 0) {
              const raw = input.substring(pos + openingLength, closingPos), lines = raw.split(/\r\n|\r|\n/), lineCount = lines.length - 1;
              const matchLength = closingPos - pos + openingLength;
              if (openingLength === 1 && lineCount !== 0 || openingLength === 3 && this._lineMode) break;
              this._line += lineCount;
              const finalLineLength = lineCount === 0 ? 0 : lines[lines.length - 1].length + openingLength;
              return {
                value: this._unescape(raw, stringEscapeReplacements),
                matchLength,
                finalLineLength,
                tripleQuoted: openingLength === 3
              };
            }
            closingPos++;
          }
          this._literalClosingPos = input.length - pos - openingLength + 1;
        }
        return {
          value: "",
          matchLength: 0,
          finalLineLength: 0,
          tripleQuoted: false
        };
      }
      // ### `_tryTokenizeToEnd` tokenizes as far as possible, reporting failures through the callback
      _tryTokenizeToEnd(callback, inputFinished) {
        let callbackError;
        try {
          this._tokenizeToEnd((error, token) => {
            try {
              return callback(error, token);
            } catch (thrown) {
              throw callbackError = thrown;
            }
          }, inputFinished);
        } catch (error) {
          if (error === callbackError || !(error instanceof RangeError)) throw error;
          callback(this._syntaxError(null, `Token too long on line ${this._line}.`));
        }
      }
      // ### `_syntaxError` creates a syntax error for the given issue
      _syntaxError(issue, message = `Unexpected "${issue}" on line ${this._line}.`) {
        this._input = null;
        const err = new Error(message);
        err.context = {
          token: void 0,
          line: this._line,
          previousToken: this.previousToken
        };
        return err;
      }
      // ### `_startTokenization` resets the lexer state for a new input
      _startTokenization() {
        this._line = 1;
        this._linePosition = 0;
        this._previousMarker = void 0;
        this.previousToken = void 0;
        this._literalClosingPos = 0;
        this._input = void 0;
        return this._tokenization = {};
      }
      // ### `_tokenizeString` synchronously emits the tokens of a complete string through the callback,
      // so that the caller can consume each token without the lexer collecting them all first
      _tokenizeString(input, callback) {
        this._startTokenization();
        this._input = this._readStartingBom(input);
        this._tryTokenizeToEnd(callback, true);
      }
      // ### Strips off any starting UTF BOM mark.
      _readStartingBom(input) {
        if (input.startsWith("\uFEFF")) {
          this._linePosition = 1;
          return input.slice(1);
        }
        return input;
      }
      // ## Public methods
      // ### `tokenize` starts the transformation of an N3 document into an array of tokens.
      // The input can be a string or a stream.
      // Token ranges use one-based lines and zero-based, end-exclusive UTF-16 columns.
      // Separator whitespace counts towards the next token's start, outside either range.
      // Multiline tokens also have endLine; their end column is relative to that line.
      tokenize(input, callback) {
        const tokenization = this._startTokenization();
        if (typeof input === "string") {
          this._input = this._readStartingBom(input);
          if (typeof callback === "function") queueMicrotask(() => {
            if (this._tokenization === tokenization) this._tryTokenizeToEnd(callback, true);
          });
          else {
            const tokens = [];
            let error;
            this._tryTokenizeToEnd((e, t) => e ? error = e : tokens.push(t), true);
            if (error) throw error;
            return tokens;
          }
        } else {
          let decoder, retryLength = 0;
          if (typeof input.setEncoding === "function") input.setEncoding("utf8");
          input.on("data", (data) => {
            if (this._tokenization === tokenization && this._input !== null && data.length !== 0) {
              if (typeof data !== "string") {
                decoder = decoder || new TextDecoder("utf-8", {
                  ignoreBOM: true
                });
                if (!(data = decoder.decode(data, {
                  stream: true
                }))) return;
              }
              if (typeof this._input === "undefined") this._input = this._readStartingBom(data);
              else this._input += data;
              if (this._input.length >= retryLength) {
                this._tryTokenizeToEnd(callback, false);
                retryLength = this._input !== null && this._input.length > MIN_RESCAN_LENGTH ? 2 * this._input.length : 0;
              }
            }
          });
          input.on("end", () => {
            if (this._tokenization === tokenization && this._input !== null) {
              const rest = decoder ? decoder.decode() : "";
              if (rest) this._input = typeof this._input === "string" ? this._input + rest : rest;
              if (typeof this._input === "string") this._tryTokenizeToEnd(callback, true);
            }
          });
          input.on("error", (error) => {
            if (this._tokenization === tokenization) callback(error);
          });
        }
      }
    };
    exports2.default = N3Lexer;
  }
});

// ../vscode/node_modules/n3/lib/N3DataFactory.js
var require_N3DataFactory = __commonJS({
  "../vscode/node_modules/n3/lib/N3DataFactory.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    exports2.default = exports2.Variable = exports2.Triple = exports2.Term = exports2.Quad = exports2.NamedNode = exports2.Literal = exports2.DefaultGraph = exports2.BlankNode = void 0;
    exports2.escapeQuotes = escapeQuotes;
    exports2.fromQuad = fromQuad;
    exports2.fromTerm = fromTerm;
    exports2.termFromId = termFromId;
    exports2.termToId = termToId;
    exports2.unescapeQuotes = unescapeQuotes;
    var _IRIs = _interopRequireDefault(require_IRIs());
    function _interopRequireDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var {
      rdf,
      xsd
    } = _IRIs.default;
    var DEFAULTGRAPH;
    var _blankNodeCounter = 0;
    var EMPTY_IRI_ID = "<>";
    var escapedLiteral = /^"(.*".*)(?="[^"]*$)/;
    var DataFactory = {
      namedNode,
      blankNode,
      variable,
      literal,
      defaultGraph,
      quad,
      triple: quad,
      fromTerm,
      fromQuad
    };
    var _default = exports2.default = DataFactory;
    var Term = class _Term {
      constructor(id) {
        this.id = id;
      }
      // ### The value of this term
      get value() {
        return this.id;
      }
      // ### Returns whether this object represents the same term as the other
      equals(other) {
        if (other instanceof _Term) return this.id === other.id && this.termType === other.termType;
        return !!other && this.termType === other.termType && this.value === other.value;
      }
      // ### Implement hashCode for Immutable.js, since we implement `equals`
      // https://immutable-js.com/docs/v4.0.0/ValueObject/#hashCode()
      hashCode() {
        return 0;
      }
      // ### Returns a plain object representation of this term
      toJSON() {
        return {
          termType: this.termType,
          value: this.value
        };
      }
    };
    exports2.Term = Term;
    var NamedNode = class extends Term {
      // ### Creates a named node
      /**
       * @deprecated Create named nodes through a data factory instead
       * (`DataFactory.namedNode(iri)`), so that term validation can be applied;
       * the constructor assumes an already-validated IRI.
       */
      constructor(iri) {
        if (iri !== "") super(iri);
        else {
          super(EMPTY_IRI_ID);
          Object.defineProperty(this, "value", {
            value: ""
          });
        }
      }
      // ### The term type of this term
      get termType() {
        return "NamedNode";
      }
    };
    exports2.NamedNode = NamedNode;
    var Literal = class _Literal extends Term {
      // ### Creates a literal
      /**
       * @deprecated Create literals through a data factory instead
       * (`DataFactory.literal(value, languageOrDatatype)`), so that term
       * validation can be applied; the constructor takes the internal
       * id representation and assumes it is already valid.
       */
      constructor(id) {
        super(id);
      }
      // ### The term type of this term
      get termType() {
        return "Literal";
      }
      // ### The text value of this literal
      get value() {
        return this.id.substring(1, this.id.lastIndexOf('"'));
      }
      // ### The language of this literal
      get language() {
        const id = this.id;
        let atPos = id.lastIndexOf('"') + 1;
        const dirPos = id.lastIndexOf("--");
        return atPos < id.length && id[atPos++] === "@" ? (dirPos > atPos ? id.substr(0, dirPos) : id).substr(atPos).toLowerCase() : "";
      }
      // ### The direction of this literal
      get direction() {
        const id = this.id;
        const endPos = id.lastIndexOf('"');
        const dirPos = id[endPos + 1] === "@" ? id.lastIndexOf("--") : -1;
        return dirPos > endPos && dirPos + 2 < id.length ? id.substr(dirPos + 2).toLowerCase() : "";
      }
      // ### The datatype IRI of this literal
      get datatype() {
        return new NamedNode(this.datatypeString);
      }
      // ### The datatype string of this literal
      get datatypeString() {
        const id = this.id, dtPos = id.lastIndexOf('"') + 1;
        const char = dtPos < id.length ? id[dtPos] : "";
        return char === "^" ? id.substr(dtPos + 2) : (
          // If "@" follows, return rdf:langString or rdf:dirLangString; xsd:string otherwise
          char !== "@" ? xsd.string : id.indexOf("--", dtPos) > 0 ? rdf.dirLangString : rdf.langString
        );
      }
      // ### Returns whether this object represents the same term as the other
      equals(other) {
        if (other instanceof _Literal) return this.id === other.id;
        return !!other && !!other.datatype && this.termType === other.termType && this.value === other.value && this.language === other.language && (this.direction === other.direction || this.direction === "" && !other.direction) && this.datatype.value === other.datatype.value;
      }
      toJSON() {
        return {
          termType: this.termType,
          value: this.value,
          language: this.language,
          direction: this.direction,
          datatype: {
            termType: "NamedNode",
            value: this.datatypeString
          }
        };
      }
    };
    exports2.Literal = Literal;
    var BlankNode = class extends Term {
      // ### Creates a blank node
      /**
       * @deprecated Create blank nodes through a data factory instead
       * (`DataFactory.blankNode(name)`), so that term validation can be applied;
       * the constructor assumes an already-validated name.
       */
      constructor(name) {
        super(`_:${name}`);
      }
      // ### The term type of this term
      get termType() {
        return "BlankNode";
      }
      // ### The name of this blank node
      get value() {
        return this.id.substr(2);
      }
    };
    exports2.BlankNode = BlankNode;
    var Variable = class extends Term {
      // ### Creates a variable
      /**
       * @deprecated Create variables through a data factory instead
       * (`DataFactory.variable(name)`), so that term validation can be applied;
       * the constructor assumes an already-validated name.
       */
      constructor(name) {
        super(`?${name}`);
      }
      // ### The term type of this term
      get termType() {
        return "Variable";
      }
      // ### The name of this variable
      get value() {
        return this.id.substr(1);
      }
    };
    exports2.Variable = Variable;
    var DefaultGraph = class extends Term {
      // ### Creates the default graph
      /**
       * @deprecated Obtain the default graph through a data factory instead
       * (`DataFactory.defaultGraph()`).
       */
      constructor() {
        super("");
        return DEFAULTGRAPH || this;
      }
      // ### The term type of this term
      get termType() {
        return "DefaultGraph";
      }
      // ### Returns whether this object represents the same term as the other
      equals(other) {
        return this === other || !!other && this.termType === other.termType;
      }
    };
    exports2.DefaultGraph = DefaultGraph;
    DEFAULTGRAPH = new DefaultGraph();
    function termFromId(id, factory, nested) {
      factory = factory || DataFactory;
      if (!id) return factory.defaultGraph();
      switch (id[0]) {
        case "?":
          return factory.variable(id.substr(1));
        case "_":
          return factory.blankNode(id.substr(2));
        case '"':
          if (factory === DataFactory) return new Literal(id);
          if (id[id.length - 1] === '"') return factory.literal(id.substr(1, id.length - 2));
          const endPos = id.lastIndexOf('"', id.length - 1);
          let languageOrDatatype;
          if (id[endPos + 1] === "@") {
            languageOrDatatype = id.substr(endPos + 2);
            const dashDashIndex = languageOrDatatype.lastIndexOf("--");
            if (dashDashIndex > 0 && dashDashIndex < languageOrDatatype.length) {
              languageOrDatatype = {
                language: languageOrDatatype.substr(0, dashDashIndex),
                direction: languageOrDatatype.substr(dashDashIndex + 2)
              };
            }
          } else {
            languageOrDatatype = factory.namedNode(id.substr(endPos + 3));
          }
          return factory.literal(id.substr(1, endPos - 1), languageOrDatatype);
        case "[":
          id = JSON.parse(id);
          break;
        case "<":
          if (id === EMPTY_IRI_ID) return factory.namedNode("");
        // falls through
        default:
          if (!nested || !Array.isArray(id)) {
            return factory.namedNode(id);
          }
      }
      return factory.quad(termFromId(id[0], factory, true), termFromId(id[1], factory, true), termFromId(id[2], factory, true), id[3] && termFromId(id[3], factory, true));
    }
    function termToId(term, nested) {
      if (typeof term === "string") return term;
      if (term instanceof Term && term.termType !== "Quad") return term.id;
      if (!term) return DEFAULTGRAPH.id;
      switch (term.termType) {
        case "NamedNode": {
          const iri = term.value;
          return iri !== "" ? iri : EMPTY_IRI_ID;
        }
        case "BlankNode":
          return `_:${term.value}`;
        case "Variable":
          return `?${term.value}`;
        case "DefaultGraph":
          return "";
        case "Literal":
          return `"${term.value}"${term.language ? `@${term.language}${term.direction ? `--${term.direction}` : ""}` : term.datatype && term.datatype.value !== xsd.string ? `^^${term.datatype.value}` : ""}`;
        case "Quad":
          const res2 = [termToId(term.subject, true), termToId(term.predicate, true), termToId(term.object, true)];
          if (term.graph && term.graph.termType !== "DefaultGraph") {
            res2.push(termToId(term.graph, true));
          }
          return nested ? res2 : JSON.stringify(res2);
        default:
          throw new Error(`Unexpected termType: ${term.termType}`);
      }
    }
    var Quad2 = class extends Term {
      // ### Creates a quad
      /**
       * @deprecated Create quads through a data factory instead
       * (`DataFactory.quad(subject, predicate, object, graph)`), so that term
       * validation can be applied; the constructor assumes already-validated terms.
       */
      constructor(subject, predicate, object, graph) {
        super("");
        this._subject = subject;
        this._predicate = predicate;
        this._object = object;
        this._graph = graph || DEFAULTGRAPH;
      }
      // ### The term type of this term
      get termType() {
        return "Quad";
      }
      get subject() {
        return this._subject;
      }
      get predicate() {
        return this._predicate;
      }
      get object() {
        return this._object;
      }
      get graph() {
        return this._graph;
      }
      // ### Returns a plain object representation of this quad
      toJSON() {
        return {
          termType: this.termType,
          subject: this._subject.toJSON(),
          predicate: this._predicate.toJSON(),
          object: this._object.toJSON(),
          graph: this._graph.toJSON()
        };
      }
      // ### Returns whether this object represents the same quad as the other
      equals(other) {
        return !!other && this._subject.equals(other.subject) && this._predicate.equals(other.predicate) && this._object.equals(other.object) && this._graph.equals(other.graph);
      }
    };
    exports2.Triple = exports2.Quad = Quad2;
    function escapeQuotes(id) {
      return id.replace(escapedLiteral, (_, quoted) => `"${quoted.replace(/"/g, '""')}`);
    }
    function unescapeQuotes(id) {
      return id.replace(escapedLiteral, (_, quoted) => `"${quoted.replace(/""/g, '"')}`);
    }
    function namedNode(iri) {
      return new NamedNode(iri);
    }
    function blankNode(name) {
      return new BlankNode(name || `n3-${_blankNodeCounter++}`);
    }
    function literal(value, languageOrDataType) {
      if (typeof languageOrDataType === "string") return new Literal(`"${value}"@${languageOrDataType.toLowerCase()}`);
      if (languageOrDataType !== void 0 && !("termType" in languageOrDataType)) {
        return new Literal(`"${value}"@${languageOrDataType.language.toLowerCase()}${languageOrDataType.direction ? `--${languageOrDataType.direction.toLowerCase()}` : ""}`);
      }
      let datatype = languageOrDataType ? languageOrDataType.value : "";
      if (datatype === "") {
        if (typeof value === "boolean") datatype = xsd.boolean;
        else if (typeof value === "number") {
          if (Number.isFinite(value))
            datatype = Number.isInteger(value) && Math.abs(value) < 1e21 ? xsd.integer : xsd.double;
          else {
            datatype = xsd.double;
            if (!Number.isNaN(value)) value = value > 0 ? "INF" : "-INF";
          }
        } else if (typeof value === "bigint") datatype = xsd.integer;
        else if (value instanceof Date && !Number.isNaN(value.getTime())) {
          datatype = xsd.dateTime;
          value = value.toISOString();
        }
      }
      return datatype === "" || datatype === xsd.string ? new Literal(`"${value}"`) : new Literal(`"${value}"^^${datatype}`);
    }
    function variable(name) {
      return new Variable(name);
    }
    function defaultGraph() {
      return DEFAULTGRAPH;
    }
    function quad(subject, predicate, object, graph) {
      return new Quad2(subject, predicate, object, graph);
    }
    function fromTerm(term) {
      if (term instanceof Term) return term;
      switch (term.termType) {
        case "NamedNode":
          return namedNode(term.value);
        case "BlankNode":
          return blankNode(term.value);
        case "Variable":
          return variable(term.value);
        case "DefaultGraph":
          return DEFAULTGRAPH;
        case "Literal":
          return literal(term.value, !term.language ? term.datatype : term.direction ? {
            language: term.language,
            direction: term.direction
          } : term.language);
        case "Quad":
          return fromQuad(term);
        default:
          throw new Error(`Unexpected termType: ${term.termType}`);
      }
    }
    function fromQuad(inQuad) {
      if (inQuad instanceof Quad2) return inQuad;
      if (inQuad.termType !== "Quad") throw new Error(`Unexpected termType: ${inQuad.termType}`);
      return quad(fromTerm(inQuad.subject), fromTerm(inQuad.predicate), fromTerm(inQuad.object), fromTerm(inQuad.graph));
    }
  }
});

// ../vscode/node_modules/n3/lib/N3Parser.js
var require_N3Parser = __commonJS({
  "../vscode/node_modules/n3/lib/N3Parser.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    exports2.default = void 0;
    var _N3Lexer = _interopRequireDefault(require_N3Lexer());
    var _N3DataFactory = _interopRequireDefault(require_N3DataFactory());
    var _IRIs = _interopRequireDefault(require_IRIs());
    function _interopRequireDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var blankNodePrefix = 0;
    var dotSegments = /(^|\/)\.\.?($|[/#?])/;
    var pathDotSegments = /^[^?#]*(?:^|\/)\.\.?(?:$|[/#?])/;
    var N3Parser = class _N3Parser {
      constructor(options) {
        this._contextStack = [];
        this._graph = null;
        options = options || {};
        this._setBase(options.baseIRI);
        options.factory && initDataFactory(this, options.factory);
        const format = typeof options.format === "string" ? options.format.match(/(?:^|\W)(\w*)$/)[1].toLowerCase() : "", isTurtle = /turtle/.test(format), isTriG = /trig/.test(format), isNTriples = /triple/.test(format), isNQuads = /quad/.test(format), isN3 = this._n3Mode = /n3/.test(format), isLineMode = isNTriples || isNQuads;
        this._emitCurrent = this._emit;
        if (isN3) {
          this._createQuad = this._createQuadInDirection;
          this._emit = this._emitInDirection;
          this._emitCurrent = this._emitCurrentInDirection;
        }
        if (!(this._supportsNamedGraphs = !(isTurtle || isN3))) this._readPredicateOrNamedGraph = this._readPredicate;
        this._supportsQuads = !(isTurtle || isTriG || isNTriples || isN3);
        this._isImpliedBy = options.isImpliedBy;
        this._implicitEmptyPrefix = !!options.implicitEmptyPrefix;
        this._emptyFormulaAsTrue = !!options.emptyFormulaAsTrue;
        if (isLineMode) this._resolveRelativeIRI = (iri) => {
          return null;
        };
        this._blankNodePrefix = typeof options.blankNodePrefix !== "string" ? "" : options.blankNodePrefix.replace(/^(?!_:)/, "_:");
        this._directives = null;
        if (options.directives) {
          this._directives = /* @__PURE__ */ Object.create(null);
          for (const name of options.directives) this._directives[`@${name.toLowerCase()}`] = this._directives[name.toUpperCase()] = name;
        }
        this._lexer = options.lexer || new _N3Lexer.default({
          lineMode: isLineMode,
          n3: isN3,
          isImpliedBy: this._isImpliedBy,
          directives: options.directives
        });
        this._explicitQuantifiers = !!options.explicitQuantifiers;
        this._formulaScopedBlankNodes = !!options.formulaScopedBlankNodes;
        this._parseUnsupportedVersions = !!options.parseUnsupportedVersions;
        this._version = options.version;
        const maxTripleTermDepth = options.maxTripleTermDepth;
        this._maxTripleTermDepth = maxTripleTermDepth === Infinity || Number.isInteger(maxTripleTermDepth) && maxTripleTermDepth >= 0 ? maxTripleTermDepth : 1024;
      }
      // ## Static class methods
      // ### `_resetBlankNodePrefix` restarts blank node prefix identification
      static _resetBlankNodePrefix() {
        blankNodePrefix = 0;
      }
      // ## Private methods
      // ### `_setBase` sets the base IRI to resolve relative IRIs
      _setBase(baseIRI) {
        if (!baseIRI) {
          this._base = "";
          this._basePath = "";
          this._basePathHasDotSegments = false;
        } else {
          const fragmentPos = baseIRI.indexOf("#");
          if (fragmentPos >= 0) baseIRI = baseIRI.substr(0, fragmentPos);
          this._base = baseIRI;
          const queryPos = baseIRI.indexOf("?");
          const path2 = queryPos < 0 ? baseIRI : baseIRI.substr(0, queryPos);
          this._basePath = baseIRI.indexOf("/") < 0 ? baseIRI : path2.substr(0, path2.lastIndexOf("/") + 1);
          const base = baseIRI;
          baseIRI = baseIRI.match(/^(?:([a-z][a-z0-9+.-]*:))?(\/\/[^\/?#]*)?/i);
          this._baseRoot = baseIRI[0];
          this._baseScheme = baseIRI[1];
          if (baseIRI[2] !== void 0 && (base.length === this._baseRoot.length || base[this._baseRoot.length] === "?")) this._basePath = `${this._baseRoot}/`;
          this._basePathHasDotSegments = dotSegments.test(this._basePath);
        }
      }
      // ### `_enterTripleTerm` stores the current parsing context when entering a triple term,
      // failing if triple terms nest deeper than the maximum depth
      _enterTripleTerm(type, subject, predicate, token) {
        if (this._tripleTermDepth >= this._maxTripleTermDepth) {
          this._error(`Triple terms nested deeper than ${this._maxTripleTermDepth} level${this._maxTripleTermDepth === 1 ? "" : "s"}`, token);
          return false;
        }
        this._tripleTermDepth++;
        this._saveContext(type, this._graph, subject, predicate, null);
        this._graph = null;
        return true;
      }
      // ### `_saveContext` stores the current parsing context
      // when entering a new scope (list, blank node, formula)
      _saveContext(type, graph, subject, predicate, object) {
        if (!this._n3Mode) {
          this._contextStack.push({
            type,
            subject,
            predicate,
            object,
            graph
          });
          return;
        }
        const context = {
          type,
          subject,
          predicate,
          object,
          graph,
          inverse: this._inversePredicate,
          expectOf: this._expectOf,
          blankPrefix: this._prefixes._,
          prefixChanges: this._prefixChanges,
          quantifiedChanges: this._quantifiedChanges,
          emptyFormula: this._emptyFormula
        };
        if (type === "formula") {
          context.base = [this._base, this._basePath, this._baseRoot, this._baseScheme, this._basePathHasDotSegments];
          this._prefixChanges = [];
        }
        this._contextStack.push(context);
        this._inversePredicate = false;
        this._expectOf = false;
        if (!this._formulaScopedBlankNodes || type === "formula") {
          this._prefixes._ = this._graph ? `${this._graph.value}.` : ".";
          this._quantifiedChanges = [];
        }
        if (type === "formula") {
          this._subject = null;
          this._emptyFormula = true;
        }
      }
      // ### `_restoreContext` restores the parent context
      // when leaving a scope (list, blank node, formula)
      _restoreContext(type, token) {
        const context = this._contextStack.pop();
        if (!context || context.type !== type) return this._error(`Unexpected ${token.type}`, token);
        this._subject = context.subject;
        this._predicate = context.predicate;
        this._object = context.object;
        this._graph = context.graph;
        if (this._n3Mode) {
          this._inversePredicate = context.inverse;
          this._expectOf = context.expectOf;
          if (type === "formula") [this._base, this._basePath, this._baseRoot, this._baseScheme, this._basePathHasDotSegments] = context.base;
          if (this._prefixChanges !== context.prefixChanges) {
            undoChanges(this._prefixes, this._prefixChanges);
            this._prefixChanges = context.prefixChanges;
          }
          this._prefixes._ = context.blankPrefix;
          if (this._quantifiedChanges !== context.quantifiedChanges) {
            undoChanges(this._quantified, this._quantifiedChanges);
            this._quantifiedChanges = context.quantifiedChanges;
          }
          this._emptyFormula = context.emptyFormula;
        }
      }
      // ### `_readBeforeTopContext` is called once only at the start of parsing.
      _readBeforeTopContext(token) {
        if (this._version && !this._isValidVersion(this._version)) return this._error(`Detected unsupported version as media type parameter: "${this._version}"`, token);
        return this._readInTopContext(token);
      }
      // ### `_readInTopContext` reads a token when in the top context
      _readInTopContext(token) {
        switch (token.type) {
          // If an EOF token arrives in the top context, signal that we're done
          case "eof":
            if (this._graph !== null) return this._error("Unclosed graph", token);
            delete this._prefixes._;
            return this._callback(null, null, this._prefixes);
          // It could be a prefix declaration
          case "PREFIX":
            this._sparqlStyle = true;
          case "@prefix":
            return this._readPrefix;
          // It could be a base declaration
          case "BASE":
            this._sparqlStyle = true;
          case "@base":
            return this._readBaseIRI;
          // It could be a version declaration
          case "VERSION":
            this._sparqlStyle = true;
          case "@version":
            return this._readVersion;
          // It could be a graph
          case "{":
            if (this._supportsNamedGraphs) {
              this._graph = "";
              this._subject = null;
              return this._readSubject;
            }
          case "GRAPH":
            if (this._supportsNamedGraphs) return this._readNamedGraphLabel;
          // Otherwise, the next token must be a subject, unless it is an additional directive
          default:
            if (this._directives !== null && token.type in this._directives && this._graph === null) {
              this._sparqlStyle = token.type[0] !== "@";
              this._directiveCallback(this._directives[token.type]);
              return this._readDeclarationPunctuation;
            }
            return this._readSubject(token);
        }
      }
      // ### `_readInFormulaContext` reads a token at the statement level of a formula
      _readInFormulaContext(token) {
        switch (token.type) {
          case "PREFIX":
            this._sparqlStyle = true;
          case "@prefix":
            return this._readPrefix;
          case "BASE":
            this._sparqlStyle = true;
          case "@base":
            return this._readBaseIRI;
          default:
            return this._readSubject(token);
        }
      }
      // ### `_getStatementReader` returns the reader for the current statement scope
      _getStatementReader() {
        const context = this._contextStack[this._contextStack.length - 1];
        return context && context.type === "formula" ? this._readInFormulaContext : this._readInTopContext;
      }
      // ### `_readEntity` reads an IRI, prefixed name, blank node, or variable
      _readEntity(token, quantifier) {
        let value;
        switch (token.type) {
          // Read a relative or absolute IRI
          case "IRI":
          case "typeIRI":
            const iri = this._resolveIRI(token.value);
            if (iri === null) return this._error("Invalid IRI", token);
            value = this._factory.namedNode(iri);
            break;
          // Read a prefixed name
          case "type":
          case "prefixed":
            const prefix = this._prefixes[token.prefix];
            if (prefix === void 0) return this._error(`Undefined prefix "${token.prefix}:"`, token);
            value = this._factory.namedNode(prefix + token.value);
            break;
          // Read a blank node
          case "blank":
            value = this._factory.blankNode(this._prefixes[token.prefix] + token.value);
            break;
          // Read a variable
          case "var":
            value = this._factory.variable(token.value.substr(1));
            break;
          // Everything else is not an entity
          default:
            return this._error(`Expected entity but got ${token.type}`, token);
        }
        if (!quantifier && this._n3Mode && value.id in this._quantified) value = this._quantified[value.id];
        return value;
      }
      // ### `_readList` starts reading a list in the subject, predicate, or object position
      _readList(token, subject, predicate, object) {
        const stack = this._contextStack, parent = stack.length && stack[stack.length - 1];
        if (parent.type === "<<") {
          return this._error("Unexpected list in reified triple", token);
        }
        this._saveContext("list", this._graph, subject, predicate, object);
        this._subject = null;
        return this._readListItem;
      }
      // ### `_readSubject` reads a quad's subject
      _readSubject(token) {
        this._predicate = null;
        if (token.type !== "}") this._emptyFormula = false;
        switch (token.type) {
          case "[":
            this._saveContext("blank", this._graph, this._subject = this._factory.blankNode(), null, null);
            return this._readBlankNodeHead;
          case "(":
            return this._readList(token, this.RDF_NIL, null, null);
          case "{":
            if (!this._n3Mode) return this._error("Unexpected graph", token);
            this._saveContext("formula", this._graph, this._graph = this._factory.blankNode(), null, null);
            return this._readInFormulaContext;
          case "}":
            return this._readPunctuation(token);
          case "@forSome":
            if (!this._n3Mode) return this._error('Unexpected "@forSome"', token);
            this._subject = null;
            this._predicate = this.N3_FORSOME;
            this._quantifier = "blankNode";
            return this._readQuantifierList;
          case "@forAll":
            if (!this._n3Mode) return this._error('Unexpected "@forAll"', token);
            this._subject = null;
            this._predicate = this.N3_FORALL;
            this._quantifier = "variable";
            return this._readQuantifierList;
          case "literal":
            if (!this._n3Mode) return this._error("Unexpected literal", token);
            if (token.prefix.length === 0) {
              this._literalValue = token.value;
              return this._completeSubjectLiteral;
            } else {
              this._subject = this._factory.literal(token.value, this._factory.namedNode(token.prefix));
              return this._getPathReader(this._readPredicateOrNamedGraph);
            }
          case "<<(":
            if (!this._n3Mode) return this._error("Disallowed triple term as subject", token);
            return this._enterTripleTerm("<<(", null, null, token) && this._readSubject;
          case "<<":
            return this._enterTripleTerm("<<", null, null, token) && this._readSubject;
          default:
            if ((this._subject = this._readEntity(token)) === void 0) return;
            if (this._n3Mode) return this._getPathReader(this._readPredicateOrNamedGraph);
        }
        return this._readPredicateOrNamedGraph;
      }
      // ### `_readPredicate` reads a quad's predicate
      _readPredicate(token) {
        const type = token.type;
        let pathable = false;
        switch (type) {
          case "inverse":
            this._inversePredicate = true;
          case "abbreviation":
            this._predicate = this.ABBREVIATIONS[token.value];
            break;
          case "has":
            return this._readPredicateAfterVerb;
          case "is":
            this._inversePredicate = true;
            this._expectOf = true;
            return this._readPredicateAfterVerb;
          case "inversePredicate":
            this._inversePredicate = true;
            return this._readPredicateAfterVerb;
          case "|}":
            this._subject = null;
            return this._readAnnotationBlockPunctuation(token);
          case ".":
          case "]":
          case "}":
            if (this._predicate === null && !this._n3Mode) return this._error(`Unexpected ${type}`, token);
            this._subject = null;
            return type === "]" ? this._readBlankNodeTail(token) : this._readPunctuation(token);
          case ";":
            return this._predicate !== null ? this._readPredicate : this._error("Expected predicate but got ;", token);
          case "literal":
            if (!this._n3Mode) return this._error("Unexpected literal", token);
            if (token.prefix.length === 0) {
              this._literalValue = token.value;
              return this._completePredicateLiteral;
            } else this._predicate = this._factory.literal(token.value, this._factory.namedNode(token.prefix));
            pathable = true;
            break;
          case "(":
            return this._n3Mode ? this._readList(token, this._subject, this.RDF_NIL, null) : this._error(`Expected entity but got ${type}`, token);
          case "[":
            if (this._n3Mode) {
              this._saveContext("blank", this._graph, this._subject, this._subject = this._factory.blankNode(), null);
              return this._readBlankNodeHead;
            }
            return this._error("Disallowed blank node as predicate", token);
          case "{":
            if (this._n3Mode) {
              this._saveContext("formula", this._graph, this._subject, this._graph = this._factory.blankNode(), null);
              return this._readSubject;
            }
            return this._readEntity(token);
          case "blank":
            if (!this._n3Mode) return this._error("Disallowed blank node as predicate", token);
          default:
            if ((this._predicate = this._readEntity(token)) === void 0) return;
            pathable = this._n3Mode;
        }
        this._validAnnotation = true;
        return pathable ? this._getPathReader(this._readObject, "predicate") : this._readObject;
      }
      // ### `_readPredicateAfterVerb` reads the predicate following `has` or `is`
      _readPredicateAfterVerb(token) {
        if (token.type === "has" || token.type === "is" || token.type === "of" || token.type === "inversePredicate") return this._error(`Expected expression but got ${token.type}`, token);
        return this._readPredicate(token);
      }
      // ### `_readObject` reads a quad's object
      _readObject(token) {
        if (this._expectOf) {
          if (token.type !== "of") return this._error(`Expected of but got ${token.type}`, token);
          this._expectOf = false;
          return this._readObject;
        }
        switch (token.type) {
          case "literal":
            if (token.prefix.length === 0) {
              this._literalValue = token.value;
              return this._readDataTypeOrLang;
            } else {
              this._object = this._factory.literal(token.value, this._factory.namedNode(token.prefix));
              if (this._n3Mode) return this._getPathReader(this._getContextEndReader());
            }
            break;
          case "[":
            this._saveContext("blank", this._graph, this._subject, this._predicate, this._subject = this._factory.blankNode());
            return this._readBlankNodeHead;
          case "(":
            return this._readList(token, this._subject, this._predicate, this.RDF_NIL);
          case "{":
            if (!this._n3Mode) return this._error("Unexpected graph", token);
            this._saveContext("formula", this._graph, this._subject, this._predicate, this._graph = this._factory.blankNode());
            return this._readInFormulaContext;
          case "<<(":
            return this._enterTripleTerm("<<(", this._subject, this._predicate, token) && this._readSubject;
          case "<<":
            return this._enterTripleTerm("<<", this._subject, this._predicate, token) && this._readSubject;
          default:
            if ((this._object = this._readEntity(token)) === void 0) return;
            if (this._n3Mode) return this._getPathReader(this._getContextEndReader());
        }
        return this._getContextEndReader();
      }
      // ### `_readPredicateOrNamedGraph` reads a quad's predicate, or a named graph
      _readPredicateOrNamedGraph(token) {
        return token.type === "{" ? this._readGraph(token) : this._readPredicate(token);
      }
      // ### `_readGraph` reads a graph
      _readGraph(token) {
        if (token.type !== "{") return this._error(`Expected graph but got ${token.type}`, token);
        this._graph = this._subject, this._subject = null;
        return this._readSubject;
      }
      // ### `_readBlankNodeHead` reads the head of a blank node
      _readBlankNodeHead(token) {
        if (token.type === "]") {
          this._subject = null;
          return this._readBlankNodeTail(token);
        } else {
          const stack = this._contextStack, parentParent = stack.length > 1 && stack[stack.length - 2];
          if (parentParent.type === "<<") {
            return this._error("Unexpected compound blank node expression in reified triple", token);
          }
          if (token.type === "id") return this._readIriPropertyListId;
          this._predicate = null;
          return this._readPredicate(token);
        }
      }
      // ### `_readIriPropertyListId` replaces a property list's blank node with its IRI
      _readIriPropertyListId(token) {
        const iri = this._readEntity(token);
        if (iri === void 0) return;
        if (iri.termType !== "NamedNode") return this._error(`Expected IRI after id but got ${token.type}`, token);
        const placeholder2 = this._subject;
        this._subject = iri;
        const context = this._contextStack[this._contextStack.length - 1];
        if (context.subject === placeholder2) context.subject = iri;
        if (context.predicate === placeholder2) context.predicate = iri;
        if (context.object === placeholder2) context.object = iri;
        this._predicate = null;
        return this._readIriPropertyListPredicate;
      }
      // ### `_readIriPropertyListPredicate` requires properties after an IRI property list ID
      _readIriPropertyListPredicate(token) {
        if (token.type === ";" || token.type === "]" || token.type === "." || token.type === "}") return this._error(`Expected predicate but got ${token.type}`, token);
        return this._readPredicate(token);
      }
      // ### `_readBlankNodeTail` reads the end of a blank node
      _readBlankNodeTail(token) {
        if (token.type !== "]") return this._readBlankNodePunctuation(token);
        if (this._subject !== null) this._emitCurrent(this._subject, this._predicate, this._object, this._graph);
        const empty = this._predicate === null;
        this._restoreContext("blank", token);
        if (this._object !== null) return this._getContextEndReader();
        else if (this._predicate !== null) return this._getPathReader(this._readObject, "predicate");
        else
          return empty ? this._readPredicateOrNamedGraph : this._readPredicateAfterBlank;
      }
      // ### `_readPredicateAfterBlank` reads a predicate after an anonymous blank node
      _readPredicateAfterBlank(token) {
        switch (token.type) {
          case ".":
          case "}":
            this._subject = null;
            return this._readPunctuation(token);
          default:
            return this._readPredicate(token);
        }
      }
      // ### `_readListItem` reads items from a list
      _readListItem(token) {
        let item = null, list = null, next = this._readListItem;
        const previousList = this._subject, stack = this._contextStack, parent = stack[stack.length - 1];
        switch (token.type) {
          case "[":
            this._saveContext("blank", this._graph, list = this._factory.blankNode(), this.RDF_FIRST, this._subject = item = this._factory.blankNode());
            next = this._readBlankNodeHead;
            break;
          case "(":
            this._saveContext("list", this._graph, list = this._factory.blankNode(), this.RDF_FIRST, this.RDF_NIL);
            this._subject = null;
            break;
          case ")":
            this._restoreContext("list", token);
            if (stack.length !== 0 && stack[stack.length - 1].type === "list") {
              if (this._n3Mode) {
                if (previousList !== null) this._emit(previousList, this.RDF_REST, this.RDF_NIL, this._graph);
                this._saveContext("item", this._graph, this._subject, this._predicate, this._object);
                this._subject = this._object, this._predicate = null;
                return this._getPathReader(this._readListItem);
              }
              this._emit(this._subject, this._predicate, this._object, this._graph);
            }
            if (this._predicate === null) {
              next = this._n3Mode ? this._getPathReader(this._readPredicate) : this._readPredicate;
              if (this._subject === this.RDF_NIL) return next;
            } else if (this._object === null) {
              next = this._getPathReader(this._readObject, "predicate");
              if (this._predicate === this.RDF_NIL) return next;
            } else {
              next = this._getContextEndReader();
              if (this._n3Mode) next = this._getPathReader(next);
              if (this._object === this.RDF_NIL) return next;
            }
            list = this.RDF_NIL;
            break;
          case "literal":
            if (token.prefix.length === 0) {
              this._literalValue = token.value;
              next = this._readListItemDataTypeOrLang;
            } else {
              item = this._factory.literal(token.value, this._factory.namedNode(token.prefix));
              next = this._getContextEndReader();
            }
            break;
          case "{":
            if (!this._n3Mode) return this._error("Unexpected graph", token);
            list = this._factory.blankNode();
            item = this._factory.blankNode();
            if (previousList === null) {
              if (parent.predicate === null) parent.subject = list;
              else parent.object = list;
            } else {
              this._emit(previousList, this.RDF_REST, list, this._graph);
            }
            this._emit(list, this.RDF_FIRST, item, this._graph);
            this._saveContext("formula", this._graph, list, this.RDF_FIRST, this._graph = item);
            this._subject = null;
            return this._readInFormulaContext;
          case "<<(":
          case "<<":
            if (!this._enterTripleTerm(token.type, null, null, token)) return;
            next = this._readSubject;
            break;
          default:
            if ((item = this._readEntity(token)) === void 0) return;
        }
        if (list === null) this._subject = list = this._factory.blankNode();
        if (token.type === "<<" || token.type === "<<(") stack[stack.length - 1].subject = this._subject;
        if (previousList === null) {
          if (parent.predicate === null) parent.subject = list;
          else if (parent.object === null) parent.predicate = list;
          else parent.object = list;
        } else {
          this._emit(previousList, this.RDF_REST, list, this._graph);
        }
        if (item !== null) {
          if (this._n3Mode && (token.type === "IRI" || token.type === "prefixed" || token.type === "var" || token.type === "blank" || token.type === "literal")) {
            this._saveContext("item", this._graph, list, this.RDF_FIRST, item);
            this._subject = item, this._predicate = null;
            return this._getPathReader(this._readListItem);
          }
          this._emit(list, this.RDF_FIRST, item, this._graph);
        }
        return next;
      }
      // ### `_readDataTypeOrLang` reads an _optional_ datatype or language
      _readDataTypeOrLang(token) {
        return this._completeObjectLiteral(token, false);
      }
      // ### `_readListItemDataTypeOrLang` reads an _optional_ datatype or language in a list
      _readListItemDataTypeOrLang(token) {
        return this._completeObjectLiteral(token, true);
      }
      // ### `_completeLiteral` completes a literal with an optional datatype or language
      // Defers possible direction tags without allocating bound callbacks.
      _completeLiteral(token, component) {
        let literal, readCb = false;
        switch (token.type) {
          // Create a datatyped literal
          case "type":
          case "typeIRI":
            const datatype = this._readEntity(token);
            if (datatype === void 0) return;
            if (datatype.value === _IRIs.default.rdf.langString || datatype.value === _IRIs.default.rdf.dirLangString) {
              return this._error("Detected illegal (directional) languaged-tagged string with explicit datatype", token);
            }
            literal = this._factory.literal(this._literalValue, datatype);
            token = null;
            break;
          // Create a language-tagged string
          case "langcode":
            if (token.value.split("-").some((t) => t.length > 8)) return this._error("Detected language tag with subtag longer than 8 characters", token);
            literal = this._factory.literal(this._literalValue, token.value);
            this._literalLanguage = token.value;
            token = null;
            this._literalComponent = component;
            readCb = true;
            break;
          // Create a simple string literal by default
          default:
            literal = this._factory.literal(this._literalValue);
        }
        return {
          token,
          literal,
          readCb
        };
      }
      // ### `_readDirCode` reads an optional directional language tag
      _readDirCode(token) {
        const component = this._literalComponent, listItem = this._literalListItem;
        if (token.type === "dircode") {
          const term = this._factory.literal(this._literalValue, {
            language: this._literalLanguage,
            direction: token.value
          });
          if (component === "subject") this._subject = term;
          else if (component === "predicate") this._predicate = term;
          else this._object = term;
          this._literalLanguage = void 0;
          token = null;
        }
        if (component === "subject" || component === "predicate") {
          const next = component === "subject" ? this._readPredicateOrNamedGraph : this._readObject;
          const reader = this._getPathEndReader(token, next, component);
          return reader || next.call(this, token);
        }
        return this._completeObjectLiteralPost(token, listItem);
      }
      // Completes a literal in subject or predicate position
      _completeTermLiteral(token, component) {
        const completed = this._completeLiteral(token, component);
        if (!completed) return;
        let next;
        if (component === "subject") {
          this._subject = completed.literal;
          next = this._readPredicateOrNamedGraph;
        } else {
          this._predicate = completed.literal;
          this._validAnnotation = true;
          next = this._readObject;
        }
        if (completed.readCb) {
          this._literalListItem = false;
          return this._readDirCode;
        }
        const reader = this._getPathEndReader(completed.token, next, component);
        if (reader) return reader;
        return next.call(this, completed.token);
      }
      // Completes a literal in subject position
      _completeSubjectLiteral(token) {
        return this._completeTermLiteral(token, "subject");
      }
      // Completes a literal in predicate position
      _completePredicateLiteral(token) {
        return this._completeTermLiteral(token, "predicate");
      }
      // Completes a literal in object position
      _completeObjectLiteral(token, listItem) {
        const completed = this._completeLiteral(token, "object");
        if (!completed) return;
        this._object = completed.literal;
        if (completed.readCb) {
          this._literalListItem = listItem;
          return this._readDirCode;
        }
        return this._completeObjectLiteralPost(completed.token, listItem);
      }
      _completeObjectLiteralPost(token, listItem) {
        if (this._n3Mode && (token === null || token.type === "!" || token.type === "^")) {
          if (listItem) {
            this._saveContext("item", this._graph, this._subject, this.RDF_FIRST, this._object);
            this._subject = this._object, this._predicate = null;
            return this._getPathEndReader(token, this._readListItem);
          }
          return this._getPathEndReader(token, this._getContextEndReader());
        }
        if (listItem) this._emit(this._subject, this.RDF_FIRST, this._object, this._graph);
        if (token === null) return this._getContextEndReader();
        else {
          this._readCallback = this._getContextEndReader();
          return this._readCallback(token);
        }
      }
      // ### `_readFormulaTail` reads the end of a formula
      _readFormulaTail(token) {
        if (token.type !== "}") return this._readPunctuation(token);
        if (this._subject !== null) this._emitCurrent(this._subject, this._predicate, this._object, this._graph);
        const formula = this._graph, empty = this._emptyFormula;
        this._restoreContext("formula", token);
        if (empty && this._emptyFormulaAsTrue) {
          if (this._subject === formula) this._subject = this.N3_TRUE;
          else if (this._predicate === formula) this._predicate = this.N3_TRUE;
          else this._object = this.N3_TRUE;
        }
        if (this._object !== null) return this._getPathReader(this._getContextEndReader(), "object");
        if (this._predicate !== null) return this._getPathReader(this._readObject, "predicate");
        return this._getPathReader(this._readPredicate, "subject");
      }
      // ### `_readPunctuation` reads punctuation between quads or quad parts
      _readPunctuation(token) {
        let next, graph = this._graph;
        const subject = this._subject, inversePredicate = this._inversePredicate;
        switch (token.type) {
          // A closing brace ends a graph
          case "}":
            if (this._graph === null) return this._error("Unexpected graph closing", token);
            if (this._n3Mode) return this._readFormulaTail(token);
            this._graph = null;
          // A dot just ends the statement, without sharing anything with the next
          case ".":
            this._subject = null;
            this._tripleTerm = null;
            next = this._getStatementReader();
            if (inversePredicate) this._inversePredicate = false;
            break;
          // Semicolon means the subject is shared; predicate and object are different
          case ";":
            if (inversePredicate) this._inversePredicate = false;
            next = this._readPredicate;
            break;
          // Comma means both the subject and predicate are shared; the object is different
          case ",":
            next = this._readObject;
            break;
          // A reifier or annotation block annotates the triple just read
          case "~":
          case "{|":
            return this._readAnnotationStart(token);
          // An annotation block can only be closed from within one
          case "|}":
            return this._error("Unexpected annotation syntax closing", token);
          default:
            if (this._supportsQuads && this._graph === null && (graph = this._readEntity(token)) !== void 0) {
              next = this._readQuadPunctuation;
              break;
            }
            return this._error(`Expected punctuation to follow "${this._object.id}"`, token);
        }
        if (subject !== null) {
          const predicate = this._predicate, object = this._object;
          this._emit(subject, predicate, object, graph, inversePredicate);
        }
        return next;
      }
      // ### `_readBlankNodePunctuation` reads punctuation in a blank node
      _readBlankNodePunctuation(token) {
        let next, resetInversePredicate = false;
        switch (token.type) {
          // Semicolon means the subject is shared; predicate and object are different
          case ";":
            resetInversePredicate = this._inversePredicate;
            next = this._readPredicate;
            break;
          // Comma means both the subject and predicate are shared; the object is different
          case ",":
            next = this._readObject;
            break;
          // Annotation syntax applies to the quad just read, exactly as it does
          // outside of a blank node property list
          case "~":
          case "{|":
            return this._readAnnotationStart(token);
          case "|}":
            return this._error("Unexpected annotation syntax closing", token);
          default:
            return this._error(`Expected punctuation to follow "${this._object.id}"`, token);
        }
        this._emitCurrent(this._subject, this._predicate, this._object, this._graph);
        if (resetInversePredicate) this._inversePredicate = false;
        return next;
      }
      // ### `_readQuadPunctuation` reads punctuation after a quad
      _readQuadPunctuation(token) {
        if (token.type !== ".") return this._error("Expected dot to follow quad", token);
        return this._readInTopContext;
      }
      // ### `_readPrefix` reads the prefix of a prefix declaration
      _readPrefix(token) {
        if (token.type !== "prefix") return this._error("Expected prefix to follow @prefix", token);
        this._prefix = token.value;
        return this._readPrefixIRI;
      }
      // ### `_readPrefixIRI` reads the IRI of a prefix declaration
      _readPrefixIRI(token) {
        if (token.type !== "IRI") return this._error(`Expected IRI to follow prefix "${this._prefix}:"`, token);
        const prefixNode = this._readEntity(token);
        if (this._prefixChanges !== null) this._prefixChanges.push(this._prefix, this._prefixes[this._prefix]);
        this._prefixes[this._prefix] = prefixNode.value;
        this._prefixCallback(this._prefix, prefixNode);
        return this._readDeclarationPunctuation;
      }
      // ### `_readBaseIRI` reads the IRI of a base declaration
      _readBaseIRI(token) {
        const iri = token.type === "IRI" && this._resolveIRI(token.value);
        if (!iri) return this._error("Expected valid IRI to follow base declaration", token);
        this._setBase(iri);
        return this._readDeclarationPunctuation;
      }
      // ### `_isValidVersion` checks if the given version is valid for this parser to handle.
      _isValidVersion(version) {
        return this._parseUnsupportedVersions || _N3Parser.SUPPORTED_VERSIONS.includes(version);
      }
      // ### `_readVersion` reads version string declaration
      _readVersion(token) {
        if (token.type !== "literal") return this._error("Expected literal to follow version declaration", token);
        if (token.prefix !== "" || token.tripleQuoted) return this._error("Version declarations must use single quotes", token);
        this._versionCallback(token.value);
        if (!this._isValidVersion(token.value)) return this._error(`Detected unsupported version: "${token.value}"`, token);
        return this._readDeclarationPunctuation;
      }
      // ### `_readNamedGraphLabel` reads the label of a named graph
      _readNamedGraphLabel(token) {
        switch (token.type) {
          case "IRI":
          case "blank":
          case "prefixed":
            return this._readSubject(token), this._readGraph;
          case "[":
            return this._readNamedGraphBlankLabel;
          default:
            return this._error("Invalid graph label", token);
        }
      }
      // ### `_readNamedGraphLabel` reads a blank node label of a named graph
      _readNamedGraphBlankLabel(token) {
        if (token.type !== "]") return this._error("Invalid graph label", token);
        this._subject = this._factory.blankNode();
        return this._readGraph;
      }
      // ### `_readDeclarationPunctuation` reads the punctuation of a declaration
      _readDeclarationPunctuation(token) {
        if (this._sparqlStyle) {
          this._sparqlStyle = false;
          return this._getStatementReader().call(this, token);
        }
        if (token.type !== ".") return this._error("Expected declaration to end with a dot", token);
        return this._getStatementReader();
      }
      // Reads a list of quantified symbols from a @forSome or @forAll statement
      _readQuantifierList(token) {
        let entity;
        switch (token.type) {
          case "IRI":
          case "prefixed":
            if ((entity = this._readEntity(token, true)) !== void 0) break;
          default:
            return this._error(`Unexpected ${token.type}`, token);
        }
        if (!this._explicitQuantifiers) {
          if (this._quantifiedChanges !== null) this._quantifiedChanges.push(entity.id, this._quantified[entity.id]);
          this._quantified[entity.id] = this._factory[this._quantifier](this._factory.blankNode().value);
        } else {
          if (this._subject === null) this._emit(this._graph || this.DEFAULTGRAPH, this._predicate, this._subject = this._factory.blankNode(), this.QUANTIFIERS_GRAPH);
          else this._emit(this._subject, this.RDF_REST, this._subject = this._factory.blankNode(), this.QUANTIFIERS_GRAPH);
          this._emit(this._subject, this.RDF_FIRST, entity, this.QUANTIFIERS_GRAPH);
        }
        return this._readQuantifierPunctuation;
      }
      // Reads punctuation from a @forSome or @forAll statement
      _readQuantifierPunctuation(token) {
        if (token.type === ",") return this._readQuantifierList;
        else {
          if (this._explicitQuantifiers) {
            this._emit(this._subject, this.RDF_REST, this.RDF_NIL, this.QUANTIFIERS_GRAPH);
            this._subject = null;
          }
          this._readCallback = this._getContextEndReader();
          return this._readCallback(token);
        }
      }
      // ### `_getPathReader` reads a potential path and then resumes with the given function
      _getPathReader(afterPath, position) {
        this._afterPath = afterPath;
        this._pathPosition = position || (this._predicate === null ? "subject" : "object");
        return this._readPath;
      }
      // ### `_getPathEndReader` continues reading after a term that might start a path,
      // given the pending token that follows the term (or `null` if it was consumed)
      _getPathEndReader(token, afterPath, position) {
        if (token !== null && token.type !== "!" && token.type !== "^") return null;
        const reader = this._getPathReader(afterPath, position);
        return token === null ? reader : reader.call(this, token);
      }
      // ### `_readPath` reads a potential path
      _readPath(token) {
        switch (token.type) {
          // Forward path
          case "!":
            return this._readForwardPath;
          // Backward path
          case "^":
            return this._readBackwardPath;
          // Not a path; resume reading where we left off
          default:
            const afterPath = this._afterPath;
            const stack = this._contextStack, parent = stack.length && stack[stack.length - 1];
            if (parent && parent.type === "item") {
              const item = this._subject;
              this._restoreContext("item", token);
              this._emit(this._subject, this.RDF_FIRST, item, this._graph);
            }
            this._afterPath = null;
            this._pathPosition = null;
            return afterPath.call(this, token);
        }
      }
      // ### `_readForwardPath` reads a '!' path
      _readForwardPath(token) {
        let subject, predicate;
        const object = this._factory.blankNode();
        if ((predicate = this._readEntity(token)) === void 0) return;
        if (this._pathPosition === "subject") subject = this._subject, this._subject = object;
        else if (this._pathPosition === "predicate") subject = this._predicate, this._predicate = object;
        else subject = this._object, this._object = object;
        this._emit(subject, predicate, object, this._graph);
        return this._readPath;
      }
      // ### `_readBackwardPath` reads a '^' path
      _readBackwardPath(token) {
        const subject = this._factory.blankNode();
        let predicate, object;
        if ((predicate = this._readEntity(token)) === void 0) return;
        if (this._pathPosition === "subject") object = this._subject, this._subject = subject;
        else if (this._pathPosition === "predicate") object = this._predicate, this._predicate = subject;
        else object = this._object, this._object = subject;
        this._emit(subject, predicate, object, this._graph);
        return this._readPath;
      }
      // ### `_readTripleTermTail` reads the end of a triple term
      _readTripleTermTail(token) {
        if (token.type !== ")>>") return this._error(`Expected )>> but got ${token.type}`, token);
        const quad = this._createQuad(this._subject, this._predicate, this._object, this._graph, this._inversePredicate);
        this._restoreContext("<<(", token);
        this._tripleTermDepth--;
        const stack = this._contextStack, parent = stack.length && stack[stack.length - 1];
        if (parent && parent.type === "list") {
          this._emit(this._subject, this.RDF_FIRST, quad, this._graph);
          return this._getContextEndReader();
        }
        if (this._subject === null) {
          this._subject = quad;
          return this._readPredicate;
        } else {
          this._object = quad;
          return this._getContextEndReader();
        }
      }
      // ### `_readReifiedTripleTailOrReifier` reads a reifier or the end of a nested reified triple
      _readReifiedTripleTailOrReifier(token) {
        if (token.type === "~") {
          return this._readReifier;
        }
        return this._readReifiedTripleTail(token);
      }
      // ### `_readReifiedTripleTail` reads the end of a nested reified triple
      _readReifiedTripleTail(token) {
        if (token.type !== ">>") return this._error(`Expected >> but got ${token.type}`, token);
        this._tripleTerm = null;
        const reifier = this._readTripleTerm();
        this._restoreContext("<<", token);
        this._tripleTermDepth--;
        const stack = this._contextStack, parent = stack.length && stack[stack.length - 1];
        if (parent && parent.type === "list") {
          this._emit(this._subject, this.RDF_FIRST, reifier, this._graph);
          return this._getContextEndReader();
        } else if (this._subject === null) {
          this._subject = reifier;
          return this._readPredicateOrReifierTripleEnd;
        } else {
          this._object = reifier;
          return this._getContextEndReader();
        }
      }
      _readPredicateOrReifierTripleEnd(token) {
        if (token.type === ".") {
          this._subject = null;
          return this._readPunctuation(token);
        }
        return this._readPredicate(token);
      }
      // ### `_readReifier` reads the triple term identifier after a tilde when in a reifying triple.
      _readReifier(token) {
        if (token.type === ">>") return this._readReifiedTripleTail(token);
        this._reifier = this._readEntity(token);
        return this._readReifiedTripleTail;
      }
      // ### `_readAnnotationStart` reads the first reifier or annotation block after an object,
      // which completes the annotated quad
      _readAnnotationStart(token) {
        this._emitCurrent(this._subject, this._predicate, this._object, this._graph);
        this._tripleTerm = null;
        return this._readAnnotation(token);
      }
      // ### `_readAnnotation` reads what follows an annotated quad:
      // further reifiers or annotation blocks for that same quad, or punctuation
      _readAnnotation(token) {
        switch (token.type) {
          case "~":
            return this._readReifierInAnnotation;
          case "{|":
            return this._readAnnotationBlockHead(token);
        }
        this._tripleTerm = null;
        switch (token.type) {
          // The subject stays shared with the next predicate-object pair
          case ";":
            this._inversePredicate = false;
            return this._readPredicate;
          // The subject and predicate stay shared with the next object
          case ",":
            return this._readObject;
          default:
            this._subject = null;
            return this._getContextEndReader().call(this, token);
        }
      }
      // ### `_readReifierInAnnotation` reads the optional reifier after a tilde in annotation syntax
      _readReifierInAnnotation(token) {
        switch (token.type) {
          case "IRI":
          case "typeIRI":
          case "type":
          case "prefixed":
          case "blank":
          case "var":
            this._reifier = this._readEntity(token);
            return this._readAnnotationBlockOrReifier;
        }
        this._reifier = this._factory.blankNode();
        return this._readAnnotationBlockOrReifier(token);
      }
      // ### `_readAnnotationBlockOrReifier` reads what follows a reifier:
      // either an annotation block, which uses the reifier as its subject,
      // or anything else, in which case the reifier stands alone
      _readAnnotationBlockOrReifier(token) {
        if (token.type === "{|") return this._readAnnotationBlockHead(token);
        this._readTripleTerm();
        return this._readAnnotation(token);
      }
      // ### `_readAnnotationBlockHead` opens an annotation block,
      // whose predicate-object pairs describe the reifier of the annotated quad
      _readAnnotationBlockHead(token) {
        const reifier = this._readTripleTerm();
        this._saveContext("annotation", this._graph, this._subject, this._predicate, this._object);
        this._contextStack[this._contextStack.length - 1].tripleTerm = this._tripleTerm;
        this._subject = reifier;
        this._predicate = this._object = this._tripleTerm = null;
        this._inversePredicate = false;
        this._validAnnotation = false;
        return this._readPredicate;
      }
      // ### `_readAnnotationBlockPunctuation` reads punctuation inside an annotation block
      _readAnnotationBlockPunctuation(token) {
        const stack = this._contextStack;
        if (token.type === "|}") {
          if (!stack.length || stack[stack.length - 1].type !== "annotation") return this._error("Unexpected annotation syntax closing", token);
          if (!this._validAnnotation) return this._error("Annotation block can not be empty", token);
          if (this._subject !== null) this._emitCurrent(this._subject, this._predicate, this._object, this._graph);
          const {
            tripleTerm
          } = stack[stack.length - 1];
          this._restoreContext("annotation", token);
          this._tripleTerm = tripleTerm;
          return this._readAnnotation;
        }
        return this._readBlankNodePunctuation(token);
      }
      _readTripleTerm() {
        const stack = this._contextStack, parent = stack.length && stack[stack.length - 1];
        const parentGraph = parent ? parent.graph : void 0;
        const reifier = this._reifier || this._factory.blankNode();
        this._reifier = null;
        this._tripleTerm = this._tripleTerm || this._createQuad(this._subject, this._predicate, this._object, null, this._inversePredicate);
        this._emit(reifier, this.RDF_REIFIES, this._tripleTerm, parentGraph || this._graph || this.DEFAULTGRAPH);
        return reifier;
      }
      // ### `_getContextEndReader` gets the next reader function at the end of a context
      _getContextEndReader() {
        const contextStack = this._contextStack;
        if (!contextStack.length) return this._readPunctuation;
        switch (contextStack[contextStack.length - 1].type) {
          case "blank":
            return this._readBlankNodeTail;
          case "list":
            return this._readListItem;
          case "formula":
            return this._readFormulaTail;
          case "<<(":
            return this._readTripleTermTail;
          case "<<":
            return this._readReifiedTripleTailOrReifier;
          case "annotation":
            return this._readAnnotationBlockPunctuation;
        }
      }
      // ### `_createQuad` creates a quad
      _createQuad(subject, predicate, object, graph) {
        return this._factory.quad(subject, predicate, object, graph || this.DEFAULTGRAPH);
      }
      // ### `_createQuadInDirection` creates a quad in the active predicate direction
      _createQuadInDirection(subject, predicate, object, graph, inversePredicate) {
        return inversePredicate ? this._factory.quad(object, predicate, subject, graph || this.DEFAULTGRAPH) : this._factory.quad(subject, predicate, object, graph || this.DEFAULTGRAPH);
      }
      // ### `_emitInDirection` sends a quad in the active predicate direction
      _emitInDirection(subject, predicate, object, graph, inversePredicate) {
        this._callback(null, this._createQuad(subject, predicate, object, graph, inversePredicate));
      }
      // ### `_emitCurrentInDirection` sends a quad in the current predicate direction
      _emitCurrentInDirection(subject, predicate, object, graph) {
        this._callback(null, this._createQuad(subject, predicate, object, graph, this._inversePredicate));
      }
      // ### `_emit` sends a quad through the callback
      _emit(subject, predicate, object, graph) {
        this._callback(null, this._factory.quad(subject, predicate, object, graph || this.DEFAULTGRAPH));
      }
      // ### `_error` emits an error message through the callback
      _error(message, token) {
        const suffix = ` on line ${token.line}.`;
        if (message.length + suffix.length > 200) message = `${message.slice(0, 199 - suffix.length)}\u2026`;
        const err = new Error(`${message}${suffix}`);
        err.context = {
          token,
          line: token.line,
          previousToken: this._lexer.previousToken
        };
        this._callback(err);
        this._callback = noop;
      }
      // ### `_resolveIRI` resolves an IRI against the base path
      _resolveIRI(iri) {
        return /^[a-z][a-z0-9+.-]*:/i.test(iri) ? iri : this._resolveRelativeIRI(iri);
      }
      // ### `_resolveRelativeIRI` resolves an IRI against the base path,
      // assuming that a base path has been set and that the IRI is indeed relative
      _resolveRelativeIRI(iri) {
        if (!iri.length) return this._base;
        switch (iri[0]) {
          // Resolve relative fragment IRIs against the base IRI
          case "#":
            return this._base + iri;
          // Resolve relative query string IRIs by replacing the query string
          case "?": {
            const queryPos = this._base.indexOf("?");
            return (queryPos < 0 ? this._base : this._base.substr(0, queryPos)) + iri;
          }
          // Resolve root-relative IRIs at the root of the base IRI
          case "/":
            if (iri[1] !== "/") return this._baseRoot + this._removeDotSegments(iri);
            return this._baseScheme ? this._removeDotSegments(this._baseScheme + iri) : this._removeDotSegments(`:${iri}`).substr(1);
          // Resolve all other IRIs at the base IRI's path
          default:
            if (/^[^/:]*:/.test(iri)) return null;
            return this._basePathHasDotSegments || pathDotSegments.test(iri) ? this._removeDotSegments(this._basePath + iri) : this._basePath + iri;
        }
      }
      // ### `_removeDotSegments` resolves './' and '../' path segments in an IRI as per RFC3986
      _removeDotSegments(iri) {
        if (!dotSegments.test(iri)) return iri;
        const length = iri.length;
        let result = "", i = -1, pathStart = -1, segmentStart = 0, next = "/";
        while (i < length) {
          switch (next) {
            // The path starts with the first slash after the authority
            case ":":
              if (pathStart < 0) {
                if (iri[++i] === "/" && iri[++i] === "/")
                  while ((pathStart = i + 1) < length && iri[pathStart] !== "/" && iri[pathStart] !== "?" && iri[pathStart] !== "#") i = pathStart;
              }
              break;
            // Don't modify a query string or fragment
            case "?":
            case "#":
              i = length;
              break;
            // Handle '/.' or '/..' path segments
            case "/":
              if (iri[i + 1] === ".") {
                next = iri[++i + 1];
                switch (next) {
                  // Remove a '/.' segment
                  case "/":
                    result += iri.substring(segmentStart, i - 1);
                    segmentStart = i + 1;
                    break;
                  // Remove a trailing '/.' segment
                  case void 0:
                  case "?":
                  case "#":
                    return result + iri.substring(segmentStart, i) + iri.substr(i + 1);
                  // Remove a '/..' segment
                  case ".":
                    next = iri[++i + 1];
                    if (next === void 0 || next === "/" || next === "?" || next === "#") {
                      result += iri.substring(segmentStart, i - 2);
                      if ((segmentStart = result.lastIndexOf("/")) >= pathStart) result = result.substr(0, segmentStart);
                      if (next !== "/") return `${result}/${iri.substr(i + 1)}`;
                      segmentStart = i + 1;
                    }
                }
              }
          }
          next = iri[++i];
        }
        return result + iri.substring(segmentStart);
      }
      // ## Public methods
      // ### `parse` parses the N3 input and emits each parsed quad through the onQuad callback.
      parse(input, quadCallback, prefixCallback, versionCallback) {
        let onQuad, onPrefix, onComment, onVersion, onDirective, onToken, onTokenEnd;
        if (quadCallback && (quadCallback.onQuad || quadCallback.onPrefix || quadCallback.onComment || quadCallback.onVersion || quadCallback.onDirective || quadCallback.onToken || quadCallback.onTokenEnd)) {
          onQuad = quadCallback.onQuad;
          onPrefix = quadCallback.onPrefix;
          onComment = quadCallback.onComment;
          onVersion = quadCallback.onVersion;
          onDirective = quadCallback.onDirective;
          onToken = quadCallback.onToken;
          onTokenEnd = quadCallback.onTokenEnd;
        } else {
          onQuad = quadCallback;
          onPrefix = prefixCallback;
          onVersion = versionCallback;
        }
        this._readCallback = this._readBeforeTopContext;
        this._contextStack = [];
        this._graph = this._subject = this._predicate = this._object = null;
        this._tripleTerm = this._reifier = null;
        this._sparqlStyle = false;
        this._prefixes = /* @__PURE__ */ Object.create(null);
        this._prefixes._ = this._blankNodePrefix ? this._blankNodePrefix.substr(2) : `b${blankNodePrefix++}_`;
        if (this._n3Mode && this._implicitEmptyPrefix && this._base) this._prefixes[""] = this._resolveIRI("#");
        this._prefixCallback = onPrefix || noop;
        this._versionCallback = onVersion || noop;
        this._directiveCallback = onDirective || noop;
        this._inversePredicate = false;
        this._expectOf = false;
        this._quantified = /* @__PURE__ */ Object.create(null);
        this._prefixChanges = null;
        this._quantifiedChanges = null;
        this._emptyFormula = false;
        this._tripleTermDepth = 0;
        const readGrammarToken = (token) => {
          return this._readCallback = this._readCallback(token);
        };
        let readToken = readGrammarToken;
        if (onComment || this._lexer.comments) {
          this._lexer.comments = true;
          readToken = (token) => {
            if (token.type !== "comment") return readGrammarToken(token);
            if (onComment) onComment(token.value);
            return this._readCallback;
          };
        }
        if (onToken || onTokenEnd) {
          const consumeToken = readToken;
          readToken = (token) => {
            try {
              try {
                if (onToken) onToken(token);
                return consumeToken(token);
              } finally {
                if (onTokenEnd) onTokenEnd(token);
              }
            } catch (error) {
              this._readCallback = null;
              throw error;
            }
          };
        }
        if (!onQuad) {
          const quads = [];
          let error;
          this._callback = (e, t) => {
            e ? error = e : t && quads.push(t);
          };
          const lexer = this._lexer;
          if (!onPrefix && !onVersion && !onDirective && !onComment && !onToken && !onTokenEnd && lexer.tokenize === _N3Lexer.default.prototype.tokenize && typeof lexer._tokenizeString === "function") {
            const base = [this._base, this._basePath, this._baseRoot, this._baseScheme];
            lexer._tokenizeString(input, (e, token) => {
              if (e) {
                [this._base, this._basePath, this._baseRoot, this._baseScheme] = base;
                this._callback(e), this._callback = noop;
              } else if (this._readCallback) readToken(token);
            });
          } else lexer.tokenize(input).every(readToken);
          if (error) throw error;
          return quads;
        }
        const processNextToken = (error, token) => {
          if (error !== null) this._callback(error), this._callback = noop;
          else if (this._readCallback) readToken(token);
        };
        this._callback = onQuad;
        this._lexer.tokenize(input, processNextToken);
      }
    };
    exports2.default = N3Parser;
    function undoChanges(map, changes) {
      for (let i = changes.length - 2; i >= 0; i -= 2) {
        if (changes[i + 1] === void 0) delete map[changes[i]];
        else map[changes[i]] = changes[i + 1];
      }
    }
    function noop() {
    }
    function initDataFactory(parser, factory) {
      parser._factory = factory;
      parser.DEFAULTGRAPH = factory.defaultGraph();
      parser.RDF_FIRST = factory.namedNode(_IRIs.default.rdf.first);
      parser.RDF_REST = factory.namedNode(_IRIs.default.rdf.rest);
      parser.RDF_NIL = factory.namedNode(_IRIs.default.rdf.nil);
      parser.RDF_REIFIES = factory.namedNode(_IRIs.default.rdf.reifies);
      parser.N3_FORALL = factory.namedNode(_IRIs.default.r.forAll);
      parser.N3_FORSOME = factory.namedNode(_IRIs.default.r.forSome);
      parser.N3_TRUE = factory.literal("true", factory.namedNode(_IRIs.default.xsd.boolean));
      parser.ABBREVIATIONS = {
        "a": factory.namedNode(_IRIs.default.rdf.type),
        "=": factory.namedNode(_IRIs.default.owl.sameAs),
        ">": factory.namedNode(_IRIs.default.log.implies),
        "<": factory.namedNode(_IRIs.default.log.isImpliedBy)
      };
      parser.QUANTIFIERS_GRAPH = factory.namedNode("urn:n3:quantifiers");
    }
    N3Parser.SUPPORTED_VERSIONS = ["1.2", "1.2-basic", "1.1"];
    initDataFactory(N3Parser.prototype, _N3DataFactory.default);
  }
});

// ../vscode/node_modules/n3/lib/N3Util.js
var require_N3Util = __commonJS({
  "../vscode/node_modules/n3/lib/N3Util.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    exports2.inDefaultGraph = inDefaultGraph;
    exports2.isBlankNode = isBlankNode;
    exports2.isDefaultGraph = isDefaultGraph;
    exports2.isLiteral = isLiteral;
    exports2.isNamedNode = isNamedNode;
    exports2.isQuad = isQuad;
    exports2.isVariable = isVariable;
    exports2.prefix = prefix;
    exports2.prefixes = prefixes;
    var _N3DataFactory = _interopRequireDefault(require_N3DataFactory());
    function _interopRequireDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    function isNamedNode(term) {
      return !!term && term.termType === "NamedNode";
    }
    function isBlankNode(term) {
      return !!term && term.termType === "BlankNode";
    }
    function isLiteral(term) {
      return !!term && term.termType === "Literal";
    }
    function isVariable(term) {
      return !!term && term.termType === "Variable";
    }
    function isQuad(term) {
      return !!term && term.termType === "Quad";
    }
    function isDefaultGraph(term) {
      return !!term && term.termType === "DefaultGraph";
    }
    function inDefaultGraph(quad) {
      return isDefaultGraph(quad.graph);
    }
    function prefix(iri, factory) {
      return prefixes({
        "": iri.value || iri
      }, factory)("");
    }
    function prefixes(defaultPrefixes, factory) {
      const prefixes2 = /* @__PURE__ */ Object.create(null);
      for (const prefix2 in defaultPrefixes) processPrefix(prefix2, defaultPrefixes[prefix2]);
      factory = factory || _N3DataFactory.default;
      function processPrefix(prefix2, iri) {
        if (typeof iri === "string") {
          const cache = /* @__PURE__ */ Object.create(null);
          prefixes2[prefix2] = (local) => {
            return cache[local] || (cache[local] = factory.namedNode(iri + local));
          };
        } else if (!(prefix2 in prefixes2)) {
          throw new Error(`Unknown prefix: ${prefix2}`);
        }
        return prefixes2[prefix2];
      }
      return processPrefix;
    }
  }
});

// ../vscode/node_modules/n3/lib/Util.js
var require_Util = __commonJS({
  "../vscode/node_modules/n3/lib/Util.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    exports2.escapeRegex = escapeRegex;
    function escapeRegex(regex) {
      return regex.replace(/[.*+?^${}()|[\]\\/-]/g, "\\$&");
    }
  }
});

// ../vscode/node_modules/n3/lib/BaseIRI.js
var require_BaseIRI = __commonJS({
  "../vscode/node_modules/n3/lib/BaseIRI.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    exports2.default = void 0;
    var _Util = require_Util();
    var BASE_UNSUPPORTED = /^:?[^:?#]*(?:[?#]|$)|^file:|^[^:]*:\/*[^?#]+?\/(?:\.\.?(?:\/|$)|\/)/i;
    var SUFFIX_SUPPORTED = /^(?:(?!\.\.?(?:[/?#]|$))[^/?#]+(?:\/[^/?#]{3,})*\/?)?(?:[?#]|$)/;
    var CURRENT = "./";
    var PARENT = "../";
    var QUERY = "?";
    var FRAGMENT = "#";
    var BaseIRI = class _BaseIRI {
      constructor(base) {
        this.base = base;
        this._baseLength = 0;
        this._baseMatcher = null;
        this._pathReplacements = new Array(base.length + 1);
      }
      static supports(base) {
        return !BASE_UNSUPPORTED.test(base);
      }
      _getBaseMatcher() {
        if (this._baseMatcher) return this._baseMatcher;
        if (!_BaseIRI.supports(this.base)) return this._baseMatcher = /.^/;
        const scheme = /^[^:]*:\/*/.exec(this.base)[0];
        const regexHead = ["^", (0, _Util.escapeRegex)(scheme)];
        const regexTail = [];
        const segments = [], segmenter = /[^/?#]*([/?#])/y;
        let segment, query = 0, fragment = 0, last = segmenter.lastIndex = scheme.length;
        while (!query && !fragment && (segment = segmenter.exec(this.base))) {
          if (segment[1] === FRAGMENT) fragment = segmenter.lastIndex - 1;
          else {
            regexHead.push((0, _Util.escapeRegex)(segment[0]), "(?:");
            regexTail.push(")?");
            if (segment[1] !== QUERY) segments.push(last = segmenter.lastIndex);
            else {
              query = last = segmenter.lastIndex;
              fragment = this.base.indexOf(FRAGMENT, query);
              this._pathReplacements[query] = QUERY;
            }
          }
        }
        for (let i = 0; i < segments.length; i++) this._pathReplacements[segments[i]] = PARENT.repeat(segments.length - i - 1);
        this._pathReplacements[segments[segments.length - 1]] = CURRENT;
        this._baseLength = fragment > 0 ? fragment : this.base.length;
        regexHead.push((0, _Util.escapeRegex)(this.base.substring(last, this._baseLength)), query ? "(?:#|$)" : "(?:[?#]|$)");
        return this._baseMatcher = new RegExp([...regexHead, ...regexTail].join(""));
      }
      toRelative(iri) {
        const match = this._getBaseMatcher().exec(iri);
        if (!match) return iri;
        const length = match[0].length;
        if (length === this._baseLength && length === iri.length) return "";
        const parentPath = this._pathReplacements[length];
        if (parentPath) {
          const suffix = iri.substring(length);
          if (parentPath !== QUERY && !SUFFIX_SUPPORTED.test(suffix)) return iri;
          if (parentPath === CURRENT && /^[^?#]/.test(suffix) && (suffix.indexOf(":") < 0 || !/^[^/?#]*:/.test(suffix))) return suffix;
          return parentPath + suffix;
        }
        return iri.substring(length - 1);
      }
    };
    exports2.default = BaseIRI;
  }
});

// ../vscode/node_modules/n3/lib/N3Writer.js
var require_N3Writer = __commonJS({
  "../vscode/node_modules/n3/lib/N3Writer.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    exports2.default = void 0;
    var _IRIs = _interopRequireDefault(require_IRIs());
    var _N3DataFactory = _interopRequireWildcard(require_N3DataFactory());
    var _N3Util = require_N3Util();
    var _BaseIRI = _interopRequireDefault(require_BaseIRI());
    var _Util = require_Util();
    function _interopRequireWildcard(e, t) {
      if ("function" == typeof WeakMap) var r = /* @__PURE__ */ new WeakMap(), n = /* @__PURE__ */ new WeakMap();
      return (_interopRequireWildcard = function(e2, t2) {
        if (!t2 && e2 && e2.__esModule) return e2;
        var o, i, f = { __proto__: null, default: e2 };
        if (null === e2 || "object" != typeof e2 && "function" != typeof e2) return f;
        if (o = t2 ? n : r) {
          if (o.has(e2)) return o.get(e2);
          o.set(e2, f);
        }
        for (const t3 in e2) "default" !== t3 && {}.hasOwnProperty.call(e2, t3) && ((i = (o = Object.defineProperty) && Object.getOwnPropertyDescriptor(e2, t3)) && (i.get || i.set) ? o(f, t3, i) : f[t3] = e2[t3]);
        return f;
      })(e, t);
    }
    function _interopRequireDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var DEFAULTGRAPH = _N3DataFactory.default.defaultGraph();
    var {
      rdf,
      xsd
    } = _IRIs.default;
    var {
      hasOwnProperty
    } = Object.prototype;
    var escape2 = /["\\\t\n\r\b\f\u0000-\u0019\ud800-\udbff]/;
    var escapeAll = /["\\\t\n\r\b\f\u0000-\u0019]|[\ud800-\udbff][\udc00-\udfff]/g;
    var canonicalEscape = /[^ !#-\[\]-~\u0080-\uFFFD]/;
    var canonicalEscapeAll = /[^ !#-\[\]-~\u0080-\uFFFD]/g;
    var escapedCharacters = {
      "\\": "\\\\",
      '"': '\\"',
      "	": "\\t",
      "\n": "\\n",
      "\r": "\\r",
      "\b": "\\b",
      "\f": "\\f"
    };
    var invalidVersionLabel = /["\\\u0000-\u001f\u007f]|[\ud800-\udbff](?![\udc00-\udfff])|(?:^|[^\ud800-\udbff])[\udc00-\udfff]/;
    var localNameStart = "A-Za-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD_:0-9";
    var localNameChar = `${localNameStart}\\-\\u00B7\\u0300-\\u036F\\u203F\\u2040`;
    var percent = "%[0-9A-Fa-f]{2}";
    var localName2 = new RegExp(`^(?:(?:[${localNameStart}]|${percent})(?:(?:[${localNameChar}.]|${percent})*(?:[${localNameChar}]|${percent}))?)?$`);
    var SerializedTerm = class extends _N3DataFactory.Term {
      // Pretty-printed nodes are not equal to any other node
      // (e.g., [] does not equal [])
      equals(other) {
        return other === this;
      }
    };
    var N3Writer = class {
      constructor(outputStream, options) {
        this._prefixRegex = /$0^/;
        this._hasPrefixes = false;
        if (outputStream && typeof outputStream.write !== "function") options = outputStream, outputStream = null;
        options = options || {};
        this._lists = options.lists;
        if (!outputStream) {
          let output = "";
          this._outputStream = {
            write(chunk, encoding, done) {
              output += chunk;
              done && done();
            },
            end: (done) => {
              done && done(null, output);
            }
          };
          this._endStream = true;
        } else {
          this._outputStream = outputStream;
          this._endStream = options.end === void 0 ? true : !!options.end;
        }
        if (options.version && invalidVersionLabel.test(options.version)) throw new Error(`Invalid version label: ${JSON.stringify(options.version)}`);
        this._subject = null;
        if (!/triple|quad/i.test(options.format)) {
          this._lineMode = false;
          this._escape = escape2, this._escapeAll = escapeAll, this._characterReplacer = characterReplacer;
          this._graph = DEFAULTGRAPH;
          if (options.version) this._write(`@version "${options.version}".
`);
          this._prefixIRIs = /* @__PURE__ */ Object.create(null);
          this._prefixPatterns = /* @__PURE__ */ Object.create(null);
          if (options.baseIRI) {
            this._baseIri = new _BaseIRI.default(options.baseIRI);
            if (options.writeBase) this._write(`@base <${options.baseIRI}>.
`);
          }
          options.prefixes && this.addPrefixes(options.prefixes);
        } else {
          this._lineMode = true;
          this._writeQuad = this._writeQuadLine;
          this._escape = canonicalEscape, this._escapeAll = canonicalEscapeAll;
          this._characterReplacer = canonicalCharacterReplacer;
          if (options.version) this._write(`VERSION "${options.version}"
`);
        }
      }
      // ## Private methods
      // ### Whether the current graph is the default graph
      get _inDefaultGraph() {
        return DEFAULTGRAPH.equals(this._graph);
      }
      // ### `_write` writes the argument to the output stream
      _write(string, callback) {
        this._outputStream.write(string, "utf8", callback);
      }
      // ### `_endStatement` finishes a pending statement and closes an open graph block
      _endStatement() {
        if (this._subject !== null) {
          this._write(this._inDefaultGraph ? ".\n" : "\n}\n");
          this._subject = null;
          this._graph = DEFAULTGRAPH;
        }
      }
      // ### `_writeQuad` writes the quad to the output stream
      _writeQuad(subject, predicate, object, graph, done) {
        try {
          if (graph !== this._graph && (!graph.equals(this._graph) || graph.termType !== this._graph.termType)) {
            this._write((this._subject === null ? "" : this._inDefaultGraph ? ".\n" : "\n}\n") + (DEFAULTGRAPH.equals(graph) ? "" : `${this._encodeIriOrBlank(graph)} {
`));
            this._graph = graph;
            this._subject = null;
          }
          if (subject === this._subject || subject.equals(this._subject)) {
            if (predicate === this._predicate || predicate.equals(this._predicate)) this._write(`, ${this._encodeObject(object)}`, done);
            else this._write(`;
    ${this._encodePredicate(this._predicate = predicate)} ${this._encodeObject(object)}`, done);
          } else this._write(`${(this._subject === null ? "" : ".\n") + this._encodeSubject(this._subject = subject)} ${this._encodePredicate(this._predicate = predicate)} ${this._encodeObject(object)}`, done);
        } catch (error) {
          done && done(error);
        }
      }
      // ### `_writeQuadLine` writes the quad to the output stream as a single line
      _writeQuadLine(subject, predicate, object, graph, done) {
        delete this._prefixMatch;
        this._write(this.quadToString(subject, predicate, object, graph), done);
      }
      // ### `quadToString` serializes a quad as a string
      quadToString(subject, predicate, object, graph) {
        return `${this._encodeSubject(subject)} ${predicate.termType === "Literal" ? this._encodeLiteral(predicate) : this._encodeIriOrBlank(predicate)} ${this._encodeObject(object)}${graph && !(0, _N3Util.isDefaultGraph)(graph) ? ` ${this._encodeIriOrBlank(graph)} .
` : " .\n"}`;
      }
      // ### `quadsToString` serializes an array of quads as a string
      quadsToString(quads) {
        let quadsString = "";
        for (const quad of quads) quadsString += this.quadToString(quad.subject, quad.predicate, quad.object, quad.graph);
        return quadsString;
      }
      // ### `_encodeSubject` represents a subject
      _encodeSubject(entity) {
        switch (entity.termType) {
          case "Quad":
            return this._encodeQuad(entity);
          // Literal subjects are only valid in N3
          case "Literal":
            return this._encodeLiteral(entity);
          default:
            return this._encodeIriOrBlank(entity);
        }
      }
      // ### `_encodeIriOrBlank` represents an IRI or blank node
      _encodeIriOrBlank(entity) {
        if (entity.termType !== "NamedNode") {
          if (this._lists && hasOwnProperty.call(this._lists, entity.value)) entity = this.list(this._lists[entity.value]);
          if (entity instanceof _N3DataFactory.Term) return entity.id;
          return entity.termType === "Variable" ? `?${entity.value}` : `_:${entity.value}`;
        }
        let iri = entity.value;
        if (this._baseIri) {
          iri = this._baseIri.toRelative(iri);
        }
        if (this._escape.test(iri)) iri = iri.replace(this._escapeAll, this._characterReplacer);
        const prefixMatch = this._hasPrefixes ? (this._prefixRegex || this._createPrefixRegex()).exec(iri) : null;
        if (!prefixMatch) return `<${iri}>`;
        if (prefixMatch[1]) return this._prefixIRIs[prefixMatch[1]] + prefixMatch[2];
        return localName2.test(iri.slice(prefixMatch[0].length)) ? iri : `<${iri}>`;
      }
      // ### `_encodeLiteral` represents a literal
      _encodeLiteral(literal) {
        let value = literal.value;
        if (this._escape.test(value)) value = value.replace(this._escapeAll, this._characterReplacer);
        const language = literal.language;
        if (language) {
          const literalDirection = literal.direction;
          const direction = literalDirection ? `--${literalDirection}` : "";
          return `"${value}"@${language}${direction}`;
        }
        if (this._lineMode) {
          if (literal.datatype.value === xsd.string) return `"${value}"`;
        } else {
          switch (literal.datatype.value) {
            case xsd.string:
              return `"${value}"`;
            case xsd.boolean:
              if (value === "true" || value === "false") return value;
              break;
            case xsd.integer:
              if (/^[+-]?\d+$/.test(value)) return value;
              break;
            case xsd.decimal:
              if (/^[+-]?\d*\.\d+$/.test(value)) return value;
              break;
            case xsd.double:
              if (/^[+-]?(?:\d+\.\d*|\.?\d+)[eE][+-]?\d+$/.test(value)) return value;
              break;
          }
        }
        return `"${value}"^^${this._encodeIriOrBlank(literal.datatype)}`;
      }
      // ### `_encodePredicate` represents a predicate
      _encodePredicate(predicate) {
        switch (predicate.termType) {
          case "NamedNode":
            return predicate.value === rdf.type ? "a" : this._encodeIriOrBlank(predicate);
          // Literal predicates are only valid in N3
          case "Literal":
            return this._encodeLiteral(predicate);
          default:
            return this._encodeIriOrBlank(predicate);
        }
      }
      // ### `_encodeObject` represents an object
      _encodeObject(object) {
        switch (object.termType) {
          case "Quad":
            return this._encodeQuad(object);
          case "Literal":
            return this._encodeLiteral(object);
          default:
            return this._encodeIriOrBlank(object);
        }
      }
      // ### `_encodeQuad` encodes an RDF-star quad
      _encodeQuad({
        subject,
        predicate,
        object,
        graph
      }) {
        const space = this._lineMode ? " " : "";
        return `<<(${space}${this._encodeSubject(subject)} ${this._encodePredicate(predicate)} ${this._encodeObject(object)}${(0, _N3Util.isDefaultGraph)(graph) ? "" : ` ${this._encodeIriOrBlank(graph)}`}${space})>>`;
      }
      // ### `_blockedWrite` replaces `_write` after the writer has been closed
      _blockedWrite() {
        throw new Error("Cannot write because the writer has been closed.");
      }
      // ### `addQuad` adds the quad to the output stream
      addQuad(subject, predicate, object, graph, done) {
        if (object === void 0) this._writeQuad(subject.subject, subject.predicate, subject.object, subject.graph, predicate);
        else if (typeof graph === "function") this._writeQuad(subject, predicate, object, DEFAULTGRAPH, graph);
        else this._writeQuad(subject, predicate, object, graph || DEFAULTGRAPH, done);
      }
      // ### `addQuads` adds the quads to the output stream
      addQuads(quads) {
        for (let i = 0; i < quads.length; i++) this.addQuad(quads[i]);
      }
      // ### `addPrefix` adds the prefix to the output stream
      addPrefix(prefix, iri, done) {
        const prefixes = {};
        prefixes[prefix] = iri;
        this.addPrefixes(prefixes, done);
      }
      // ### `addPrefixes` adds the prefixes to the output stream
      addPrefixes(prefixes, done) {
        if (!this._prefixIRIs) return done && done();
        let hasPrefixes = false;
        for (let prefix in prefixes) {
          let iri = prefixes[prefix];
          if (typeof iri !== "string") iri = iri.value;
          hasPrefixes = true;
          this._endStatement();
          this._prefixIRIs[iri] = prefix += ":";
          this._prefixPatterns[iri] = [(0, _Util.escapeRegex)(iri), (0, _Util.escapeRegex)(prefix)];
          this._write(`@prefix ${prefix} <${iri}>.
`);
        }
        if (hasPrefixes) {
          this._hasPrefixes = true;
          this._prefixRegex = null;
        }
        this._write(hasPrefixes ? "\n" : "", done);
      }
      // ### `_createPrefixRegex` creates the matcher for the current prefixes
      _createPrefixRegex() {
        let IRIlist = "", prefixList = "";
        for (const prefixIRI in this._prefixPatterns) {
          const [IRIpattern, prefixPattern] = this._prefixPatterns[prefixIRI];
          IRIlist += IRIlist ? `|${IRIpattern}` : IRIpattern;
          prefixList += prefixList ? `|${prefixPattern}` : prefixPattern;
        }
        return this._prefixRegex = new RegExp(`^(${IRIlist})([_a-zA-Z0-9](?:\\.?[\\-_a-zA-Z0-9])*)$|^(?:${prefixList})`);
      }
      // ### `blank` creates a blank node with the given content
      blank(predicate, object) {
        let children = predicate, child, length;
        if (predicate === void 0) children = [];
        else if (predicate.termType) children = [{
          predicate,
          object
        }];
        else if (!("length" in predicate)) children = [predicate];
        switch (length = children.length) {
          // Generate an empty blank node
          case 0:
            return new SerializedTerm("[]");
          // Generate a non-nested one-triple blank node
          case 1:
            child = children[0];
            if (!(child.object instanceof SerializedTerm)) return new SerializedTerm(`[ ${this._encodePredicate(child.predicate)} ${this._encodeObject(child.object)} ]`);
          // Generate a multi-triple or nested blank node
          default:
            let contents = "[";
            for (let i = 0; i < length; i++) {
              child = children[i];
              if (child.predicate.equals(predicate)) contents += `, ${this._encodeObject(child.object)}`;
              else {
                contents += `${(i ? ";\n  " : "\n  ") + this._encodePredicate(child.predicate)} ${this._encodeObject(child.object)}`;
                predicate = child.predicate;
              }
            }
            return new SerializedTerm(`${contents}
]`);
        }
      }
      // ### `list` creates a list node with the given content
      list(elements) {
        const length = elements && elements.length || 0, contents = new Array(length);
        for (let i = 0; i < length; i++) contents[i] = this._encodeObject(elements[i]);
        return new SerializedTerm(`(${contents.join(" ")})`);
      }
      // ### `end` signals the end of the output stream
      end(done) {
        this._endStatement();
        this._write = this._blockedWrite;
        let singleDone = done && ((error, result) => {
          singleDone = null, done(error, result);
        });
        if (this._endStream) {
          try {
            return this._outputStream.end(singleDone);
          } catch (error) {
          }
        }
        singleDone && singleDone();
      }
    };
    exports2.default = N3Writer;
    function characterReplacer(character) {
      let result = escapedCharacters[character];
      if (result === void 0) {
        if (character.length === 1) {
          result = character.charCodeAt(0).toString(16);
          result = "\\u0000".substr(0, 6 - result.length) + result;
        } else {
          result = ((character.charCodeAt(0) - 55296) * 1024 + character.charCodeAt(1) + 9216).toString(16);
          result = "\\U00000000".substr(0, 10 - result.length) + result;
        }
      }
      return result;
    }
    function canonicalCharacterReplacer(character) {
      let result = escapedCharacters[character];
      if (result === void 0) {
        result = character.charCodeAt(0).toString(16).toUpperCase();
        result = "\\u0000".substr(0, 6 - result.length) + result;
      }
      return result;
    }
  }
});

// ../vscode/node_modules/readable-stream/lib/ours/primordials.js
var require_primordials = __commonJS({
  "../vscode/node_modules/readable-stream/lib/ours/primordials.js"(exports2, module2) {
    "use strict";
    var AggregateError = class extends Error {
      constructor(errors) {
        if (!Array.isArray(errors)) {
          throw new TypeError(`Expected input to be an Array, got ${typeof errors}`);
        }
        let message = "";
        for (let i = 0; i < errors.length; i++) {
          message += `    ${errors[i].stack}
`;
        }
        super(message);
        this.name = "AggregateError";
        this.errors = errors;
      }
    };
    module2.exports = {
      AggregateError,
      ArrayIsArray(self) {
        return Array.isArray(self);
      },
      ArrayPrototypeIncludes(self, el) {
        return self.includes(el);
      },
      ArrayPrototypeIndexOf(self, el) {
        return self.indexOf(el);
      },
      ArrayPrototypeJoin(self, sep) {
        return self.join(sep);
      },
      ArrayPrototypeMap(self, fn) {
        return self.map(fn);
      },
      ArrayPrototypePop(self, el) {
        return self.pop(el);
      },
      ArrayPrototypePush(self, el) {
        return self.push(el);
      },
      ArrayPrototypeSlice(self, start, end) {
        return self.slice(start, end);
      },
      Error,
      FunctionPrototypeCall(fn, thisArgs, ...args) {
        return fn.call(thisArgs, ...args);
      },
      FunctionPrototypeSymbolHasInstance(self, instance) {
        return Function.prototype[Symbol.hasInstance].call(self, instance);
      },
      MathFloor: Math.floor,
      Number,
      NumberIsInteger: Number.isInteger,
      NumberIsNaN: Number.isNaN,
      NumberMAX_SAFE_INTEGER: Number.MAX_SAFE_INTEGER,
      NumberMIN_SAFE_INTEGER: Number.MIN_SAFE_INTEGER,
      NumberParseInt: Number.parseInt,
      ObjectDefineProperties(self, props) {
        return Object.defineProperties(self, props);
      },
      ObjectDefineProperty(self, name, prop) {
        return Object.defineProperty(self, name, prop);
      },
      ObjectGetOwnPropertyDescriptor(self, name) {
        return Object.getOwnPropertyDescriptor(self, name);
      },
      ObjectKeys(obj) {
        return Object.keys(obj);
      },
      ObjectSetPrototypeOf(target, proto) {
        return Object.setPrototypeOf(target, proto);
      },
      Promise,
      PromisePrototypeCatch(self, fn) {
        return self.catch(fn);
      },
      PromisePrototypeThen(self, thenFn, catchFn) {
        return self.then(thenFn, catchFn);
      },
      PromiseReject(err) {
        return Promise.reject(err);
      },
      PromiseResolve(val) {
        return Promise.resolve(val);
      },
      ReflectApply: Reflect.apply,
      RegExpPrototypeTest(self, value) {
        return self.test(value);
      },
      SafeSet: Set,
      String,
      StringPrototypeSlice(self, start, end) {
        return self.slice(start, end);
      },
      StringPrototypeToLowerCase(self) {
        return self.toLowerCase();
      },
      StringPrototypeToUpperCase(self) {
        return self.toUpperCase();
      },
      StringPrototypeTrim(self) {
        return self.trim();
      },
      Symbol,
      SymbolFor: Symbol.for,
      SymbolAsyncIterator: Symbol.asyncIterator,
      SymbolHasInstance: Symbol.hasInstance,
      SymbolIterator: Symbol.iterator,
      SymbolDispose: Symbol.dispose || /* @__PURE__ */ Symbol("Symbol.dispose"),
      SymbolAsyncDispose: Symbol.asyncDispose || /* @__PURE__ */ Symbol("Symbol.asyncDispose"),
      TypedArrayPrototypeSet(self, buf, len) {
        return self.set(buf, len);
      },
      Boolean,
      Uint8Array
    };
  }
});

// ../vscode/node_modules/readable-stream/lib/ours/util/inspect.js
var require_inspect = __commonJS({
  "../vscode/node_modules/readable-stream/lib/ours/util/inspect.js"(exports2, module2) {
    "use strict";
    module2.exports = {
      format(format, ...args) {
        return format.replace(/%([sdifj])/g, function(...[_unused, type]) {
          const replacement = args.shift();
          if (type === "f") {
            return replacement.toFixed(6);
          } else if (type === "j") {
            return JSON.stringify(replacement);
          } else if (type === "s" && typeof replacement === "object") {
            const ctor = replacement.constructor !== Object ? replacement.constructor.name : "";
            return `${ctor} {}`.trim();
          } else {
            return replacement.toString();
          }
        });
      },
      inspect(value) {
        switch (typeof value) {
          case "string":
            if (value.includes("'")) {
              if (!value.includes('"')) {
                return `"${value}"`;
              } else if (!value.includes("`") && !value.includes("${")) {
                return `\`${value}\``;
              }
            }
            return `'${value}'`;
          case "number":
            if (isNaN(value)) {
              return "NaN";
            } else if (Object.is(value, -0)) {
              return String(value);
            }
            return value;
          case "bigint":
            return `${String(value)}n`;
          case "boolean":
          case "undefined":
            return String(value);
          case "object":
            return "{}";
        }
      }
    };
  }
});

// ../vscode/node_modules/readable-stream/lib/ours/errors.js
var require_errors = __commonJS({
  "../vscode/node_modules/readable-stream/lib/ours/errors.js"(exports2, module2) {
    "use strict";
    var { format, inspect } = require_inspect();
    var { AggregateError: CustomAggregateError } = require_primordials();
    var AggregateError = globalThis.AggregateError || CustomAggregateError;
    var kIsNodeError = /* @__PURE__ */ Symbol("kIsNodeError");
    var kTypes = [
      "string",
      "function",
      "number",
      "object",
      // Accept 'Function' and 'Object' as alternative to the lower cased version.
      "Function",
      "Object",
      "boolean",
      "bigint",
      "symbol"
    ];
    var classRegExp = /^([A-Z][a-z0-9]*)+$/;
    var nodeInternalPrefix = "__node_internal_";
    var codes = {};
    function assert(value, message) {
      if (!value) {
        throw new codes.ERR_INTERNAL_ASSERTION(message);
      }
    }
    function addNumericalSeparator(val) {
      let res2 = "";
      let i = val.length;
      const start = val[0] === "-" ? 1 : 0;
      for (; i >= start + 4; i -= 3) {
        res2 = `_${val.slice(i - 3, i)}${res2}`;
      }
      return `${val.slice(0, i)}${res2}`;
    }
    function getMessage(key, msg, args) {
      if (typeof msg === "function") {
        assert(
          msg.length <= args.length,
          // Default options do not count.
          `Code: ${key}; The provided arguments length (${args.length}) does not match the required ones (${msg.length}).`
        );
        return msg(...args);
      }
      const expectedLength = (msg.match(/%[dfijoOs]/g) || []).length;
      assert(
        expectedLength === args.length,
        `Code: ${key}; The provided arguments length (${args.length}) does not match the required ones (${expectedLength}).`
      );
      if (args.length === 0) {
        return msg;
      }
      return format(msg, ...args);
    }
    function E(code, message, Base) {
      if (!Base) {
        Base = Error;
      }
      class NodeError extends Base {
        constructor(...args) {
          super(getMessage(code, message, args));
        }
        toString() {
          return `${this.name} [${code}]: ${this.message}`;
        }
      }
      Object.defineProperties(NodeError.prototype, {
        name: {
          value: Base.name,
          writable: true,
          enumerable: false,
          configurable: true
        },
        toString: {
          value() {
            return `${this.name} [${code}]: ${this.message}`;
          },
          writable: true,
          enumerable: false,
          configurable: true
        }
      });
      NodeError.prototype.code = code;
      NodeError.prototype[kIsNodeError] = true;
      codes[code] = NodeError;
    }
    function hideStackFrames(fn) {
      const hidden = nodeInternalPrefix + fn.name;
      Object.defineProperty(fn, "name", {
        value: hidden
      });
      return fn;
    }
    function aggregateTwoErrors(innerError, outerError) {
      if (innerError && outerError && innerError !== outerError) {
        if (Array.isArray(outerError.errors)) {
          outerError.errors.push(innerError);
          return outerError;
        }
        const err = new AggregateError([outerError, innerError], outerError.message);
        err.code = outerError.code;
        return err;
      }
      return innerError || outerError;
    }
    var AbortError = class extends Error {
      constructor(message = "The operation was aborted", options = void 0) {
        if (options !== void 0 && typeof options !== "object") {
          throw new codes.ERR_INVALID_ARG_TYPE("options", "Object", options);
        }
        super(message, options);
        this.code = "ABORT_ERR";
        this.name = "AbortError";
      }
    };
    E("ERR_ASSERTION", "%s", Error);
    E(
      "ERR_INVALID_ARG_TYPE",
      (name, expected, actual) => {
        assert(typeof name === "string", "'name' must be a string");
        if (!Array.isArray(expected)) {
          expected = [expected];
        }
        let msg = "The ";
        if (name.endsWith(" argument")) {
          msg += `${name} `;
        } else {
          msg += `"${name}" ${name.includes(".") ? "property" : "argument"} `;
        }
        msg += "must be ";
        const types = [];
        const instances = [];
        const other = [];
        for (const value of expected) {
          assert(typeof value === "string", "All expected entries have to be of type string");
          if (kTypes.includes(value)) {
            types.push(value.toLowerCase());
          } else if (classRegExp.test(value)) {
            instances.push(value);
          } else {
            assert(value !== "object", 'The value "object" should be written as "Object"');
            other.push(value);
          }
        }
        if (instances.length > 0) {
          const pos = types.indexOf("object");
          if (pos !== -1) {
            types.splice(types, pos, 1);
            instances.push("Object");
          }
        }
        if (types.length > 0) {
          switch (types.length) {
            case 1:
              msg += `of type ${types[0]}`;
              break;
            case 2:
              msg += `one of type ${types[0]} or ${types[1]}`;
              break;
            default: {
              const last = types.pop();
              msg += `one of type ${types.join(", ")}, or ${last}`;
            }
          }
          if (instances.length > 0 || other.length > 0) {
            msg += " or ";
          }
        }
        if (instances.length > 0) {
          switch (instances.length) {
            case 1:
              msg += `an instance of ${instances[0]}`;
              break;
            case 2:
              msg += `an instance of ${instances[0]} or ${instances[1]}`;
              break;
            default: {
              const last = instances.pop();
              msg += `an instance of ${instances.join(", ")}, or ${last}`;
            }
          }
          if (other.length > 0) {
            msg += " or ";
          }
        }
        switch (other.length) {
          case 0:
            break;
          case 1:
            if (other[0].toLowerCase() !== other[0]) {
              msg += "an ";
            }
            msg += `${other[0]}`;
            break;
          case 2:
            msg += `one of ${other[0]} or ${other[1]}`;
            break;
          default: {
            const last = other.pop();
            msg += `one of ${other.join(", ")}, or ${last}`;
          }
        }
        if (actual == null) {
          msg += `. Received ${actual}`;
        } else if (typeof actual === "function" && actual.name) {
          msg += `. Received function ${actual.name}`;
        } else if (typeof actual === "object") {
          var _actual$constructor;
          if ((_actual$constructor = actual.constructor) !== null && _actual$constructor !== void 0 && _actual$constructor.name) {
            msg += `. Received an instance of ${actual.constructor.name}`;
          } else {
            const inspected = inspect(actual, {
              depth: -1
            });
            msg += `. Received ${inspected}`;
          }
        } else {
          let inspected = inspect(actual, {
            colors: false
          });
          if (inspected.length > 25) {
            inspected = `${inspected.slice(0, 25)}...`;
          }
          msg += `. Received type ${typeof actual} (${inspected})`;
        }
        return msg;
      },
      TypeError
    );
    E(
      "ERR_INVALID_ARG_VALUE",
      (name, value, reason = "is invalid") => {
        let inspected = inspect(value);
        if (inspected.length > 128) {
          inspected = inspected.slice(0, 128) + "...";
        }
        const type = name.includes(".") ? "property" : "argument";
        return `The ${type} '${name}' ${reason}. Received ${inspected}`;
      },
      TypeError
    );
    E(
      "ERR_INVALID_RETURN_VALUE",
      (input, name, value) => {
        var _value$constructor;
        const type = value !== null && value !== void 0 && (_value$constructor = value.constructor) !== null && _value$constructor !== void 0 && _value$constructor.name ? `instance of ${value.constructor.name}` : `type ${typeof value}`;
        return `Expected ${input} to be returned from the "${name}" function but got ${type}.`;
      },
      TypeError
    );
    E(
      "ERR_MISSING_ARGS",
      (...args) => {
        assert(args.length > 0, "At least one arg needs to be specified");
        let msg;
        const len = args.length;
        args = (Array.isArray(args) ? args : [args]).map((a) => `"${a}"`).join(" or ");
        switch (len) {
          case 1:
            msg += `The ${args[0]} argument`;
            break;
          case 2:
            msg += `The ${args[0]} and ${args[1]} arguments`;
            break;
          default:
            {
              const last = args.pop();
              msg += `The ${args.join(", ")}, and ${last} arguments`;
            }
            break;
        }
        return `${msg} must be specified`;
      },
      TypeError
    );
    E(
      "ERR_OUT_OF_RANGE",
      (str, range, input) => {
        assert(range, 'Missing "range" argument');
        let received;
        if (Number.isInteger(input) && Math.abs(input) > 2 ** 32) {
          received = addNumericalSeparator(String(input));
        } else if (typeof input === "bigint") {
          received = String(input);
          const limit = BigInt(2) ** BigInt(32);
          if (input > limit || input < -limit) {
            received = addNumericalSeparator(received);
          }
          received += "n";
        } else {
          received = inspect(input);
        }
        return `The value of "${str}" is out of range. It must be ${range}. Received ${received}`;
      },
      RangeError
    );
    E("ERR_MULTIPLE_CALLBACK", "Callback called multiple times", Error);
    E("ERR_METHOD_NOT_IMPLEMENTED", "The %s method is not implemented", Error);
    E("ERR_STREAM_ALREADY_FINISHED", "Cannot call %s after a stream was finished", Error);
    E("ERR_STREAM_CANNOT_PIPE", "Cannot pipe, not readable", Error);
    E("ERR_STREAM_DESTROYED", "Cannot call %s after a stream was destroyed", Error);
    E("ERR_STREAM_NULL_VALUES", "May not write null values to stream", TypeError);
    E("ERR_STREAM_PREMATURE_CLOSE", "Premature close", Error);
    E("ERR_STREAM_PUSH_AFTER_EOF", "stream.push() after EOF", Error);
    E("ERR_STREAM_UNSHIFT_AFTER_END_EVENT", "stream.unshift() after end event", Error);
    E("ERR_STREAM_WRITE_AFTER_END", "write after end", Error);
    E("ERR_UNKNOWN_ENCODING", "Unknown encoding: %s", TypeError);
    module2.exports = {
      AbortError,
      aggregateTwoErrors: hideStackFrames(aggregateTwoErrors),
      hideStackFrames,
      codes
    };
  }
});

// ../vscode/node_modules/event-target-shim/dist/event-target-shim.js
var require_event_target_shim = __commonJS({
  "../vscode/node_modules/event-target-shim/dist/event-target-shim.js"(exports2, module2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var privateData = /* @__PURE__ */ new WeakMap();
    var wrappers = /* @__PURE__ */ new WeakMap();
    function pd(event) {
      const retv = privateData.get(event);
      console.assert(
        retv != null,
        "'this' is expected an Event object, but got",
        event
      );
      return retv;
    }
    function setCancelFlag(data) {
      if (data.passiveListener != null) {
        if (typeof console !== "undefined" && typeof console.error === "function") {
          console.error(
            "Unable to preventDefault inside passive event listener invocation.",
            data.passiveListener
          );
        }
        return;
      }
      if (!data.event.cancelable) {
        return;
      }
      data.canceled = true;
      if (typeof data.event.preventDefault === "function") {
        data.event.preventDefault();
      }
    }
    function Event(eventTarget, event) {
      privateData.set(this, {
        eventTarget,
        event,
        eventPhase: 2,
        currentTarget: eventTarget,
        canceled: false,
        stopped: false,
        immediateStopped: false,
        passiveListener: null,
        timeStamp: event.timeStamp || Date.now()
      });
      Object.defineProperty(this, "isTrusted", { value: false, enumerable: true });
      const keys = Object.keys(event);
      for (let i = 0; i < keys.length; ++i) {
        const key = keys[i];
        if (!(key in this)) {
          Object.defineProperty(this, key, defineRedirectDescriptor(key));
        }
      }
    }
    Event.prototype = {
      /**
       * The type of this event.
       * @type {string}
       */
      get type() {
        return pd(this).event.type;
      },
      /**
       * The target of this event.
       * @type {EventTarget}
       */
      get target() {
        return pd(this).eventTarget;
      },
      /**
       * The target of this event.
       * @type {EventTarget}
       */
      get currentTarget() {
        return pd(this).currentTarget;
      },
      /**
       * @returns {EventTarget[]} The composed path of this event.
       */
      composedPath() {
        const currentTarget = pd(this).currentTarget;
        if (currentTarget == null) {
          return [];
        }
        return [currentTarget];
      },
      /**
       * Constant of NONE.
       * @type {number}
       */
      get NONE() {
        return 0;
      },
      /**
       * Constant of CAPTURING_PHASE.
       * @type {number}
       */
      get CAPTURING_PHASE() {
        return 1;
      },
      /**
       * Constant of AT_TARGET.
       * @type {number}
       */
      get AT_TARGET() {
        return 2;
      },
      /**
       * Constant of BUBBLING_PHASE.
       * @type {number}
       */
      get BUBBLING_PHASE() {
        return 3;
      },
      /**
       * The target of this event.
       * @type {number}
       */
      get eventPhase() {
        return pd(this).eventPhase;
      },
      /**
       * Stop event bubbling.
       * @returns {void}
       */
      stopPropagation() {
        const data = pd(this);
        data.stopped = true;
        if (typeof data.event.stopPropagation === "function") {
          data.event.stopPropagation();
        }
      },
      /**
       * Stop event bubbling.
       * @returns {void}
       */
      stopImmediatePropagation() {
        const data = pd(this);
        data.stopped = true;
        data.immediateStopped = true;
        if (typeof data.event.stopImmediatePropagation === "function") {
          data.event.stopImmediatePropagation();
        }
      },
      /**
       * The flag to be bubbling.
       * @type {boolean}
       */
      get bubbles() {
        return Boolean(pd(this).event.bubbles);
      },
      /**
       * The flag to be cancelable.
       * @type {boolean}
       */
      get cancelable() {
        return Boolean(pd(this).event.cancelable);
      },
      /**
       * Cancel this event.
       * @returns {void}
       */
      preventDefault() {
        setCancelFlag(pd(this));
      },
      /**
       * The flag to indicate cancellation state.
       * @type {boolean}
       */
      get defaultPrevented() {
        return pd(this).canceled;
      },
      /**
       * The flag to be composed.
       * @type {boolean}
       */
      get composed() {
        return Boolean(pd(this).event.composed);
      },
      /**
       * The unix time of this event.
       * @type {number}
       */
      get timeStamp() {
        return pd(this).timeStamp;
      },
      /**
       * The target of this event.
       * @type {EventTarget}
       * @deprecated
       */
      get srcElement() {
        return pd(this).eventTarget;
      },
      /**
       * The flag to stop event bubbling.
       * @type {boolean}
       * @deprecated
       */
      get cancelBubble() {
        return pd(this).stopped;
      },
      set cancelBubble(value) {
        if (!value) {
          return;
        }
        const data = pd(this);
        data.stopped = true;
        if (typeof data.event.cancelBubble === "boolean") {
          data.event.cancelBubble = true;
        }
      },
      /**
       * The flag to indicate cancellation state.
       * @type {boolean}
       * @deprecated
       */
      get returnValue() {
        return !pd(this).canceled;
      },
      set returnValue(value) {
        if (!value) {
          setCancelFlag(pd(this));
        }
      },
      /**
       * Initialize this event object. But do nothing under event dispatching.
       * @param {string} type The event type.
       * @param {boolean} [bubbles=false] The flag to be possible to bubble up.
       * @param {boolean} [cancelable=false] The flag to be possible to cancel.
       * @deprecated
       */
      initEvent() {
      }
    };
    Object.defineProperty(Event.prototype, "constructor", {
      value: Event,
      configurable: true,
      writable: true
    });
    if (typeof window !== "undefined" && typeof window.Event !== "undefined") {
      Object.setPrototypeOf(Event.prototype, window.Event.prototype);
      wrappers.set(window.Event.prototype, Event);
    }
    function defineRedirectDescriptor(key) {
      return {
        get() {
          return pd(this).event[key];
        },
        set(value) {
          pd(this).event[key] = value;
        },
        configurable: true,
        enumerable: true
      };
    }
    function defineCallDescriptor(key) {
      return {
        value() {
          const event = pd(this).event;
          return event[key].apply(event, arguments);
        },
        configurable: true,
        enumerable: true
      };
    }
    function defineWrapper(BaseEvent, proto) {
      const keys = Object.keys(proto);
      if (keys.length === 0) {
        return BaseEvent;
      }
      function CustomEvent(eventTarget, event) {
        BaseEvent.call(this, eventTarget, event);
      }
      CustomEvent.prototype = Object.create(BaseEvent.prototype, {
        constructor: { value: CustomEvent, configurable: true, writable: true }
      });
      for (let i = 0; i < keys.length; ++i) {
        const key = keys[i];
        if (!(key in BaseEvent.prototype)) {
          const descriptor = Object.getOwnPropertyDescriptor(proto, key);
          const isFunc = typeof descriptor.value === "function";
          Object.defineProperty(
            CustomEvent.prototype,
            key,
            isFunc ? defineCallDescriptor(key) : defineRedirectDescriptor(key)
          );
        }
      }
      return CustomEvent;
    }
    function getWrapper(proto) {
      if (proto == null || proto === Object.prototype) {
        return Event;
      }
      let wrapper = wrappers.get(proto);
      if (wrapper == null) {
        wrapper = defineWrapper(getWrapper(Object.getPrototypeOf(proto)), proto);
        wrappers.set(proto, wrapper);
      }
      return wrapper;
    }
    function wrapEvent(eventTarget, event) {
      const Wrapper = getWrapper(Object.getPrototypeOf(event));
      return new Wrapper(eventTarget, event);
    }
    function isStopped(event) {
      return pd(event).immediateStopped;
    }
    function setEventPhase(event, eventPhase) {
      pd(event).eventPhase = eventPhase;
    }
    function setCurrentTarget(event, currentTarget) {
      pd(event).currentTarget = currentTarget;
    }
    function setPassiveListener(event, passiveListener) {
      pd(event).passiveListener = passiveListener;
    }
    var listenersMap = /* @__PURE__ */ new WeakMap();
    var CAPTURE = 1;
    var BUBBLE = 2;
    var ATTRIBUTE = 3;
    function isObject(x) {
      return x !== null && typeof x === "object";
    }
    function getListeners(eventTarget) {
      const listeners = listenersMap.get(eventTarget);
      if (listeners == null) {
        throw new TypeError(
          "'this' is expected an EventTarget object, but got another value."
        );
      }
      return listeners;
    }
    function defineEventAttributeDescriptor(eventName) {
      return {
        get() {
          const listeners = getListeners(this);
          let node = listeners.get(eventName);
          while (node != null) {
            if (node.listenerType === ATTRIBUTE) {
              return node.listener;
            }
            node = node.next;
          }
          return null;
        },
        set(listener) {
          if (typeof listener !== "function" && !isObject(listener)) {
            listener = null;
          }
          const listeners = getListeners(this);
          let prev = null;
          let node = listeners.get(eventName);
          while (node != null) {
            if (node.listenerType === ATTRIBUTE) {
              if (prev !== null) {
                prev.next = node.next;
              } else if (node.next !== null) {
                listeners.set(eventName, node.next);
              } else {
                listeners.delete(eventName);
              }
            } else {
              prev = node;
            }
            node = node.next;
          }
          if (listener !== null) {
            const newNode = {
              listener,
              listenerType: ATTRIBUTE,
              passive: false,
              once: false,
              next: null
            };
            if (prev === null) {
              listeners.set(eventName, newNode);
            } else {
              prev.next = newNode;
            }
          }
        },
        configurable: true,
        enumerable: true
      };
    }
    function defineEventAttribute(eventTargetPrototype, eventName) {
      Object.defineProperty(
        eventTargetPrototype,
        `on${eventName}`,
        defineEventAttributeDescriptor(eventName)
      );
    }
    function defineCustomEventTarget(eventNames) {
      function CustomEventTarget() {
        EventTarget.call(this);
      }
      CustomEventTarget.prototype = Object.create(EventTarget.prototype, {
        constructor: {
          value: CustomEventTarget,
          configurable: true,
          writable: true
        }
      });
      for (let i = 0; i < eventNames.length; ++i) {
        defineEventAttribute(CustomEventTarget.prototype, eventNames[i]);
      }
      return CustomEventTarget;
    }
    function EventTarget() {
      if (this instanceof EventTarget) {
        listenersMap.set(this, /* @__PURE__ */ new Map());
        return;
      }
      if (arguments.length === 1 && Array.isArray(arguments[0])) {
        return defineCustomEventTarget(arguments[0]);
      }
      if (arguments.length > 0) {
        const types = new Array(arguments.length);
        for (let i = 0; i < arguments.length; ++i) {
          types[i] = arguments[i];
        }
        return defineCustomEventTarget(types);
      }
      throw new TypeError("Cannot call a class as a function");
    }
    EventTarget.prototype = {
      /**
       * Add a given listener to this event target.
       * @param {string} eventName The event name to add.
       * @param {Function} listener The listener to add.
       * @param {boolean|{capture?:boolean,passive?:boolean,once?:boolean}} [options] The options for this listener.
       * @returns {void}
       */
      addEventListener(eventName, listener, options) {
        if (listener == null) {
          return;
        }
        if (typeof listener !== "function" && !isObject(listener)) {
          throw new TypeError("'listener' should be a function or an object.");
        }
        const listeners = getListeners(this);
        const optionsIsObj = isObject(options);
        const capture = optionsIsObj ? Boolean(options.capture) : Boolean(options);
        const listenerType = capture ? CAPTURE : BUBBLE;
        const newNode = {
          listener,
          listenerType,
          passive: optionsIsObj && Boolean(options.passive),
          once: optionsIsObj && Boolean(options.once),
          next: null
        };
        let node = listeners.get(eventName);
        if (node === void 0) {
          listeners.set(eventName, newNode);
          return;
        }
        let prev = null;
        while (node != null) {
          if (node.listener === listener && node.listenerType === listenerType) {
            return;
          }
          prev = node;
          node = node.next;
        }
        prev.next = newNode;
      },
      /**
       * Remove a given listener from this event target.
       * @param {string} eventName The event name to remove.
       * @param {Function} listener The listener to remove.
       * @param {boolean|{capture?:boolean,passive?:boolean,once?:boolean}} [options] The options for this listener.
       * @returns {void}
       */
      removeEventListener(eventName, listener, options) {
        if (listener == null) {
          return;
        }
        const listeners = getListeners(this);
        const capture = isObject(options) ? Boolean(options.capture) : Boolean(options);
        const listenerType = capture ? CAPTURE : BUBBLE;
        let prev = null;
        let node = listeners.get(eventName);
        while (node != null) {
          if (node.listener === listener && node.listenerType === listenerType) {
            if (prev !== null) {
              prev.next = node.next;
            } else if (node.next !== null) {
              listeners.set(eventName, node.next);
            } else {
              listeners.delete(eventName);
            }
            return;
          }
          prev = node;
          node = node.next;
        }
      },
      /**
       * Dispatch a given event.
       * @param {Event|{type:string}} event The event to dispatch.
       * @returns {boolean} `false` if canceled.
       */
      dispatchEvent(event) {
        if (event == null || typeof event.type !== "string") {
          throw new TypeError('"event.type" should be a string.');
        }
        const listeners = getListeners(this);
        const eventName = event.type;
        let node = listeners.get(eventName);
        if (node == null) {
          return true;
        }
        const wrappedEvent = wrapEvent(this, event);
        let prev = null;
        while (node != null) {
          if (node.once) {
            if (prev !== null) {
              prev.next = node.next;
            } else if (node.next !== null) {
              listeners.set(eventName, node.next);
            } else {
              listeners.delete(eventName);
            }
          } else {
            prev = node;
          }
          setPassiveListener(
            wrappedEvent,
            node.passive ? node.listener : null
          );
          if (typeof node.listener === "function") {
            try {
              node.listener.call(this, wrappedEvent);
            } catch (err) {
              if (typeof console !== "undefined" && typeof console.error === "function") {
                console.error(err);
              }
            }
          } else if (node.listenerType !== ATTRIBUTE && typeof node.listener.handleEvent === "function") {
            node.listener.handleEvent(wrappedEvent);
          }
          if (isStopped(wrappedEvent)) {
            break;
          }
          node = node.next;
        }
        setPassiveListener(wrappedEvent, null);
        setEventPhase(wrappedEvent, 0);
        setCurrentTarget(wrappedEvent, null);
        return !wrappedEvent.defaultPrevented;
      }
    };
    Object.defineProperty(EventTarget.prototype, "constructor", {
      value: EventTarget,
      configurable: true,
      writable: true
    });
    if (typeof window !== "undefined" && typeof window.EventTarget !== "undefined") {
      Object.setPrototypeOf(EventTarget.prototype, window.EventTarget.prototype);
    }
    exports2.defineEventAttribute = defineEventAttribute;
    exports2.EventTarget = EventTarget;
    exports2.default = EventTarget;
    module2.exports = EventTarget;
    module2.exports.EventTarget = module2.exports["default"] = EventTarget;
    module2.exports.defineEventAttribute = defineEventAttribute;
  }
});

// ../vscode/node_modules/abort-controller/dist/abort-controller.js
var require_abort_controller = __commonJS({
  "../vscode/node_modules/abort-controller/dist/abort-controller.js"(exports2, module2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var eventTargetShim = require_event_target_shim();
    var AbortSignal = class extends eventTargetShim.EventTarget {
      /**
       * AbortSignal cannot be constructed directly.
       */
      constructor() {
        super();
        throw new TypeError("AbortSignal cannot be constructed directly");
      }
      /**
       * Returns `true` if this `AbortSignal`'s `AbortController` has signaled to abort, and `false` otherwise.
       */
      get aborted() {
        const aborted = abortedFlags.get(this);
        if (typeof aborted !== "boolean") {
          throw new TypeError(`Expected 'this' to be an 'AbortSignal' object, but got ${this === null ? "null" : typeof this}`);
        }
        return aborted;
      }
    };
    eventTargetShim.defineEventAttribute(AbortSignal.prototype, "abort");
    function createAbortSignal() {
      const signal = Object.create(AbortSignal.prototype);
      eventTargetShim.EventTarget.call(signal);
      abortedFlags.set(signal, false);
      return signal;
    }
    function abortSignal(signal) {
      if (abortedFlags.get(signal) !== false) {
        return;
      }
      abortedFlags.set(signal, true);
      signal.dispatchEvent({ type: "abort" });
    }
    var abortedFlags = /* @__PURE__ */ new WeakMap();
    Object.defineProperties(AbortSignal.prototype, {
      aborted: { enumerable: true }
    });
    if (typeof Symbol === "function" && typeof Symbol.toStringTag === "symbol") {
      Object.defineProperty(AbortSignal.prototype, Symbol.toStringTag, {
        configurable: true,
        value: "AbortSignal"
      });
    }
    var AbortController = class {
      /**
       * Initialize this controller.
       */
      constructor() {
        signals.set(this, createAbortSignal());
      }
      /**
       * Returns the `AbortSignal` object associated with this object.
       */
      get signal() {
        return getSignal(this);
      }
      /**
       * Abort and signal to any observers that the associated activity is to be aborted.
       */
      abort() {
        abortSignal(getSignal(this));
      }
    };
    var signals = /* @__PURE__ */ new WeakMap();
    function getSignal(controller) {
      const signal = signals.get(controller);
      if (signal == null) {
        throw new TypeError(`Expected 'this' to be an 'AbortController' object, but got ${controller === null ? "null" : typeof controller}`);
      }
      return signal;
    }
    Object.defineProperties(AbortController.prototype, {
      signal: { enumerable: true },
      abort: { enumerable: true }
    });
    if (typeof Symbol === "function" && typeof Symbol.toStringTag === "symbol") {
      Object.defineProperty(AbortController.prototype, Symbol.toStringTag, {
        configurable: true,
        value: "AbortController"
      });
    }
    exports2.AbortController = AbortController;
    exports2.AbortSignal = AbortSignal;
    exports2.default = AbortController;
    module2.exports = AbortController;
    module2.exports.AbortController = module2.exports["default"] = AbortController;
    module2.exports.AbortSignal = AbortSignal;
  }
});

// ../vscode/node_modules/readable-stream/lib/ours/util.js
var require_util = __commonJS({
  "../vscode/node_modules/readable-stream/lib/ours/util.js"(exports2, module2) {
    "use strict";
    var bufferModule = require("buffer");
    var { format, inspect } = require_inspect();
    var {
      codes: { ERR_INVALID_ARG_TYPE }
    } = require_errors();
    var { kResistStopPropagation, AggregateError, SymbolDispose } = require_primordials();
    var AbortSignal = globalThis.AbortSignal || require_abort_controller().AbortSignal;
    var AbortController = globalThis.AbortController || require_abort_controller().AbortController;
    var AsyncFunction = Object.getPrototypeOf(async function() {
    }).constructor;
    var Blob = globalThis.Blob || bufferModule.Blob;
    var isBlob = typeof Blob !== "undefined" ? function isBlob2(b) {
      return b instanceof Blob;
    } : function isBlob2(b) {
      return false;
    };
    var validateAbortSignal = (signal, name) => {
      if (signal !== void 0 && (signal === null || typeof signal !== "object" || !("aborted" in signal))) {
        throw new ERR_INVALID_ARG_TYPE(name, "AbortSignal", signal);
      }
    };
    var validateFunction = (value, name) => {
      if (typeof value !== "function") {
        throw new ERR_INVALID_ARG_TYPE(name, "Function", value);
      }
    };
    module2.exports = {
      AggregateError,
      kEmptyObject: Object.freeze({}),
      once(callback) {
        let called = false;
        return function(...args) {
          if (called) {
            return;
          }
          called = true;
          callback.apply(this, args);
        };
      },
      createDeferredPromise: function() {
        let resolve3;
        let reject;
        const promise = new Promise((res2, rej) => {
          resolve3 = res2;
          reject = rej;
        });
        return {
          promise,
          resolve: resolve3,
          reject
        };
      },
      promisify(fn) {
        return new Promise((resolve3, reject) => {
          fn((err, ...args) => {
            if (err) {
              return reject(err);
            }
            return resolve3(...args);
          });
        });
      },
      debuglog() {
        return function() {
        };
      },
      format,
      inspect,
      types: {
        isAsyncFunction(fn) {
          return fn instanceof AsyncFunction;
        },
        isArrayBufferView(arr) {
          return ArrayBuffer.isView(arr);
        }
      },
      isBlob,
      deprecate(fn, message) {
        return fn;
      },
      addAbortListener: require("events").addAbortListener || function addAbortListener(signal, listener) {
        if (signal === void 0) {
          throw new ERR_INVALID_ARG_TYPE("signal", "AbortSignal", signal);
        }
        validateAbortSignal(signal, "signal");
        validateFunction(listener, "listener");
        let removeEventListener;
        if (signal.aborted) {
          queueMicrotask(() => listener());
        } else {
          signal.addEventListener("abort", listener, {
            __proto__: null,
            once: true,
            [kResistStopPropagation]: true
          });
          removeEventListener = () => {
            signal.removeEventListener("abort", listener);
          };
        }
        return {
          __proto__: null,
          [SymbolDispose]() {
            var _removeEventListener;
            (_removeEventListener = removeEventListener) === null || _removeEventListener === void 0 ? void 0 : _removeEventListener();
          }
        };
      },
      AbortSignalAny: AbortSignal.any || function AbortSignalAny(signals) {
        if (signals.length === 1) {
          return signals[0];
        }
        const ac = new AbortController();
        const abort = () => ac.abort();
        signals.forEach((signal) => {
          validateAbortSignal(signal, "signals");
          signal.addEventListener("abort", abort, {
            once: true
          });
        });
        ac.signal.addEventListener(
          "abort",
          () => {
            signals.forEach((signal) => signal.removeEventListener("abort", abort));
          },
          {
            once: true
          }
        );
        return ac.signal;
      }
    };
    module2.exports.promisify.custom = /* @__PURE__ */ Symbol.for("nodejs.util.promisify.custom");
  }
});

// ../vscode/node_modules/readable-stream/lib/internal/validators.js
var require_validators = __commonJS({
  "../vscode/node_modules/readable-stream/lib/internal/validators.js"(exports2, module2) {
    "use strict";
    var {
      ArrayIsArray,
      ArrayPrototypeIncludes,
      ArrayPrototypeJoin,
      ArrayPrototypeMap,
      NumberIsInteger,
      NumberIsNaN,
      NumberMAX_SAFE_INTEGER,
      NumberMIN_SAFE_INTEGER,
      NumberParseInt,
      ObjectPrototypeHasOwnProperty,
      RegExpPrototypeExec,
      String: String2,
      StringPrototypeToUpperCase,
      StringPrototypeTrim
    } = require_primordials();
    var {
      hideStackFrames,
      codes: { ERR_SOCKET_BAD_PORT, ERR_INVALID_ARG_TYPE, ERR_INVALID_ARG_VALUE, ERR_OUT_OF_RANGE, ERR_UNKNOWN_SIGNAL }
    } = require_errors();
    var { normalizeEncoding } = require_util();
    var { isAsyncFunction, isArrayBufferView } = require_util().types;
    var signals = {};
    function isInt32(value) {
      return value === (value | 0);
    }
    function isUint32(value) {
      return value === value >>> 0;
    }
    var octalReg = /^[0-7]+$/;
    var modeDesc = "must be a 32-bit unsigned integer or an octal string";
    function parseFileMode(value, name, def) {
      if (typeof value === "undefined") {
        value = def;
      }
      if (typeof value === "string") {
        if (RegExpPrototypeExec(octalReg, value) === null) {
          throw new ERR_INVALID_ARG_VALUE(name, value, modeDesc);
        }
        value = NumberParseInt(value, 8);
      }
      validateUint32(value, name);
      return value;
    }
    var validateInteger = hideStackFrames((value, name, min = NumberMIN_SAFE_INTEGER, max = NumberMAX_SAFE_INTEGER) => {
      if (typeof value !== "number") throw new ERR_INVALID_ARG_TYPE(name, "number", value);
      if (!NumberIsInteger(value)) throw new ERR_OUT_OF_RANGE(name, "an integer", value);
      if (value < min || value > max) throw new ERR_OUT_OF_RANGE(name, `>= ${min} && <= ${max}`, value);
    });
    var validateInt32 = hideStackFrames((value, name, min = -2147483648, max = 2147483647) => {
      if (typeof value !== "number") {
        throw new ERR_INVALID_ARG_TYPE(name, "number", value);
      }
      if (!NumberIsInteger(value)) {
        throw new ERR_OUT_OF_RANGE(name, "an integer", value);
      }
      if (value < min || value > max) {
        throw new ERR_OUT_OF_RANGE(name, `>= ${min} && <= ${max}`, value);
      }
    });
    var validateUint32 = hideStackFrames((value, name, positive = false) => {
      if (typeof value !== "number") {
        throw new ERR_INVALID_ARG_TYPE(name, "number", value);
      }
      if (!NumberIsInteger(value)) {
        throw new ERR_OUT_OF_RANGE(name, "an integer", value);
      }
      const min = positive ? 1 : 0;
      const max = 4294967295;
      if (value < min || value > max) {
        throw new ERR_OUT_OF_RANGE(name, `>= ${min} && <= ${max}`, value);
      }
    });
    function validateString(value, name) {
      if (typeof value !== "string") throw new ERR_INVALID_ARG_TYPE(name, "string", value);
    }
    function validateNumber(value, name, min = void 0, max) {
      if (typeof value !== "number") throw new ERR_INVALID_ARG_TYPE(name, "number", value);
      if (min != null && value < min || max != null && value > max || (min != null || max != null) && NumberIsNaN(value)) {
        throw new ERR_OUT_OF_RANGE(
          name,
          `${min != null ? `>= ${min}` : ""}${min != null && max != null ? " && " : ""}${max != null ? `<= ${max}` : ""}`,
          value
        );
      }
    }
    var validateOneOf = hideStackFrames((value, name, oneOf) => {
      if (!ArrayPrototypeIncludes(oneOf, value)) {
        const allowed = ArrayPrototypeJoin(
          ArrayPrototypeMap(oneOf, (v) => typeof v === "string" ? `'${v}'` : String2(v)),
          ", "
        );
        const reason = "must be one of: " + allowed;
        throw new ERR_INVALID_ARG_VALUE(name, value, reason);
      }
    });
    function validateBoolean(value, name) {
      if (typeof value !== "boolean") throw new ERR_INVALID_ARG_TYPE(name, "boolean", value);
    }
    function getOwnPropertyValueOrDefault(options, key, defaultValue) {
      return options == null || !ObjectPrototypeHasOwnProperty(options, key) ? defaultValue : options[key];
    }
    var validateObject = hideStackFrames((value, name, options = null) => {
      const allowArray = getOwnPropertyValueOrDefault(options, "allowArray", false);
      const allowFunction = getOwnPropertyValueOrDefault(options, "allowFunction", false);
      const nullable = getOwnPropertyValueOrDefault(options, "nullable", false);
      if (!nullable && value === null || !allowArray && ArrayIsArray(value) || typeof value !== "object" && (!allowFunction || typeof value !== "function")) {
        throw new ERR_INVALID_ARG_TYPE(name, "Object", value);
      }
    });
    var validateDictionary = hideStackFrames((value, name) => {
      if (value != null && typeof value !== "object" && typeof value !== "function") {
        throw new ERR_INVALID_ARG_TYPE(name, "a dictionary", value);
      }
    });
    var validateArray = hideStackFrames((value, name, minLength = 0) => {
      if (!ArrayIsArray(value)) {
        throw new ERR_INVALID_ARG_TYPE(name, "Array", value);
      }
      if (value.length < minLength) {
        const reason = `must be longer than ${minLength}`;
        throw new ERR_INVALID_ARG_VALUE(name, value, reason);
      }
    });
    function validateStringArray(value, name) {
      validateArray(value, name);
      for (let i = 0; i < value.length; i++) {
        validateString(value[i], `${name}[${i}]`);
      }
    }
    function validateBooleanArray(value, name) {
      validateArray(value, name);
      for (let i = 0; i < value.length; i++) {
        validateBoolean(value[i], `${name}[${i}]`);
      }
    }
    function validateAbortSignalArray(value, name) {
      validateArray(value, name);
      for (let i = 0; i < value.length; i++) {
        const signal = value[i];
        const indexedName = `${name}[${i}]`;
        if (signal == null) {
          throw new ERR_INVALID_ARG_TYPE(indexedName, "AbortSignal", signal);
        }
        validateAbortSignal(signal, indexedName);
      }
    }
    function validateSignalName(signal, name = "signal") {
      validateString(signal, name);
      if (signals[signal] === void 0) {
        if (signals[StringPrototypeToUpperCase(signal)] !== void 0) {
          throw new ERR_UNKNOWN_SIGNAL(signal + " (signals must use all capital letters)");
        }
        throw new ERR_UNKNOWN_SIGNAL(signal);
      }
    }
    var validateBuffer = hideStackFrames((buffer, name = "buffer") => {
      if (!isArrayBufferView(buffer)) {
        throw new ERR_INVALID_ARG_TYPE(name, ["Buffer", "TypedArray", "DataView"], buffer);
      }
    });
    function validateEncoding(data, encoding) {
      const normalizedEncoding = normalizeEncoding(encoding);
      const length = data.length;
      if (normalizedEncoding === "hex" && length % 2 !== 0) {
        throw new ERR_INVALID_ARG_VALUE("encoding", encoding, `is invalid for data of length ${length}`);
      }
    }
    function validatePort(port, name = "Port", allowZero = true) {
      if (typeof port !== "number" && typeof port !== "string" || typeof port === "string" && StringPrototypeTrim(port).length === 0 || +port !== +port >>> 0 || port > 65535 || port === 0 && !allowZero) {
        throw new ERR_SOCKET_BAD_PORT(name, port, allowZero);
      }
      return port | 0;
    }
    var validateAbortSignal = hideStackFrames((signal, name) => {
      if (signal !== void 0 && (signal === null || typeof signal !== "object" || !("aborted" in signal))) {
        throw new ERR_INVALID_ARG_TYPE(name, "AbortSignal", signal);
      }
    });
    var validateFunction = hideStackFrames((value, name) => {
      if (typeof value !== "function") throw new ERR_INVALID_ARG_TYPE(name, "Function", value);
    });
    var validatePlainFunction = hideStackFrames((value, name) => {
      if (typeof value !== "function" || isAsyncFunction(value)) throw new ERR_INVALID_ARG_TYPE(name, "Function", value);
    });
    var validateUndefined = hideStackFrames((value, name) => {
      if (value !== void 0) throw new ERR_INVALID_ARG_TYPE(name, "undefined", value);
    });
    function validateUnion(value, name, union) {
      if (!ArrayPrototypeIncludes(union, value)) {
        throw new ERR_INVALID_ARG_TYPE(name, `('${ArrayPrototypeJoin(union, "|")}')`, value);
      }
    }
    var linkValueRegExp = /^(?:<[^>]*>)(?:\s*;\s*[^;"\s]+(?:=(")?[^;"\s]*\1)?)*$/;
    function validateLinkHeaderFormat(value, name) {
      if (typeof value === "undefined" || !RegExpPrototypeExec(linkValueRegExp, value)) {
        throw new ERR_INVALID_ARG_VALUE(
          name,
          value,
          'must be an array or string of format "</styles.css>; rel=preload; as=style"'
        );
      }
    }
    function validateLinkHeaderValue(hints) {
      if (typeof hints === "string") {
        validateLinkHeaderFormat(hints, "hints");
        return hints;
      } else if (ArrayIsArray(hints)) {
        const hintsLength = hints.length;
        let result = "";
        if (hintsLength === 0) {
          return result;
        }
        for (let i = 0; i < hintsLength; i++) {
          const link = hints[i];
          validateLinkHeaderFormat(link, "hints");
          result += link;
          if (i !== hintsLength - 1) {
            result += ", ";
          }
        }
        return result;
      }
      throw new ERR_INVALID_ARG_VALUE(
        "hints",
        hints,
        'must be an array or string of format "</styles.css>; rel=preload; as=style"'
      );
    }
    module2.exports = {
      isInt32,
      isUint32,
      parseFileMode,
      validateArray,
      validateStringArray,
      validateBooleanArray,
      validateAbortSignalArray,
      validateBoolean,
      validateBuffer,
      validateDictionary,
      validateEncoding,
      validateFunction,
      validateInt32,
      validateInteger,
      validateNumber,
      validateObject,
      validateOneOf,
      validatePlainFunction,
      validatePort,
      validateSignalName,
      validateString,
      validateUint32,
      validateUndefined,
      validateUnion,
      validateAbortSignal,
      validateLinkHeaderValue
    };
  }
});

// ../vscode/node_modules/process/index.js
var require_process = __commonJS({
  "../vscode/node_modules/process/index.js"(exports2, module2) {
    module2.exports = global.process;
  }
});

// ../vscode/node_modules/readable-stream/lib/internal/shims/process.js
var require_process2 = __commonJS({
  "../vscode/node_modules/readable-stream/lib/internal/shims/process.js"(exports2, module2) {
    "use strict";
    var process2 = ((base, esmKey, keys, isValid) => {
      if (esmKey in base && base[esmKey] === true) {
        let candidate;
        for (const key of keys) {
          if (!(key in base)) {
            continue;
          }
          candidate = base[key];
          if (isValid(candidate)) {
            return candidate;
          }
        }
      }
      return base;
    })(require_process(), "__esModule", ["default", "process"], (candidate) => "nextTick" in candidate);
    module2.exports = process2;
  }
});

// ../vscode/node_modules/readable-stream/lib/internal/streams/utils.js
var require_utils = __commonJS({
  "../vscode/node_modules/readable-stream/lib/internal/streams/utils.js"(exports2, module2) {
    "use strict";
    var { SymbolAsyncIterator, SymbolIterator, SymbolFor } = require_primordials();
    var kIsDestroyed = SymbolFor("nodejs.stream.destroyed");
    var kIsErrored = SymbolFor("nodejs.stream.errored");
    var kIsReadable = SymbolFor("nodejs.stream.readable");
    var kIsWritable = SymbolFor("nodejs.stream.writable");
    var kIsDisturbed = SymbolFor("nodejs.stream.disturbed");
    var kIsClosedPromise = SymbolFor("nodejs.webstream.isClosedPromise");
    var kControllerErrorFunction = SymbolFor("nodejs.webstream.controllerErrorFunction");
    function isReadableNodeStream(obj, strict = false) {
      var _obj$_readableState;
      return !!(obj && typeof obj.pipe === "function" && typeof obj.on === "function" && (!strict || typeof obj.pause === "function" && typeof obj.resume === "function") && (!obj._writableState || ((_obj$_readableState = obj._readableState) === null || _obj$_readableState === void 0 ? void 0 : _obj$_readableState.readable) !== false) && // Duplex
      (!obj._writableState || obj._readableState));
    }
    function isWritableNodeStream(obj) {
      var _obj$_writableState;
      return !!(obj && typeof obj.write === "function" && typeof obj.on === "function" && (!obj._readableState || ((_obj$_writableState = obj._writableState) === null || _obj$_writableState === void 0 ? void 0 : _obj$_writableState.writable) !== false));
    }
    function isDuplexNodeStream(obj) {
      return !!(obj && typeof obj.pipe === "function" && obj._readableState && typeof obj.on === "function" && typeof obj.write === "function");
    }
    function isNodeStream(obj) {
      return obj && (obj._readableState || obj._writableState || typeof obj.write === "function" && typeof obj.on === "function" || typeof obj.pipe === "function" && typeof obj.on === "function");
    }
    function isReadableStream(obj) {
      return !!(obj && !isNodeStream(obj) && typeof obj.pipeThrough === "function" && typeof obj.getReader === "function" && typeof obj.cancel === "function");
    }
    function isWritableStream(obj) {
      return !!(obj && !isNodeStream(obj) && typeof obj.getWriter === "function" && typeof obj.abort === "function");
    }
    function isTransformStream(obj) {
      return !!(obj && !isNodeStream(obj) && typeof obj.readable === "object" && typeof obj.writable === "object");
    }
    function isWebStream(obj) {
      return isReadableStream(obj) || isWritableStream(obj) || isTransformStream(obj);
    }
    function isIterable(obj, isAsync) {
      if (obj == null) return false;
      if (isAsync === true) return typeof obj[SymbolAsyncIterator] === "function";
      if (isAsync === false) return typeof obj[SymbolIterator] === "function";
      return typeof obj[SymbolAsyncIterator] === "function" || typeof obj[SymbolIterator] === "function";
    }
    function isDestroyed(stream) {
      if (!isNodeStream(stream)) return null;
      const wState = stream._writableState;
      const rState = stream._readableState;
      const state = wState || rState;
      return !!(stream.destroyed || stream[kIsDestroyed] || state !== null && state !== void 0 && state.destroyed);
    }
    function isWritableEnded(stream) {
      if (!isWritableNodeStream(stream)) return null;
      if (stream.writableEnded === true) return true;
      const wState = stream._writableState;
      if (wState !== null && wState !== void 0 && wState.errored) return false;
      if (typeof (wState === null || wState === void 0 ? void 0 : wState.ended) !== "boolean") return null;
      return wState.ended;
    }
    function isWritableFinished(stream, strict) {
      if (!isWritableNodeStream(stream)) return null;
      if (stream.writableFinished === true) return true;
      const wState = stream._writableState;
      if (wState !== null && wState !== void 0 && wState.errored) return false;
      if (typeof (wState === null || wState === void 0 ? void 0 : wState.finished) !== "boolean") return null;
      return !!(wState.finished || strict === false && wState.ended === true && wState.length === 0);
    }
    function isReadableEnded(stream) {
      if (!isReadableNodeStream(stream)) return null;
      if (stream.readableEnded === true) return true;
      const rState = stream._readableState;
      if (!rState || rState.errored) return false;
      if (typeof (rState === null || rState === void 0 ? void 0 : rState.ended) !== "boolean") return null;
      return rState.ended;
    }
    function isReadableFinished(stream, strict) {
      if (!isReadableNodeStream(stream)) return null;
      const rState = stream._readableState;
      if (rState !== null && rState !== void 0 && rState.errored) return false;
      if (typeof (rState === null || rState === void 0 ? void 0 : rState.endEmitted) !== "boolean") return null;
      return !!(rState.endEmitted || strict === false && rState.ended === true && rState.length === 0);
    }
    function isReadable(stream) {
      if (stream && stream[kIsReadable] != null) return stream[kIsReadable];
      if (typeof (stream === null || stream === void 0 ? void 0 : stream.readable) !== "boolean") return null;
      if (isDestroyed(stream)) return false;
      return isReadableNodeStream(stream) && stream.readable && !isReadableFinished(stream);
    }
    function isWritable(stream) {
      if (stream && stream[kIsWritable] != null) return stream[kIsWritable];
      if (typeof (stream === null || stream === void 0 ? void 0 : stream.writable) !== "boolean") return null;
      if (isDestroyed(stream)) return false;
      return isWritableNodeStream(stream) && stream.writable && !isWritableEnded(stream);
    }
    function isFinished(stream, opts) {
      if (!isNodeStream(stream)) {
        return null;
      }
      if (isDestroyed(stream)) {
        return true;
      }
      if ((opts === null || opts === void 0 ? void 0 : opts.readable) !== false && isReadable(stream)) {
        return false;
      }
      if ((opts === null || opts === void 0 ? void 0 : opts.writable) !== false && isWritable(stream)) {
        return false;
      }
      return true;
    }
    function isWritableErrored(stream) {
      var _stream$_writableStat, _stream$_writableStat2;
      if (!isNodeStream(stream)) {
        return null;
      }
      if (stream.writableErrored) {
        return stream.writableErrored;
      }
      return (_stream$_writableStat = (_stream$_writableStat2 = stream._writableState) === null || _stream$_writableStat2 === void 0 ? void 0 : _stream$_writableStat2.errored) !== null && _stream$_writableStat !== void 0 ? _stream$_writableStat : null;
    }
    function isReadableErrored(stream) {
      var _stream$_readableStat, _stream$_readableStat2;
      if (!isNodeStream(stream)) {
        return null;
      }
      if (stream.readableErrored) {
        return stream.readableErrored;
      }
      return (_stream$_readableStat = (_stream$_readableStat2 = stream._readableState) === null || _stream$_readableStat2 === void 0 ? void 0 : _stream$_readableStat2.errored) !== null && _stream$_readableStat !== void 0 ? _stream$_readableStat : null;
    }
    function isClosed(stream) {
      if (!isNodeStream(stream)) {
        return null;
      }
      if (typeof stream.closed === "boolean") {
        return stream.closed;
      }
      const wState = stream._writableState;
      const rState = stream._readableState;
      if (typeof (wState === null || wState === void 0 ? void 0 : wState.closed) === "boolean" || typeof (rState === null || rState === void 0 ? void 0 : rState.closed) === "boolean") {
        return (wState === null || wState === void 0 ? void 0 : wState.closed) || (rState === null || rState === void 0 ? void 0 : rState.closed);
      }
      if (typeof stream._closed === "boolean" && isOutgoingMessage(stream)) {
        return stream._closed;
      }
      return null;
    }
    function isOutgoingMessage(stream) {
      return typeof stream._closed === "boolean" && typeof stream._defaultKeepAlive === "boolean" && typeof stream._removedConnection === "boolean" && typeof stream._removedContLen === "boolean";
    }
    function isServerResponse(stream) {
      return typeof stream._sent100 === "boolean" && isOutgoingMessage(stream);
    }
    function isServerRequest(stream) {
      var _stream$req;
      return typeof stream._consuming === "boolean" && typeof stream._dumped === "boolean" && ((_stream$req = stream.req) === null || _stream$req === void 0 ? void 0 : _stream$req.upgradeOrConnect) === void 0;
    }
    function willEmitClose(stream) {
      if (!isNodeStream(stream)) return null;
      const wState = stream._writableState;
      const rState = stream._readableState;
      const state = wState || rState;
      return !state && isServerResponse(stream) || !!(state && state.autoDestroy && state.emitClose && state.closed === false);
    }
    function isDisturbed(stream) {
      var _stream$kIsDisturbed;
      return !!(stream && ((_stream$kIsDisturbed = stream[kIsDisturbed]) !== null && _stream$kIsDisturbed !== void 0 ? _stream$kIsDisturbed : stream.readableDidRead || stream.readableAborted));
    }
    function isErrored(stream) {
      var _ref, _ref2, _ref3, _ref4, _ref5, _stream$kIsErrored, _stream$_readableStat3, _stream$_writableStat3, _stream$_readableStat4, _stream$_writableStat4;
      return !!(stream && ((_ref = (_ref2 = (_ref3 = (_ref4 = (_ref5 = (_stream$kIsErrored = stream[kIsErrored]) !== null && _stream$kIsErrored !== void 0 ? _stream$kIsErrored : stream.readableErrored) !== null && _ref5 !== void 0 ? _ref5 : stream.writableErrored) !== null && _ref4 !== void 0 ? _ref4 : (_stream$_readableStat3 = stream._readableState) === null || _stream$_readableStat3 === void 0 ? void 0 : _stream$_readableStat3.errorEmitted) !== null && _ref3 !== void 0 ? _ref3 : (_stream$_writableStat3 = stream._writableState) === null || _stream$_writableStat3 === void 0 ? void 0 : _stream$_writableStat3.errorEmitted) !== null && _ref2 !== void 0 ? _ref2 : (_stream$_readableStat4 = stream._readableState) === null || _stream$_readableStat4 === void 0 ? void 0 : _stream$_readableStat4.errored) !== null && _ref !== void 0 ? _ref : (_stream$_writableStat4 = stream._writableState) === null || _stream$_writableStat4 === void 0 ? void 0 : _stream$_writableStat4.errored));
    }
    module2.exports = {
      isDestroyed,
      kIsDestroyed,
      isDisturbed,
      kIsDisturbed,
      isErrored,
      kIsErrored,
      isReadable,
      kIsReadable,
      kIsClosedPromise,
      kControllerErrorFunction,
      kIsWritable,
      isClosed,
      isDuplexNodeStream,
      isFinished,
      isIterable,
      isReadableNodeStream,
      isReadableStream,
      isReadableEnded,
      isReadableFinished,
      isReadableErrored,
      isNodeStream,
      isWebStream,
      isWritable,
      isWritableNodeStream,
      isWritableStream,
      isWritableEnded,
      isWritableFinished,
      isWritableErrored,
      isServerRequest,
      isServerResponse,
      willEmitClose,
      isTransformStream
    };
  }
});

// ../vscode/node_modules/readable-stream/lib/internal/streams/end-of-stream.js
var require_end_of_stream = __commonJS({
  "../vscode/node_modules/readable-stream/lib/internal/streams/end-of-stream.js"(exports2, module2) {
    "use strict";
    var process2 = require_process2();
    var { AbortError, codes } = require_errors();
    var { ERR_INVALID_ARG_TYPE, ERR_STREAM_PREMATURE_CLOSE } = codes;
    var { kEmptyObject, once } = require_util();
    var { validateAbortSignal, validateFunction, validateObject, validateBoolean } = require_validators();
    var { Promise: Promise2, PromisePrototypeThen, SymbolDispose } = require_primordials();
    var {
      isClosed,
      isReadable,
      isReadableNodeStream,
      isReadableStream,
      isReadableFinished,
      isReadableErrored,
      isWritable,
      isWritableNodeStream,
      isWritableStream,
      isWritableFinished,
      isWritableErrored,
      isNodeStream,
      willEmitClose: _willEmitClose,
      kIsClosedPromise
    } = require_utils();
    var addAbortListener;
    function isRequest(stream) {
      return stream.setHeader && typeof stream.abort === "function";
    }
    var nop = () => {
    };
    function eos(stream, options, callback) {
      var _options$readable, _options$writable;
      if (arguments.length === 2) {
        callback = options;
        options = kEmptyObject;
      } else if (options == null) {
        options = kEmptyObject;
      } else {
        validateObject(options, "options");
      }
      validateFunction(callback, "callback");
      validateAbortSignal(options.signal, "options.signal");
      callback = once(callback);
      if (isReadableStream(stream) || isWritableStream(stream)) {
        return eosWeb(stream, options, callback);
      }
      if (!isNodeStream(stream)) {
        throw new ERR_INVALID_ARG_TYPE("stream", ["ReadableStream", "WritableStream", "Stream"], stream);
      }
      const readable = (_options$readable = options.readable) !== null && _options$readable !== void 0 ? _options$readable : isReadableNodeStream(stream);
      const writable = (_options$writable = options.writable) !== null && _options$writable !== void 0 ? _options$writable : isWritableNodeStream(stream);
      const wState = stream._writableState;
      const rState = stream._readableState;
      const onlegacyfinish = () => {
        if (!stream.writable) {
          onfinish();
        }
      };
      let willEmitClose = _willEmitClose(stream) && isReadableNodeStream(stream) === readable && isWritableNodeStream(stream) === writable;
      let writableFinished = isWritableFinished(stream, false);
      const onfinish = () => {
        writableFinished = true;
        if (stream.destroyed) {
          willEmitClose = false;
        }
        if (willEmitClose && (!stream.readable || readable)) {
          return;
        }
        if (!readable || readableFinished) {
          callback.call(stream);
        }
      };
      let readableFinished = isReadableFinished(stream, false);
      const onend = () => {
        readableFinished = true;
        if (stream.destroyed) {
          willEmitClose = false;
        }
        if (willEmitClose && (!stream.writable || writable)) {
          return;
        }
        if (!writable || writableFinished) {
          callback.call(stream);
        }
      };
      const onerror = (err) => {
        callback.call(stream, err);
      };
      let closed = isClosed(stream);
      const onclose = () => {
        closed = true;
        const errored = isWritableErrored(stream) || isReadableErrored(stream);
        if (errored && typeof errored !== "boolean") {
          return callback.call(stream, errored);
        }
        if (readable && !readableFinished && isReadableNodeStream(stream, true)) {
          if (!isReadableFinished(stream, false)) return callback.call(stream, new ERR_STREAM_PREMATURE_CLOSE());
        }
        if (writable && !writableFinished) {
          if (!isWritableFinished(stream, false)) return callback.call(stream, new ERR_STREAM_PREMATURE_CLOSE());
        }
        callback.call(stream);
      };
      const onclosed = () => {
        closed = true;
        const errored = isWritableErrored(stream) || isReadableErrored(stream);
        if (errored && typeof errored !== "boolean") {
          return callback.call(stream, errored);
        }
        callback.call(stream);
      };
      const onrequest = () => {
        stream.req.on("finish", onfinish);
      };
      if (isRequest(stream)) {
        stream.on("complete", onfinish);
        if (!willEmitClose) {
          stream.on("abort", onclose);
        }
        if (stream.req) {
          onrequest();
        } else {
          stream.on("request", onrequest);
        }
      } else if (writable && !wState) {
        stream.on("end", onlegacyfinish);
        stream.on("close", onlegacyfinish);
      }
      if (!willEmitClose && typeof stream.aborted === "boolean") {
        stream.on("aborted", onclose);
      }
      stream.on("end", onend);
      stream.on("finish", onfinish);
      if (options.error !== false) {
        stream.on("error", onerror);
      }
      stream.on("close", onclose);
      if (closed) {
        process2.nextTick(onclose);
      } else if (wState !== null && wState !== void 0 && wState.errorEmitted || rState !== null && rState !== void 0 && rState.errorEmitted) {
        if (!willEmitClose) {
          process2.nextTick(onclosed);
        }
      } else if (!readable && (!willEmitClose || isReadable(stream)) && (writableFinished || isWritable(stream) === false)) {
        process2.nextTick(onclosed);
      } else if (!writable && (!willEmitClose || isWritable(stream)) && (readableFinished || isReadable(stream) === false)) {
        process2.nextTick(onclosed);
      } else if (rState && stream.req && stream.aborted) {
        process2.nextTick(onclosed);
      }
      const cleanup = () => {
        callback = nop;
        stream.removeListener("aborted", onclose);
        stream.removeListener("complete", onfinish);
        stream.removeListener("abort", onclose);
        stream.removeListener("request", onrequest);
        if (stream.req) stream.req.removeListener("finish", onfinish);
        stream.removeListener("end", onlegacyfinish);
        stream.removeListener("close", onlegacyfinish);
        stream.removeListener("finish", onfinish);
        stream.removeListener("end", onend);
        stream.removeListener("error", onerror);
        stream.removeListener("close", onclose);
      };
      if (options.signal && !closed) {
        const abort = () => {
          const endCallback = callback;
          cleanup();
          endCallback.call(
            stream,
            new AbortError(void 0, {
              cause: options.signal.reason
            })
          );
        };
        if (options.signal.aborted) {
          process2.nextTick(abort);
        } else {
          addAbortListener = addAbortListener || require_util().addAbortListener;
          const disposable = addAbortListener(options.signal, abort);
          const originalCallback = callback;
          callback = once((...args) => {
            disposable[SymbolDispose]();
            originalCallback.apply(stream, args);
          });
        }
      }
      return cleanup;
    }
    function eosWeb(stream, options, callback) {
      let isAborted = false;
      let abort = nop;
      if (options.signal) {
        abort = () => {
          isAborted = true;
          callback.call(
            stream,
            new AbortError(void 0, {
              cause: options.signal.reason
            })
          );
        };
        if (options.signal.aborted) {
          process2.nextTick(abort);
        } else {
          addAbortListener = addAbortListener || require_util().addAbortListener;
          const disposable = addAbortListener(options.signal, abort);
          const originalCallback = callback;
          callback = once((...args) => {
            disposable[SymbolDispose]();
            originalCallback.apply(stream, args);
          });
        }
      }
      const resolverFn = (...args) => {
        if (!isAborted) {
          process2.nextTick(() => callback.apply(stream, args));
        }
      };
      PromisePrototypeThen(stream[kIsClosedPromise].promise, resolverFn, resolverFn);
      return nop;
    }
    function finished(stream, opts) {
      var _opts;
      let autoCleanup = false;
      if (opts === null) {
        opts = kEmptyObject;
      }
      if ((_opts = opts) !== null && _opts !== void 0 && _opts.cleanup) {
        validateBoolean(opts.cleanup, "cleanup");
        autoCleanup = opts.cleanup;
      }
      return new Promise2((resolve3, reject) => {
        const cleanup = eos(stream, opts, (err) => {
          if (autoCleanup) {
            cleanup();
          }
          if (err) {
            reject(err);
          } else {
            resolve3();
          }
        });
      });
    }
    module2.exports = eos;
    module2.exports.finished = finished;
  }
});

// ../vscode/node_modules/readable-stream/lib/internal/streams/destroy.js
var require_destroy = __commonJS({
  "../vscode/node_modules/readable-stream/lib/internal/streams/destroy.js"(exports2, module2) {
    "use strict";
    var process2 = require_process2();
    var {
      aggregateTwoErrors,
      codes: { ERR_MULTIPLE_CALLBACK },
      AbortError
    } = require_errors();
    var { Symbol: Symbol2 } = require_primordials();
    var { kIsDestroyed, isDestroyed, isFinished, isServerRequest } = require_utils();
    var kDestroy = Symbol2("kDestroy");
    var kConstruct = Symbol2("kConstruct");
    function checkError(err, w, r) {
      if (err) {
        err.stack;
        if (w && !w.errored) {
          w.errored = err;
        }
        if (r && !r.errored) {
          r.errored = err;
        }
      }
    }
    function destroy(err, cb) {
      const r = this._readableState;
      const w = this._writableState;
      const s = w || r;
      if (w !== null && w !== void 0 && w.destroyed || r !== null && r !== void 0 && r.destroyed) {
        if (typeof cb === "function") {
          cb();
        }
        return this;
      }
      checkError(err, w, r);
      if (w) {
        w.destroyed = true;
      }
      if (r) {
        r.destroyed = true;
      }
      if (!s.constructed) {
        this.once(kDestroy, function(er) {
          _destroy(this, aggregateTwoErrors(er, err), cb);
        });
      } else {
        _destroy(this, err, cb);
      }
      return this;
    }
    function _destroy(self, err, cb) {
      let called = false;
      function onDestroy(err2) {
        if (called) {
          return;
        }
        called = true;
        const r = self._readableState;
        const w = self._writableState;
        checkError(err2, w, r);
        if (w) {
          w.closed = true;
        }
        if (r) {
          r.closed = true;
        }
        if (typeof cb === "function") {
          cb(err2);
        }
        if (err2) {
          process2.nextTick(emitErrorCloseNT, self, err2);
        } else {
          process2.nextTick(emitCloseNT, self);
        }
      }
      try {
        self._destroy(err || null, onDestroy);
      } catch (err2) {
        onDestroy(err2);
      }
    }
    function emitErrorCloseNT(self, err) {
      emitErrorNT(self, err);
      emitCloseNT(self);
    }
    function emitCloseNT(self) {
      const r = self._readableState;
      const w = self._writableState;
      if (w) {
        w.closeEmitted = true;
      }
      if (r) {
        r.closeEmitted = true;
      }
      if (w !== null && w !== void 0 && w.emitClose || r !== null && r !== void 0 && r.emitClose) {
        self.emit("close");
      }
    }
    function emitErrorNT(self, err) {
      const r = self._readableState;
      const w = self._writableState;
      if (w !== null && w !== void 0 && w.errorEmitted || r !== null && r !== void 0 && r.errorEmitted) {
        return;
      }
      if (w) {
        w.errorEmitted = true;
      }
      if (r) {
        r.errorEmitted = true;
      }
      self.emit("error", err);
    }
    function undestroy() {
      const r = this._readableState;
      const w = this._writableState;
      if (r) {
        r.constructed = true;
        r.closed = false;
        r.closeEmitted = false;
        r.destroyed = false;
        r.errored = null;
        r.errorEmitted = false;
        r.reading = false;
        r.ended = r.readable === false;
        r.endEmitted = r.readable === false;
      }
      if (w) {
        w.constructed = true;
        w.destroyed = false;
        w.closed = false;
        w.closeEmitted = false;
        w.errored = null;
        w.errorEmitted = false;
        w.finalCalled = false;
        w.prefinished = false;
        w.ended = w.writable === false;
        w.ending = w.writable === false;
        w.finished = w.writable === false;
      }
    }
    function errorOrDestroy(stream, err, sync) {
      const r = stream._readableState;
      const w = stream._writableState;
      if (w !== null && w !== void 0 && w.destroyed || r !== null && r !== void 0 && r.destroyed) {
        return this;
      }
      if (r !== null && r !== void 0 && r.autoDestroy || w !== null && w !== void 0 && w.autoDestroy)
        stream.destroy(err);
      else if (err) {
        err.stack;
        if (w && !w.errored) {
          w.errored = err;
        }
        if (r && !r.errored) {
          r.errored = err;
        }
        if (sync) {
          process2.nextTick(emitErrorNT, stream, err);
        } else {
          emitErrorNT(stream, err);
        }
      }
    }
    function construct(stream, cb) {
      if (typeof stream._construct !== "function") {
        return;
      }
      const r = stream._readableState;
      const w = stream._writableState;
      if (r) {
        r.constructed = false;
      }
      if (w) {
        w.constructed = false;
      }
      stream.once(kConstruct, cb);
      if (stream.listenerCount(kConstruct) > 1) {
        return;
      }
      process2.nextTick(constructNT, stream);
    }
    function constructNT(stream) {
      let called = false;
      function onConstruct(err) {
        if (called) {
          errorOrDestroy(stream, err !== null && err !== void 0 ? err : new ERR_MULTIPLE_CALLBACK());
          return;
        }
        called = true;
        const r = stream._readableState;
        const w = stream._writableState;
        const s = w || r;
        if (r) {
          r.constructed = true;
        }
        if (w) {
          w.constructed = true;
        }
        if (s.destroyed) {
          stream.emit(kDestroy, err);
        } else if (err) {
          errorOrDestroy(stream, err, true);
        } else {
          process2.nextTick(emitConstructNT, stream);
        }
      }
      try {
        stream._construct((err) => {
          process2.nextTick(onConstruct, err);
        });
      } catch (err) {
        process2.nextTick(onConstruct, err);
      }
    }
    function emitConstructNT(stream) {
      stream.emit(kConstruct);
    }
    function isRequest(stream) {
      return (stream === null || stream === void 0 ? void 0 : stream.setHeader) && typeof stream.abort === "function";
    }
    function emitCloseLegacy(stream) {
      stream.emit("close");
    }
    function emitErrorCloseLegacy(stream, err) {
      stream.emit("error", err);
      process2.nextTick(emitCloseLegacy, stream);
    }
    function destroyer(stream, err) {
      if (!stream || isDestroyed(stream)) {
        return;
      }
      if (!err && !isFinished(stream)) {
        err = new AbortError();
      }
      if (isServerRequest(stream)) {
        stream.socket = null;
        stream.destroy(err);
      } else if (isRequest(stream)) {
        stream.abort();
      } else if (isRequest(stream.req)) {
        stream.req.abort();
      } else if (typeof stream.destroy === "function") {
        stream.destroy(err);
      } else if (typeof stream.close === "function") {
        stream.close();
      } else if (err) {
        process2.nextTick(emitErrorCloseLegacy, stream, err);
      } else {
        process2.nextTick(emitCloseLegacy, stream);
      }
      if (!stream.destroyed) {
        stream[kIsDestroyed] = true;
      }
    }
    module2.exports = {
      construct,
      destroyer,
      destroy,
      undestroy,
      errorOrDestroy
    };
  }
});

// ../vscode/node_modules/readable-stream/lib/internal/streams/legacy.js
var require_legacy = __commonJS({
  "../vscode/node_modules/readable-stream/lib/internal/streams/legacy.js"(exports2, module2) {
    "use strict";
    var { ArrayIsArray, ObjectSetPrototypeOf } = require_primordials();
    var { EventEmitter: EE } = require("events");
    function Stream(opts) {
      EE.call(this, opts);
    }
    ObjectSetPrototypeOf(Stream.prototype, EE.prototype);
    ObjectSetPrototypeOf(Stream, EE);
    Stream.prototype.pipe = function(dest, options) {
      const source = this;
      function ondata(chunk) {
        if (dest.writable && dest.write(chunk) === false && source.pause) {
          source.pause();
        }
      }
      source.on("data", ondata);
      function ondrain() {
        if (source.readable && source.resume) {
          source.resume();
        }
      }
      dest.on("drain", ondrain);
      if (!dest._isStdio && (!options || options.end !== false)) {
        source.on("end", onend);
        source.on("close", onclose);
      }
      let didOnEnd = false;
      function onend() {
        if (didOnEnd) return;
        didOnEnd = true;
        dest.end();
      }
      function onclose() {
        if (didOnEnd) return;
        didOnEnd = true;
        if (typeof dest.destroy === "function") dest.destroy();
      }
      function onerror(er) {
        var _this$listenerCount;
        cleanup();
        if (((_this$listenerCount = this.listenerCount) === null || _this$listenerCount === void 0 ? void 0 : _this$listenerCount.call(this, "error")) === 0) {
          this.emit("error", er);
        }
      }
      prependListener(source, "error", onerror);
      prependListener(dest, "error", onerror);
      function cleanup() {
        source.removeListener("data", ondata);
        dest.removeListener("drain", ondrain);
        source.removeListener("end", onend);
        source.removeListener("close", onclose);
        source.removeListener("error", onerror);
        dest.removeListener("error", onerror);
        source.removeListener("end", cleanup);
        source.removeListener("close", cleanup);
        dest.removeListener("close", cleanup);
      }
      source.on("end", cleanup);
      source.on("close", cleanup);
      dest.on("close", cleanup);
      dest.emit("pipe", source);
      return dest;
    };
    function prependListener(emitter, event, fn) {
      if (typeof emitter.prependListener === "function") return emitter.prependListener(event, fn);
      if (!emitter._events || !emitter._events[event]) emitter.on(event, fn);
      else if (ArrayIsArray(emitter._events[event])) emitter._events[event].unshift(fn);
      else emitter._events[event] = [fn, emitter._events[event]];
    }
    module2.exports = {
      Stream,
      prependListener
    };
  }
});

// ../vscode/node_modules/readable-stream/lib/internal/streams/add-abort-signal.js
var require_add_abort_signal = __commonJS({
  "../vscode/node_modules/readable-stream/lib/internal/streams/add-abort-signal.js"(exports2, module2) {
    "use strict";
    var { SymbolDispose } = require_primordials();
    var { AbortError, codes } = require_errors();
    var { isNodeStream, isWebStream, kControllerErrorFunction } = require_utils();
    var eos = require_end_of_stream();
    var { ERR_INVALID_ARG_TYPE } = codes;
    var addAbortListener;
    var validateAbortSignal = (signal, name) => {
      if (typeof signal !== "object" || !("aborted" in signal)) {
        throw new ERR_INVALID_ARG_TYPE(name, "AbortSignal", signal);
      }
    };
    module2.exports.addAbortSignal = function addAbortSignal(signal, stream) {
      validateAbortSignal(signal, "signal");
      if (!isNodeStream(stream) && !isWebStream(stream)) {
        throw new ERR_INVALID_ARG_TYPE("stream", ["ReadableStream", "WritableStream", "Stream"], stream);
      }
      return module2.exports.addAbortSignalNoValidate(signal, stream);
    };
    module2.exports.addAbortSignalNoValidate = function(signal, stream) {
      if (typeof signal !== "object" || !("aborted" in signal)) {
        return stream;
      }
      const onAbort = isNodeStream(stream) ? () => {
        stream.destroy(
          new AbortError(void 0, {
            cause: signal.reason
          })
        );
      } : () => {
        stream[kControllerErrorFunction](
          new AbortError(void 0, {
            cause: signal.reason
          })
        );
      };
      if (signal.aborted) {
        onAbort();
      } else {
        addAbortListener = addAbortListener || require_util().addAbortListener;
        const disposable = addAbortListener(signal, onAbort);
        eos(stream, disposable[SymbolDispose]);
      }
      return stream;
    };
  }
});

// ../vscode/node_modules/readable-stream/lib/internal/streams/buffer_list.js
var require_buffer_list = __commonJS({
  "../vscode/node_modules/readable-stream/lib/internal/streams/buffer_list.js"(exports2, module2) {
    "use strict";
    var { StringPrototypeSlice, SymbolIterator, TypedArrayPrototypeSet, Uint8Array: Uint8Array2 } = require_primordials();
    var { Buffer: Buffer2 } = require("buffer");
    var { inspect } = require_util();
    module2.exports = class BufferList {
      constructor() {
        this.head = null;
        this.tail = null;
        this.length = 0;
      }
      push(v) {
        const entry = {
          data: v,
          next: null
        };
        if (this.length > 0) this.tail.next = entry;
        else this.head = entry;
        this.tail = entry;
        ++this.length;
      }
      unshift(v) {
        const entry = {
          data: v,
          next: this.head
        };
        if (this.length === 0) this.tail = entry;
        this.head = entry;
        ++this.length;
      }
      shift() {
        if (this.length === 0) return;
        const ret = this.head.data;
        if (this.length === 1) this.head = this.tail = null;
        else this.head = this.head.next;
        --this.length;
        return ret;
      }
      clear() {
        this.head = this.tail = null;
        this.length = 0;
      }
      join(s) {
        if (this.length === 0) return "";
        let p = this.head;
        let ret = "" + p.data;
        while ((p = p.next) !== null) ret += s + p.data;
        return ret;
      }
      concat(n) {
        if (this.length === 0) return Buffer2.alloc(0);
        const ret = Buffer2.allocUnsafe(n >>> 0);
        let p = this.head;
        let i = 0;
        while (p) {
          TypedArrayPrototypeSet(ret, p.data, i);
          i += p.data.length;
          p = p.next;
        }
        return ret;
      }
      // Consumes a specified amount of bytes or characters from the buffered data.
      consume(n, hasStrings) {
        const data = this.head.data;
        if (n < data.length) {
          const slice = data.slice(0, n);
          this.head.data = data.slice(n);
          return slice;
        }
        if (n === data.length) {
          return this.shift();
        }
        return hasStrings ? this._getString(n) : this._getBuffer(n);
      }
      first() {
        return this.head.data;
      }
      *[SymbolIterator]() {
        for (let p = this.head; p; p = p.next) {
          yield p.data;
        }
      }
      // Consumes a specified amount of characters from the buffered data.
      _getString(n) {
        let ret = "";
        let p = this.head;
        let c = 0;
        do {
          const str = p.data;
          if (n > str.length) {
            ret += str;
            n -= str.length;
          } else {
            if (n === str.length) {
              ret += str;
              ++c;
              if (p.next) this.head = p.next;
              else this.head = this.tail = null;
            } else {
              ret += StringPrototypeSlice(str, 0, n);
              this.head = p;
              p.data = StringPrototypeSlice(str, n);
            }
            break;
          }
          ++c;
        } while ((p = p.next) !== null);
        this.length -= c;
        return ret;
      }
      // Consumes a specified amount of bytes from the buffered data.
      _getBuffer(n) {
        const ret = Buffer2.allocUnsafe(n);
        const retLen = n;
        let p = this.head;
        let c = 0;
        do {
          const buf = p.data;
          if (n > buf.length) {
            TypedArrayPrototypeSet(ret, buf, retLen - n);
            n -= buf.length;
          } else {
            if (n === buf.length) {
              TypedArrayPrototypeSet(ret, buf, retLen - n);
              ++c;
              if (p.next) this.head = p.next;
              else this.head = this.tail = null;
            } else {
              TypedArrayPrototypeSet(ret, new Uint8Array2(buf.buffer, buf.byteOffset, n), retLen - n);
              this.head = p;
              p.data = buf.slice(n);
            }
            break;
          }
          ++c;
        } while ((p = p.next) !== null);
        this.length -= c;
        return ret;
      }
      // Make sure the linked list only shows the minimal necessary information.
      [/* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom")](_, options) {
        return inspect(this, {
          ...options,
          // Only inspect one level.
          depth: 0,
          // It should not recurse.
          customInspect: false
        });
      }
    };
  }
});

// ../vscode/node_modules/readable-stream/lib/internal/streams/state.js
var require_state = __commonJS({
  "../vscode/node_modules/readable-stream/lib/internal/streams/state.js"(exports2, module2) {
    "use strict";
    var { MathFloor, NumberIsInteger } = require_primordials();
    var { validateInteger } = require_validators();
    var { ERR_INVALID_ARG_VALUE } = require_errors().codes;
    var defaultHighWaterMarkBytes = 16 * 1024;
    var defaultHighWaterMarkObjectMode = 16;
    function highWaterMarkFrom(options, isDuplex, duplexKey) {
      return options.highWaterMark != null ? options.highWaterMark : isDuplex ? options[duplexKey] : null;
    }
    function getDefaultHighWaterMark(objectMode) {
      return objectMode ? defaultHighWaterMarkObjectMode : defaultHighWaterMarkBytes;
    }
    function setDefaultHighWaterMark(objectMode, value) {
      validateInteger(value, "value", 0);
      if (objectMode) {
        defaultHighWaterMarkObjectMode = value;
      } else {
        defaultHighWaterMarkBytes = value;
      }
    }
    function getHighWaterMark(state, options, duplexKey, isDuplex) {
      const hwm = highWaterMarkFrom(options, isDuplex, duplexKey);
      if (hwm != null) {
        if (!NumberIsInteger(hwm) || hwm < 0) {
          const name = isDuplex ? `options.${duplexKey}` : "options.highWaterMark";
          throw new ERR_INVALID_ARG_VALUE(name, hwm);
        }
        return MathFloor(hwm);
      }
      return getDefaultHighWaterMark(state.objectMode);
    }
    module2.exports = {
      getHighWaterMark,
      getDefaultHighWaterMark,
      setDefaultHighWaterMark
    };
  }
});

// ../vscode/node_modules/safe-buffer/index.js
var require_safe_buffer = __commonJS({
  "../vscode/node_modules/safe-buffer/index.js"(exports2, module2) {
    var buffer = require("buffer");
    var Buffer2 = buffer.Buffer;
    function copyProps(src, dst) {
      for (var key in src) {
        dst[key] = src[key];
      }
    }
    if (Buffer2.from && Buffer2.alloc && Buffer2.allocUnsafe && Buffer2.allocUnsafeSlow) {
      module2.exports = buffer;
    } else {
      copyProps(buffer, exports2);
      exports2.Buffer = SafeBuffer;
    }
    function SafeBuffer(arg, encodingOrOffset, length) {
      return Buffer2(arg, encodingOrOffset, length);
    }
    SafeBuffer.prototype = Object.create(Buffer2.prototype);
    copyProps(Buffer2, SafeBuffer);
    SafeBuffer.from = function(arg, encodingOrOffset, length) {
      if (typeof arg === "number") {
        throw new TypeError("Argument must not be a number");
      }
      return Buffer2(arg, encodingOrOffset, length);
    };
    SafeBuffer.alloc = function(size, fill, encoding) {
      if (typeof size !== "number") {
        throw new TypeError("Argument must be a number");
      }
      var buf = Buffer2(size);
      if (fill !== void 0) {
        if (typeof encoding === "string") {
          buf.fill(fill, encoding);
        } else {
          buf.fill(fill);
        }
      } else {
        buf.fill(0);
      }
      return buf;
    };
    SafeBuffer.allocUnsafe = function(size) {
      if (typeof size !== "number") {
        throw new TypeError("Argument must be a number");
      }
      return Buffer2(size);
    };
    SafeBuffer.allocUnsafeSlow = function(size) {
      if (typeof size !== "number") {
        throw new TypeError("Argument must be a number");
      }
      return buffer.SlowBuffer(size);
    };
  }
});

// ../vscode/node_modules/string_decoder/lib/string_decoder.js
var require_string_decoder = __commonJS({
  "../vscode/node_modules/string_decoder/lib/string_decoder.js"(exports2) {
    "use strict";
    var Buffer2 = require_safe_buffer().Buffer;
    var isEncoding = Buffer2.isEncoding || function(encoding) {
      encoding = "" + encoding;
      switch (encoding && encoding.toLowerCase()) {
        case "hex":
        case "utf8":
        case "utf-8":
        case "ascii":
        case "binary":
        case "base64":
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
        case "raw":
          return true;
        default:
          return false;
      }
    };
    function _normalizeEncoding(enc) {
      if (!enc) return "utf8";
      var retried;
      while (true) {
        switch (enc) {
          case "utf8":
          case "utf-8":
            return "utf8";
          case "ucs2":
          case "ucs-2":
          case "utf16le":
          case "utf-16le":
            return "utf16le";
          case "latin1":
          case "binary":
            return "latin1";
          case "base64":
          case "ascii":
          case "hex":
            return enc;
          default:
            if (retried) return;
            enc = ("" + enc).toLowerCase();
            retried = true;
        }
      }
    }
    function normalizeEncoding(enc) {
      var nenc = _normalizeEncoding(enc);
      if (typeof nenc !== "string" && (Buffer2.isEncoding === isEncoding || !isEncoding(enc))) throw new Error("Unknown encoding: " + enc);
      return nenc || enc;
    }
    exports2.StringDecoder = StringDecoder;
    function StringDecoder(encoding) {
      this.encoding = normalizeEncoding(encoding);
      var nb;
      switch (this.encoding) {
        case "utf16le":
          this.text = utf16Text;
          this.end = utf16End;
          nb = 4;
          break;
        case "utf8":
          this.fillLast = utf8FillLast;
          nb = 4;
          break;
        case "base64":
          this.text = base64Text;
          this.end = base64End;
          nb = 3;
          break;
        default:
          this.write = simpleWrite;
          this.end = simpleEnd;
          return;
      }
      this.lastNeed = 0;
      this.lastTotal = 0;
      this.lastChar = Buffer2.allocUnsafe(nb);
    }
    StringDecoder.prototype.write = function(buf) {
      if (buf.length === 0) return "";
      var r;
      var i;
      if (this.lastNeed) {
        r = this.fillLast(buf);
        if (r === void 0) return "";
        i = this.lastNeed;
        this.lastNeed = 0;
      } else {
        i = 0;
      }
      if (i < buf.length) return r ? r + this.text(buf, i) : this.text(buf, i);
      return r || "";
    };
    StringDecoder.prototype.end = utf8End;
    StringDecoder.prototype.text = utf8Text;
    StringDecoder.prototype.fillLast = function(buf) {
      if (this.lastNeed <= buf.length) {
        buf.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, this.lastNeed);
        return this.lastChar.toString(this.encoding, 0, this.lastTotal);
      }
      buf.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, buf.length);
      this.lastNeed -= buf.length;
    };
    function utf8CheckByte(byte) {
      if (byte <= 127) return 0;
      else if (byte >> 5 === 6) return 2;
      else if (byte >> 4 === 14) return 3;
      else if (byte >> 3 === 30) return 4;
      return byte >> 6 === 2 ? -1 : -2;
    }
    function utf8CheckIncomplete(self, buf, i) {
      var j = buf.length - 1;
      if (j < i) return 0;
      var nb = utf8CheckByte(buf[j]);
      if (nb >= 0) {
        if (nb > 0) self.lastNeed = nb - 1;
        return nb;
      }
      if (--j < i || nb === -2) return 0;
      nb = utf8CheckByte(buf[j]);
      if (nb >= 0) {
        if (nb > 0) self.lastNeed = nb - 2;
        return nb;
      }
      if (--j < i || nb === -2) return 0;
      nb = utf8CheckByte(buf[j]);
      if (nb >= 0) {
        if (nb > 0) {
          if (nb === 2) nb = 0;
          else self.lastNeed = nb - 3;
        }
        return nb;
      }
      return 0;
    }
    function utf8CheckExtraBytes(self, buf, p) {
      if ((buf[0] & 192) !== 128) {
        self.lastNeed = 0;
        return "\uFFFD";
      }
      if (self.lastNeed > 1 && buf.length > 1) {
        if ((buf[1] & 192) !== 128) {
          self.lastNeed = 1;
          return "\uFFFD";
        }
        if (self.lastNeed > 2 && buf.length > 2) {
          if ((buf[2] & 192) !== 128) {
            self.lastNeed = 2;
            return "\uFFFD";
          }
        }
      }
    }
    function utf8FillLast(buf) {
      var p = this.lastTotal - this.lastNeed;
      var r = utf8CheckExtraBytes(this, buf, p);
      if (r !== void 0) return r;
      if (this.lastNeed <= buf.length) {
        buf.copy(this.lastChar, p, 0, this.lastNeed);
        return this.lastChar.toString(this.encoding, 0, this.lastTotal);
      }
      buf.copy(this.lastChar, p, 0, buf.length);
      this.lastNeed -= buf.length;
    }
    function utf8Text(buf, i) {
      var total = utf8CheckIncomplete(this, buf, i);
      if (!this.lastNeed) return buf.toString("utf8", i);
      this.lastTotal = total;
      var end = buf.length - (total - this.lastNeed);
      buf.copy(this.lastChar, 0, end);
      return buf.toString("utf8", i, end);
    }
    function utf8End(buf) {
      var r = buf && buf.length ? this.write(buf) : "";
      if (this.lastNeed) return r + "\uFFFD";
      return r;
    }
    function utf16Text(buf, i) {
      if ((buf.length - i) % 2 === 0) {
        var r = buf.toString("utf16le", i);
        if (r) {
          var c = r.charCodeAt(r.length - 1);
          if (c >= 55296 && c <= 56319) {
            this.lastNeed = 2;
            this.lastTotal = 4;
            this.lastChar[0] = buf[buf.length - 2];
            this.lastChar[1] = buf[buf.length - 1];
            return r.slice(0, -1);
          }
        }
        return r;
      }
      this.lastNeed = 1;
      this.lastTotal = 2;
      this.lastChar[0] = buf[buf.length - 1];
      return buf.toString("utf16le", i, buf.length - 1);
    }
    function utf16End(buf) {
      var r = buf && buf.length ? this.write(buf) : "";
      if (this.lastNeed) {
        var end = this.lastTotal - this.lastNeed;
        return r + this.lastChar.toString("utf16le", 0, end);
      }
      return r;
    }
    function base64Text(buf, i) {
      var n = (buf.length - i) % 3;
      if (n === 0) return buf.toString("base64", i);
      this.lastNeed = 3 - n;
      this.lastTotal = 3;
      if (n === 1) {
        this.lastChar[0] = buf[buf.length - 1];
      } else {
        this.lastChar[0] = buf[buf.length - 2];
        this.lastChar[1] = buf[buf.length - 1];
      }
      return buf.toString("base64", i, buf.length - n);
    }
    function base64End(buf) {
      var r = buf && buf.length ? this.write(buf) : "";
      if (this.lastNeed) return r + this.lastChar.toString("base64", 0, 3 - this.lastNeed);
      return r;
    }
    function simpleWrite(buf) {
      return buf.toString(this.encoding);
    }
    function simpleEnd(buf) {
      return buf && buf.length ? this.write(buf) : "";
    }
  }
});

// ../vscode/node_modules/readable-stream/lib/internal/streams/from.js
var require_from = __commonJS({
  "../vscode/node_modules/readable-stream/lib/internal/streams/from.js"(exports2, module2) {
    "use strict";
    var process2 = require_process2();
    var { PromisePrototypeThen, SymbolAsyncIterator, SymbolIterator } = require_primordials();
    var { Buffer: Buffer2 } = require("buffer");
    var { ERR_INVALID_ARG_TYPE, ERR_STREAM_NULL_VALUES } = require_errors().codes;
    function from(Readable, iterable, opts) {
      let iterator;
      if (typeof iterable === "string" || iterable instanceof Buffer2) {
        return new Readable({
          objectMode: true,
          ...opts,
          read() {
            this.push(iterable);
            this.push(null);
          }
        });
      }
      let isAsync;
      if (iterable && iterable[SymbolAsyncIterator]) {
        isAsync = true;
        iterator = iterable[SymbolAsyncIterator]();
      } else if (iterable && iterable[SymbolIterator]) {
        isAsync = false;
        iterator = iterable[SymbolIterator]();
      } else {
        throw new ERR_INVALID_ARG_TYPE("iterable", ["Iterable"], iterable);
      }
      const readable = new Readable({
        objectMode: true,
        highWaterMark: 1,
        // TODO(ronag): What options should be allowed?
        ...opts
      });
      let reading = false;
      readable._read = function() {
        if (!reading) {
          reading = true;
          next();
        }
      };
      readable._destroy = function(error, cb) {
        PromisePrototypeThen(
          close(error),
          () => process2.nextTick(cb, error),
          // nextTick is here in case cb throws
          (e) => process2.nextTick(cb, e || error)
        );
      };
      async function close(error) {
        const hadError = error !== void 0 && error !== null;
        const hasThrow = typeof iterator.throw === "function";
        if (hadError && hasThrow) {
          const { value, done } = await iterator.throw(error);
          await value;
          if (done) {
            return;
          }
        }
        if (typeof iterator.return === "function") {
          const { value } = await iterator.return();
          await value;
        }
      }
      async function next() {
        for (; ; ) {
          try {
            const { value, done } = isAsync ? await iterator.next() : iterator.next();
            if (done) {
              readable.push(null);
            } else {
              const res2 = value && typeof value.then === "function" ? await value : value;
              if (res2 === null) {
                reading = false;
                throw new ERR_STREAM_NULL_VALUES();
              } else if (readable.push(res2)) {
                continue;
              } else {
                reading = false;
              }
            }
          } catch (err) {
            readable.destroy(err);
          }
          break;
        }
      }
      return readable;
    }
    module2.exports = from;
  }
});

// ../vscode/node_modules/readable-stream/lib/internal/streams/readable.js
var require_readable = __commonJS({
  "../vscode/node_modules/readable-stream/lib/internal/streams/readable.js"(exports2, module2) {
    "use strict";
    var process2 = require_process2();
    var {
      ArrayPrototypeIndexOf,
      NumberIsInteger,
      NumberIsNaN,
      NumberParseInt,
      ObjectDefineProperties,
      ObjectKeys,
      ObjectSetPrototypeOf,
      Promise: Promise2,
      SafeSet,
      SymbolAsyncDispose,
      SymbolAsyncIterator,
      Symbol: Symbol2
    } = require_primordials();
    module2.exports = Readable;
    Readable.ReadableState = ReadableState;
    var { EventEmitter: EE } = require("events");
    var { Stream, prependListener } = require_legacy();
    var { Buffer: Buffer2 } = require("buffer");
    var { addAbortSignal } = require_add_abort_signal();
    var eos = require_end_of_stream();
    var debug = require_util().debuglog("stream", (fn) => {
      debug = fn;
    });
    var BufferList = require_buffer_list();
    var destroyImpl = require_destroy();
    var { getHighWaterMark, getDefaultHighWaterMark } = require_state();
    var {
      aggregateTwoErrors,
      codes: {
        ERR_INVALID_ARG_TYPE,
        ERR_METHOD_NOT_IMPLEMENTED,
        ERR_OUT_OF_RANGE,
        ERR_STREAM_PUSH_AFTER_EOF,
        ERR_STREAM_UNSHIFT_AFTER_END_EVENT
      },
      AbortError
    } = require_errors();
    var { validateObject } = require_validators();
    var kPaused = Symbol2("kPaused");
    var { StringDecoder } = require_string_decoder();
    var from = require_from();
    ObjectSetPrototypeOf(Readable.prototype, Stream.prototype);
    ObjectSetPrototypeOf(Readable, Stream);
    var nop = () => {
    };
    var { errorOrDestroy } = destroyImpl;
    var kObjectMode = 1 << 0;
    var kEnded = 1 << 1;
    var kEndEmitted = 1 << 2;
    var kReading = 1 << 3;
    var kConstructed = 1 << 4;
    var kSync = 1 << 5;
    var kNeedReadable = 1 << 6;
    var kEmittedReadable = 1 << 7;
    var kReadableListening = 1 << 8;
    var kResumeScheduled = 1 << 9;
    var kErrorEmitted = 1 << 10;
    var kEmitClose = 1 << 11;
    var kAutoDestroy = 1 << 12;
    var kDestroyed = 1 << 13;
    var kClosed = 1 << 14;
    var kCloseEmitted = 1 << 15;
    var kMultiAwaitDrain = 1 << 16;
    var kReadingMore = 1 << 17;
    var kDataEmitted = 1 << 18;
    function makeBitMapDescriptor(bit) {
      return {
        enumerable: false,
        get() {
          return (this.state & bit) !== 0;
        },
        set(value) {
          if (value) this.state |= bit;
          else this.state &= ~bit;
        }
      };
    }
    ObjectDefineProperties(ReadableState.prototype, {
      objectMode: makeBitMapDescriptor(kObjectMode),
      ended: makeBitMapDescriptor(kEnded),
      endEmitted: makeBitMapDescriptor(kEndEmitted),
      reading: makeBitMapDescriptor(kReading),
      // Stream is still being constructed and cannot be
      // destroyed until construction finished or failed.
      // Async construction is opt in, therefore we start as
      // constructed.
      constructed: makeBitMapDescriptor(kConstructed),
      // A flag to be able to tell if the event 'readable'/'data' is emitted
      // immediately, or on a later tick.  We set this to true at first, because
      // any actions that shouldn't happen until "later" should generally also
      // not happen before the first read call.
      sync: makeBitMapDescriptor(kSync),
      // Whenever we return null, then we set a flag to say
      // that we're awaiting a 'readable' event emission.
      needReadable: makeBitMapDescriptor(kNeedReadable),
      emittedReadable: makeBitMapDescriptor(kEmittedReadable),
      readableListening: makeBitMapDescriptor(kReadableListening),
      resumeScheduled: makeBitMapDescriptor(kResumeScheduled),
      // True if the error was already emitted and should not be thrown again.
      errorEmitted: makeBitMapDescriptor(kErrorEmitted),
      emitClose: makeBitMapDescriptor(kEmitClose),
      autoDestroy: makeBitMapDescriptor(kAutoDestroy),
      // Has it been destroyed.
      destroyed: makeBitMapDescriptor(kDestroyed),
      // Indicates whether the stream has finished destroying.
      closed: makeBitMapDescriptor(kClosed),
      // True if close has been emitted or would have been emitted
      // depending on emitClose.
      closeEmitted: makeBitMapDescriptor(kCloseEmitted),
      multiAwaitDrain: makeBitMapDescriptor(kMultiAwaitDrain),
      // If true, a maybeReadMore has been scheduled.
      readingMore: makeBitMapDescriptor(kReadingMore),
      dataEmitted: makeBitMapDescriptor(kDataEmitted)
    });
    function ReadableState(options, stream, isDuplex) {
      if (typeof isDuplex !== "boolean") isDuplex = stream instanceof require_duplex();
      this.state = kEmitClose | kAutoDestroy | kConstructed | kSync;
      if (options && options.objectMode) this.state |= kObjectMode;
      if (isDuplex && options && options.readableObjectMode) this.state |= kObjectMode;
      this.highWaterMark = options ? getHighWaterMark(this, options, "readableHighWaterMark", isDuplex) : getDefaultHighWaterMark(false);
      this.buffer = new BufferList();
      this.length = 0;
      this.pipes = [];
      this.flowing = null;
      this[kPaused] = null;
      if (options && options.emitClose === false) this.state &= ~kEmitClose;
      if (options && options.autoDestroy === false) this.state &= ~kAutoDestroy;
      this.errored = null;
      this.defaultEncoding = options && options.defaultEncoding || "utf8";
      this.awaitDrainWriters = null;
      this.decoder = null;
      this.encoding = null;
      if (options && options.encoding) {
        this.decoder = new StringDecoder(options.encoding);
        this.encoding = options.encoding;
      }
    }
    function Readable(options) {
      if (!(this instanceof Readable)) return new Readable(options);
      const isDuplex = this instanceof require_duplex();
      this._readableState = new ReadableState(options, this, isDuplex);
      if (options) {
        if (typeof options.read === "function") this._read = options.read;
        if (typeof options.destroy === "function") this._destroy = options.destroy;
        if (typeof options.construct === "function") this._construct = options.construct;
        if (options.signal && !isDuplex) addAbortSignal(options.signal, this);
      }
      Stream.call(this, options);
      destroyImpl.construct(this, () => {
        if (this._readableState.needReadable) {
          maybeReadMore(this, this._readableState);
        }
      });
    }
    Readable.prototype.destroy = destroyImpl.destroy;
    Readable.prototype._undestroy = destroyImpl.undestroy;
    Readable.prototype._destroy = function(err, cb) {
      cb(err);
    };
    Readable.prototype[EE.captureRejectionSymbol] = function(err) {
      this.destroy(err);
    };
    Readable.prototype[SymbolAsyncDispose] = function() {
      let error;
      if (!this.destroyed) {
        error = this.readableEnded ? null : new AbortError();
        this.destroy(error);
      }
      return new Promise2((resolve3, reject) => eos(this, (err) => err && err !== error ? reject(err) : resolve3(null)));
    };
    Readable.prototype.push = function(chunk, encoding) {
      return readableAddChunk(this, chunk, encoding, false);
    };
    Readable.prototype.unshift = function(chunk, encoding) {
      return readableAddChunk(this, chunk, encoding, true);
    };
    function readableAddChunk(stream, chunk, encoding, addToFront) {
      debug("readableAddChunk", chunk);
      const state = stream._readableState;
      let err;
      if ((state.state & kObjectMode) === 0) {
        if (typeof chunk === "string") {
          encoding = encoding || state.defaultEncoding;
          if (state.encoding !== encoding) {
            if (addToFront && state.encoding) {
              chunk = Buffer2.from(chunk, encoding).toString(state.encoding);
            } else {
              chunk = Buffer2.from(chunk, encoding);
              encoding = "";
            }
          }
        } else if (chunk instanceof Buffer2) {
          encoding = "";
        } else if (Stream._isUint8Array(chunk)) {
          chunk = Stream._uint8ArrayToBuffer(chunk);
          encoding = "";
        } else if (chunk != null) {
          err = new ERR_INVALID_ARG_TYPE("chunk", ["string", "Buffer", "Uint8Array"], chunk);
        }
      }
      if (err) {
        errorOrDestroy(stream, err);
      } else if (chunk === null) {
        state.state &= ~kReading;
        onEofChunk(stream, state);
      } else if ((state.state & kObjectMode) !== 0 || chunk && chunk.length > 0) {
        if (addToFront) {
          if ((state.state & kEndEmitted) !== 0) errorOrDestroy(stream, new ERR_STREAM_UNSHIFT_AFTER_END_EVENT());
          else if (state.destroyed || state.errored) return false;
          else addChunk(stream, state, chunk, true);
        } else if (state.ended) {
          errorOrDestroy(stream, new ERR_STREAM_PUSH_AFTER_EOF());
        } else if (state.destroyed || state.errored) {
          return false;
        } else {
          state.state &= ~kReading;
          if (state.decoder && !encoding) {
            chunk = state.decoder.write(chunk);
            if (state.objectMode || chunk.length !== 0) addChunk(stream, state, chunk, false);
            else maybeReadMore(stream, state);
          } else {
            addChunk(stream, state, chunk, false);
          }
        }
      } else if (!addToFront) {
        state.state &= ~kReading;
        maybeReadMore(stream, state);
      }
      return !state.ended && (state.length < state.highWaterMark || state.length === 0);
    }
    function addChunk(stream, state, chunk, addToFront) {
      if (state.flowing && state.length === 0 && !state.sync && stream.listenerCount("data") > 0) {
        if ((state.state & kMultiAwaitDrain) !== 0) {
          state.awaitDrainWriters.clear();
        } else {
          state.awaitDrainWriters = null;
        }
        state.dataEmitted = true;
        stream.emit("data", chunk);
      } else {
        state.length += state.objectMode ? 1 : chunk.length;
        if (addToFront) state.buffer.unshift(chunk);
        else state.buffer.push(chunk);
        if ((state.state & kNeedReadable) !== 0) emitReadable(stream);
      }
      maybeReadMore(stream, state);
    }
    Readable.prototype.isPaused = function() {
      const state = this._readableState;
      return state[kPaused] === true || state.flowing === false;
    };
    Readable.prototype.setEncoding = function(enc) {
      const decoder = new StringDecoder(enc);
      this._readableState.decoder = decoder;
      this._readableState.encoding = this._readableState.decoder.encoding;
      const buffer = this._readableState.buffer;
      let content = "";
      for (const data of buffer) {
        content += decoder.write(data);
      }
      buffer.clear();
      if (content !== "") buffer.push(content);
      this._readableState.length = content.length;
      return this;
    };
    var MAX_HWM = 1073741824;
    function computeNewHighWaterMark(n) {
      if (n > MAX_HWM) {
        throw new ERR_OUT_OF_RANGE("size", "<= 1GiB", n);
      } else {
        n--;
        n |= n >>> 1;
        n |= n >>> 2;
        n |= n >>> 4;
        n |= n >>> 8;
        n |= n >>> 16;
        n++;
      }
      return n;
    }
    function howMuchToRead(n, state) {
      if (n <= 0 || state.length === 0 && state.ended) return 0;
      if ((state.state & kObjectMode) !== 0) return 1;
      if (NumberIsNaN(n)) {
        if (state.flowing && state.length) return state.buffer.first().length;
        return state.length;
      }
      if (n <= state.length) return n;
      return state.ended ? state.length : 0;
    }
    Readable.prototype.read = function(n) {
      debug("read", n);
      if (n === void 0) {
        n = NaN;
      } else if (!NumberIsInteger(n)) {
        n = NumberParseInt(n, 10);
      }
      const state = this._readableState;
      const nOrig = n;
      if (n > state.highWaterMark) state.highWaterMark = computeNewHighWaterMark(n);
      if (n !== 0) state.state &= ~kEmittedReadable;
      if (n === 0 && state.needReadable && ((state.highWaterMark !== 0 ? state.length >= state.highWaterMark : state.length > 0) || state.ended)) {
        debug("read: emitReadable", state.length, state.ended);
        if (state.length === 0 && state.ended) endReadable(this);
        else emitReadable(this);
        return null;
      }
      n = howMuchToRead(n, state);
      if (n === 0 && state.ended) {
        if (state.length === 0) endReadable(this);
        return null;
      }
      let doRead = (state.state & kNeedReadable) !== 0;
      debug("need readable", doRead);
      if (state.length === 0 || state.length - n < state.highWaterMark) {
        doRead = true;
        debug("length less than watermark", doRead);
      }
      if (state.ended || state.reading || state.destroyed || state.errored || !state.constructed) {
        doRead = false;
        debug("reading, ended or constructing", doRead);
      } else if (doRead) {
        debug("do read");
        state.state |= kReading | kSync;
        if (state.length === 0) state.state |= kNeedReadable;
        try {
          this._read(state.highWaterMark);
        } catch (err) {
          errorOrDestroy(this, err);
        }
        state.state &= ~kSync;
        if (!state.reading) n = howMuchToRead(nOrig, state);
      }
      let ret;
      if (n > 0) ret = fromList(n, state);
      else ret = null;
      if (ret === null) {
        state.needReadable = state.length <= state.highWaterMark;
        n = 0;
      } else {
        state.length -= n;
        if (state.multiAwaitDrain) {
          state.awaitDrainWriters.clear();
        } else {
          state.awaitDrainWriters = null;
        }
      }
      if (state.length === 0) {
        if (!state.ended) state.needReadable = true;
        if (nOrig !== n && state.ended) endReadable(this);
      }
      if (ret !== null && !state.errorEmitted && !state.closeEmitted) {
        state.dataEmitted = true;
        this.emit("data", ret);
      }
      return ret;
    };
    function onEofChunk(stream, state) {
      debug("onEofChunk");
      if (state.ended) return;
      if (state.decoder) {
        const chunk = state.decoder.end();
        if (chunk && chunk.length) {
          state.buffer.push(chunk);
          state.length += state.objectMode ? 1 : chunk.length;
        }
      }
      state.ended = true;
      if (state.sync) {
        emitReadable(stream);
      } else {
        state.needReadable = false;
        state.emittedReadable = true;
        emitReadable_(stream);
      }
    }
    function emitReadable(stream) {
      const state = stream._readableState;
      debug("emitReadable", state.needReadable, state.emittedReadable);
      state.needReadable = false;
      if (!state.emittedReadable) {
        debug("emitReadable", state.flowing);
        state.emittedReadable = true;
        process2.nextTick(emitReadable_, stream);
      }
    }
    function emitReadable_(stream) {
      const state = stream._readableState;
      debug("emitReadable_", state.destroyed, state.length, state.ended);
      if (!state.destroyed && !state.errored && (state.length || state.ended)) {
        stream.emit("readable");
        state.emittedReadable = false;
      }
      state.needReadable = !state.flowing && !state.ended && state.length <= state.highWaterMark;
      flow(stream);
    }
    function maybeReadMore(stream, state) {
      if (!state.readingMore && state.constructed) {
        state.readingMore = true;
        process2.nextTick(maybeReadMore_, stream, state);
      }
    }
    function maybeReadMore_(stream, state) {
      while (!state.reading && !state.ended && (state.length < state.highWaterMark || state.flowing && state.length === 0)) {
        const len = state.length;
        debug("maybeReadMore read 0");
        stream.read(0);
        if (len === state.length)
          break;
      }
      state.readingMore = false;
    }
    Readable.prototype._read = function(n) {
      throw new ERR_METHOD_NOT_IMPLEMENTED("_read()");
    };
    Readable.prototype.pipe = function(dest, pipeOpts) {
      const src = this;
      const state = this._readableState;
      if (state.pipes.length === 1) {
        if (!state.multiAwaitDrain) {
          state.multiAwaitDrain = true;
          state.awaitDrainWriters = new SafeSet(state.awaitDrainWriters ? [state.awaitDrainWriters] : []);
        }
      }
      state.pipes.push(dest);
      debug("pipe count=%d opts=%j", state.pipes.length, pipeOpts);
      const doEnd = (!pipeOpts || pipeOpts.end !== false) && dest !== process2.stdout && dest !== process2.stderr;
      const endFn = doEnd ? onend : unpipe;
      if (state.endEmitted) process2.nextTick(endFn);
      else src.once("end", endFn);
      dest.on("unpipe", onunpipe);
      function onunpipe(readable, unpipeInfo) {
        debug("onunpipe");
        if (readable === src) {
          if (unpipeInfo && unpipeInfo.hasUnpiped === false) {
            unpipeInfo.hasUnpiped = true;
            cleanup();
          }
        }
      }
      function onend() {
        debug("onend");
        dest.end();
      }
      let ondrain;
      let cleanedUp = false;
      function cleanup() {
        debug("cleanup");
        dest.removeListener("close", onclose);
        dest.removeListener("finish", onfinish);
        if (ondrain) {
          dest.removeListener("drain", ondrain);
        }
        dest.removeListener("error", onerror);
        dest.removeListener("unpipe", onunpipe);
        src.removeListener("end", onend);
        src.removeListener("end", unpipe);
        src.removeListener("data", ondata);
        cleanedUp = true;
        if (ondrain && state.awaitDrainWriters && (!dest._writableState || dest._writableState.needDrain)) ondrain();
      }
      function pause() {
        if (!cleanedUp) {
          if (state.pipes.length === 1 && state.pipes[0] === dest) {
            debug("false write response, pause", 0);
            state.awaitDrainWriters = dest;
            state.multiAwaitDrain = false;
          } else if (state.pipes.length > 1 && state.pipes.includes(dest)) {
            debug("false write response, pause", state.awaitDrainWriters.size);
            state.awaitDrainWriters.add(dest);
          }
          src.pause();
        }
        if (!ondrain) {
          ondrain = pipeOnDrain(src, dest);
          dest.on("drain", ondrain);
        }
      }
      src.on("data", ondata);
      function ondata(chunk) {
        debug("ondata");
        const ret = dest.write(chunk);
        debug("dest.write", ret);
        if (ret === false) {
          pause();
        }
      }
      function onerror(er) {
        debug("onerror", er);
        unpipe();
        dest.removeListener("error", onerror);
        if (dest.listenerCount("error") === 0) {
          const s = dest._writableState || dest._readableState;
          if (s && !s.errorEmitted) {
            errorOrDestroy(dest, er);
          } else {
            dest.emit("error", er);
          }
        }
      }
      prependListener(dest, "error", onerror);
      function onclose() {
        dest.removeListener("finish", onfinish);
        unpipe();
      }
      dest.once("close", onclose);
      function onfinish() {
        debug("onfinish");
        dest.removeListener("close", onclose);
        unpipe();
      }
      dest.once("finish", onfinish);
      function unpipe() {
        debug("unpipe");
        src.unpipe(dest);
      }
      dest.emit("pipe", src);
      if (dest.writableNeedDrain === true) {
        pause();
      } else if (!state.flowing) {
        debug("pipe resume");
        src.resume();
      }
      return dest;
    };
    function pipeOnDrain(src, dest) {
      return function pipeOnDrainFunctionResult() {
        const state = src._readableState;
        if (state.awaitDrainWriters === dest) {
          debug("pipeOnDrain", 1);
          state.awaitDrainWriters = null;
        } else if (state.multiAwaitDrain) {
          debug("pipeOnDrain", state.awaitDrainWriters.size);
          state.awaitDrainWriters.delete(dest);
        }
        if ((!state.awaitDrainWriters || state.awaitDrainWriters.size === 0) && src.listenerCount("data")) {
          src.resume();
        }
      };
    }
    Readable.prototype.unpipe = function(dest) {
      const state = this._readableState;
      const unpipeInfo = {
        hasUnpiped: false
      };
      if (state.pipes.length === 0) return this;
      if (!dest) {
        const dests = state.pipes;
        state.pipes = [];
        this.pause();
        for (let i = 0; i < dests.length; i++)
          dests[i].emit("unpipe", this, {
            hasUnpiped: false
          });
        return this;
      }
      const index = ArrayPrototypeIndexOf(state.pipes, dest);
      if (index === -1) return this;
      state.pipes.splice(index, 1);
      if (state.pipes.length === 0) this.pause();
      dest.emit("unpipe", this, unpipeInfo);
      return this;
    };
    Readable.prototype.on = function(ev, fn) {
      const res2 = Stream.prototype.on.call(this, ev, fn);
      const state = this._readableState;
      if (ev === "data") {
        state.readableListening = this.listenerCount("readable") > 0;
        if (state.flowing !== false) this.resume();
      } else if (ev === "readable") {
        if (!state.endEmitted && !state.readableListening) {
          state.readableListening = state.needReadable = true;
          state.flowing = false;
          state.emittedReadable = false;
          debug("on readable", state.length, state.reading);
          if (state.length) {
            emitReadable(this);
          } else if (!state.reading) {
            process2.nextTick(nReadingNextTick, this);
          }
        }
      }
      return res2;
    };
    Readable.prototype.addListener = Readable.prototype.on;
    Readable.prototype.removeListener = function(ev, fn) {
      const res2 = Stream.prototype.removeListener.call(this, ev, fn);
      if (ev === "readable") {
        process2.nextTick(updateReadableListening, this);
      }
      return res2;
    };
    Readable.prototype.off = Readable.prototype.removeListener;
    Readable.prototype.removeAllListeners = function(ev) {
      const res2 = Stream.prototype.removeAllListeners.apply(this, arguments);
      if (ev === "readable" || ev === void 0) {
        process2.nextTick(updateReadableListening, this);
      }
      return res2;
    };
    function updateReadableListening(self) {
      const state = self._readableState;
      state.readableListening = self.listenerCount("readable") > 0;
      if (state.resumeScheduled && state[kPaused] === false) {
        state.flowing = true;
      } else if (self.listenerCount("data") > 0) {
        self.resume();
      } else if (!state.readableListening) {
        state.flowing = null;
      }
    }
    function nReadingNextTick(self) {
      debug("readable nexttick read 0");
      self.read(0);
    }
    Readable.prototype.resume = function() {
      const state = this._readableState;
      if (!state.flowing) {
        debug("resume");
        state.flowing = !state.readableListening;
        resume(this, state);
      }
      state[kPaused] = false;
      return this;
    };
    function resume(stream, state) {
      if (!state.resumeScheduled) {
        state.resumeScheduled = true;
        process2.nextTick(resume_, stream, state);
      }
    }
    function resume_(stream, state) {
      debug("resume", state.reading);
      if (!state.reading) {
        stream.read(0);
      }
      state.resumeScheduled = false;
      stream.emit("resume");
      flow(stream);
      if (state.flowing && !state.reading) stream.read(0);
    }
    Readable.prototype.pause = function() {
      debug("call pause flowing=%j", this._readableState.flowing);
      if (this._readableState.flowing !== false) {
        debug("pause");
        this._readableState.flowing = false;
        this.emit("pause");
      }
      this._readableState[kPaused] = true;
      return this;
    };
    function flow(stream) {
      const state = stream._readableState;
      debug("flow", state.flowing);
      while (state.flowing && stream.read() !== null) ;
    }
    Readable.prototype.wrap = function(stream) {
      let paused = false;
      stream.on("data", (chunk) => {
        if (!this.push(chunk) && stream.pause) {
          paused = true;
          stream.pause();
        }
      });
      stream.on("end", () => {
        this.push(null);
      });
      stream.on("error", (err) => {
        errorOrDestroy(this, err);
      });
      stream.on("close", () => {
        this.destroy();
      });
      stream.on("destroy", () => {
        this.destroy();
      });
      this._read = () => {
        if (paused && stream.resume) {
          paused = false;
          stream.resume();
        }
      };
      const streamKeys = ObjectKeys(stream);
      for (let j = 1; j < streamKeys.length; j++) {
        const i = streamKeys[j];
        if (this[i] === void 0 && typeof stream[i] === "function") {
          this[i] = stream[i].bind(stream);
        }
      }
      return this;
    };
    Readable.prototype[SymbolAsyncIterator] = function() {
      return streamToAsyncIterator(this);
    };
    Readable.prototype.iterator = function(options) {
      if (options !== void 0) {
        validateObject(options, "options");
      }
      return streamToAsyncIterator(this, options);
    };
    function streamToAsyncIterator(stream, options) {
      if (typeof stream.read !== "function") {
        stream = Readable.wrap(stream, {
          objectMode: true
        });
      }
      const iter = createAsyncIterator(stream, options);
      iter.stream = stream;
      return iter;
    }
    async function* createAsyncIterator(stream, options) {
      let callback = nop;
      function next(resolve3) {
        if (this === stream) {
          callback();
          callback = nop;
        } else {
          callback = resolve3;
        }
      }
      stream.on("readable", next);
      let error;
      const cleanup = eos(
        stream,
        {
          writable: false
        },
        (err) => {
          error = err ? aggregateTwoErrors(error, err) : null;
          callback();
          callback = nop;
        }
      );
      try {
        while (true) {
          const chunk = stream.destroyed ? null : stream.read();
          if (chunk !== null) {
            yield chunk;
          } else if (error) {
            throw error;
          } else if (error === null) {
            return;
          } else {
            await new Promise2(next);
          }
        }
      } catch (err) {
        error = aggregateTwoErrors(error, err);
        throw error;
      } finally {
        if ((error || (options === null || options === void 0 ? void 0 : options.destroyOnReturn) !== false) && (error === void 0 || stream._readableState.autoDestroy)) {
          destroyImpl.destroyer(stream, null);
        } else {
          stream.off("readable", next);
          cleanup();
        }
      }
    }
    ObjectDefineProperties(Readable.prototype, {
      readable: {
        __proto__: null,
        get() {
          const r = this._readableState;
          return !!r && r.readable !== false && !r.destroyed && !r.errorEmitted && !r.endEmitted;
        },
        set(val) {
          if (this._readableState) {
            this._readableState.readable = !!val;
          }
        }
      },
      readableDidRead: {
        __proto__: null,
        enumerable: false,
        get: function() {
          return this._readableState.dataEmitted;
        }
      },
      readableAborted: {
        __proto__: null,
        enumerable: false,
        get: function() {
          return !!(this._readableState.readable !== false && (this._readableState.destroyed || this._readableState.errored) && !this._readableState.endEmitted);
        }
      },
      readableHighWaterMark: {
        __proto__: null,
        enumerable: false,
        get: function() {
          return this._readableState.highWaterMark;
        }
      },
      readableBuffer: {
        __proto__: null,
        enumerable: false,
        get: function() {
          return this._readableState && this._readableState.buffer;
        }
      },
      readableFlowing: {
        __proto__: null,
        enumerable: false,
        get: function() {
          return this._readableState.flowing;
        },
        set: function(state) {
          if (this._readableState) {
            this._readableState.flowing = state;
          }
        }
      },
      readableLength: {
        __proto__: null,
        enumerable: false,
        get() {
          return this._readableState.length;
        }
      },
      readableObjectMode: {
        __proto__: null,
        enumerable: false,
        get() {
          return this._readableState ? this._readableState.objectMode : false;
        }
      },
      readableEncoding: {
        __proto__: null,
        enumerable: false,
        get() {
          return this._readableState ? this._readableState.encoding : null;
        }
      },
      errored: {
        __proto__: null,
        enumerable: false,
        get() {
          return this._readableState ? this._readableState.errored : null;
        }
      },
      closed: {
        __proto__: null,
        get() {
          return this._readableState ? this._readableState.closed : false;
        }
      },
      destroyed: {
        __proto__: null,
        enumerable: false,
        get() {
          return this._readableState ? this._readableState.destroyed : false;
        },
        set(value) {
          if (!this._readableState) {
            return;
          }
          this._readableState.destroyed = value;
        }
      },
      readableEnded: {
        __proto__: null,
        enumerable: false,
        get() {
          return this._readableState ? this._readableState.endEmitted : false;
        }
      }
    });
    ObjectDefineProperties(ReadableState.prototype, {
      // Legacy getter for `pipesCount`.
      pipesCount: {
        __proto__: null,
        get() {
          return this.pipes.length;
        }
      },
      // Legacy property for `paused`.
      paused: {
        __proto__: null,
        get() {
          return this[kPaused] !== false;
        },
        set(value) {
          this[kPaused] = !!value;
        }
      }
    });
    Readable._fromList = fromList;
    function fromList(n, state) {
      if (state.length === 0) return null;
      let ret;
      if (state.objectMode) ret = state.buffer.shift();
      else if (!n || n >= state.length) {
        if (state.decoder) ret = state.buffer.join("");
        else if (state.buffer.length === 1) ret = state.buffer.first();
        else ret = state.buffer.concat(state.length);
        state.buffer.clear();
      } else {
        ret = state.buffer.consume(n, state.decoder);
      }
      return ret;
    }
    function endReadable(stream) {
      const state = stream._readableState;
      debug("endReadable", state.endEmitted);
      if (!state.endEmitted) {
        state.ended = true;
        process2.nextTick(endReadableNT, state, stream);
      }
    }
    function endReadableNT(state, stream) {
      debug("endReadableNT", state.endEmitted, state.length);
      if (!state.errored && !state.closeEmitted && !state.endEmitted && state.length === 0) {
        state.endEmitted = true;
        stream.emit("end");
        if (stream.writable && stream.allowHalfOpen === false) {
          process2.nextTick(endWritableNT, stream);
        } else if (state.autoDestroy) {
          const wState = stream._writableState;
          const autoDestroy = !wState || wState.autoDestroy && // We don't expect the writable to ever 'finish'
          // if writable is explicitly set to false.
          (wState.finished || wState.writable === false);
          if (autoDestroy) {
            stream.destroy();
          }
        }
      }
    }
    function endWritableNT(stream) {
      const writable = stream.writable && !stream.writableEnded && !stream.destroyed;
      if (writable) {
        stream.end();
      }
    }
    Readable.from = function(iterable, opts) {
      return from(Readable, iterable, opts);
    };
    var webStreamsAdapters;
    function lazyWebStreams() {
      if (webStreamsAdapters === void 0) webStreamsAdapters = {};
      return webStreamsAdapters;
    }
    Readable.fromWeb = function(readableStream, options) {
      return lazyWebStreams().newStreamReadableFromReadableStream(readableStream, options);
    };
    Readable.toWeb = function(streamReadable, options) {
      return lazyWebStreams().newReadableStreamFromStreamReadable(streamReadable, options);
    };
    Readable.wrap = function(src, options) {
      var _ref, _src$readableObjectMo;
      return new Readable({
        objectMode: (_ref = (_src$readableObjectMo = src.readableObjectMode) !== null && _src$readableObjectMo !== void 0 ? _src$readableObjectMo : src.objectMode) !== null && _ref !== void 0 ? _ref : true,
        ...options,
        destroy(err, callback) {
          destroyImpl.destroyer(src, err);
          callback(err);
        }
      }).wrap(src);
    };
  }
});

// ../vscode/node_modules/readable-stream/lib/internal/streams/writable.js
var require_writable = __commonJS({
  "../vscode/node_modules/readable-stream/lib/internal/streams/writable.js"(exports2, module2) {
    "use strict";
    var process2 = require_process2();
    var {
      ArrayPrototypeSlice,
      Error: Error2,
      FunctionPrototypeSymbolHasInstance,
      ObjectDefineProperty,
      ObjectDefineProperties,
      ObjectSetPrototypeOf,
      StringPrototypeToLowerCase,
      Symbol: Symbol2,
      SymbolHasInstance
    } = require_primordials();
    module2.exports = Writable;
    Writable.WritableState = WritableState;
    var { EventEmitter: EE } = require("events");
    var Stream = require_legacy().Stream;
    var { Buffer: Buffer2 } = require("buffer");
    var destroyImpl = require_destroy();
    var { addAbortSignal } = require_add_abort_signal();
    var { getHighWaterMark, getDefaultHighWaterMark } = require_state();
    var {
      ERR_INVALID_ARG_TYPE,
      ERR_METHOD_NOT_IMPLEMENTED,
      ERR_MULTIPLE_CALLBACK,
      ERR_STREAM_CANNOT_PIPE,
      ERR_STREAM_DESTROYED,
      ERR_STREAM_ALREADY_FINISHED,
      ERR_STREAM_NULL_VALUES,
      ERR_STREAM_WRITE_AFTER_END,
      ERR_UNKNOWN_ENCODING
    } = require_errors().codes;
    var { errorOrDestroy } = destroyImpl;
    ObjectSetPrototypeOf(Writable.prototype, Stream.prototype);
    ObjectSetPrototypeOf(Writable, Stream);
    function nop() {
    }
    var kOnFinished = Symbol2("kOnFinished");
    function WritableState(options, stream, isDuplex) {
      if (typeof isDuplex !== "boolean") isDuplex = stream instanceof require_duplex();
      this.objectMode = !!(options && options.objectMode);
      if (isDuplex) this.objectMode = this.objectMode || !!(options && options.writableObjectMode);
      this.highWaterMark = options ? getHighWaterMark(this, options, "writableHighWaterMark", isDuplex) : getDefaultHighWaterMark(false);
      this.finalCalled = false;
      this.needDrain = false;
      this.ending = false;
      this.ended = false;
      this.finished = false;
      this.destroyed = false;
      const noDecode = !!(options && options.decodeStrings === false);
      this.decodeStrings = !noDecode;
      this.defaultEncoding = options && options.defaultEncoding || "utf8";
      this.length = 0;
      this.writing = false;
      this.corked = 0;
      this.sync = true;
      this.bufferProcessing = false;
      this.onwrite = onwrite.bind(void 0, stream);
      this.writecb = null;
      this.writelen = 0;
      this.afterWriteTickInfo = null;
      resetBuffer(this);
      this.pendingcb = 0;
      this.constructed = true;
      this.prefinished = false;
      this.errorEmitted = false;
      this.emitClose = !options || options.emitClose !== false;
      this.autoDestroy = !options || options.autoDestroy !== false;
      this.errored = null;
      this.closed = false;
      this.closeEmitted = false;
      this[kOnFinished] = [];
    }
    function resetBuffer(state) {
      state.buffered = [];
      state.bufferedIndex = 0;
      state.allBuffers = true;
      state.allNoop = true;
    }
    WritableState.prototype.getBuffer = function getBuffer() {
      return ArrayPrototypeSlice(this.buffered, this.bufferedIndex);
    };
    ObjectDefineProperty(WritableState.prototype, "bufferedRequestCount", {
      __proto__: null,
      get() {
        return this.buffered.length - this.bufferedIndex;
      }
    });
    function Writable(options) {
      const isDuplex = this instanceof require_duplex();
      if (!isDuplex && !FunctionPrototypeSymbolHasInstance(Writable, this)) return new Writable(options);
      this._writableState = new WritableState(options, this, isDuplex);
      if (options) {
        if (typeof options.write === "function") this._write = options.write;
        if (typeof options.writev === "function") this._writev = options.writev;
        if (typeof options.destroy === "function") this._destroy = options.destroy;
        if (typeof options.final === "function") this._final = options.final;
        if (typeof options.construct === "function") this._construct = options.construct;
        if (options.signal) addAbortSignal(options.signal, this);
      }
      Stream.call(this, options);
      destroyImpl.construct(this, () => {
        const state = this._writableState;
        if (!state.writing) {
          clearBuffer(this, state);
        }
        finishMaybe(this, state);
      });
    }
    ObjectDefineProperty(Writable, SymbolHasInstance, {
      __proto__: null,
      value: function(object) {
        if (FunctionPrototypeSymbolHasInstance(this, object)) return true;
        if (this !== Writable) return false;
        return object && object._writableState instanceof WritableState;
      }
    });
    Writable.prototype.pipe = function() {
      errorOrDestroy(this, new ERR_STREAM_CANNOT_PIPE());
    };
    function _write(stream, chunk, encoding, cb) {
      const state = stream._writableState;
      if (typeof encoding === "function") {
        cb = encoding;
        encoding = state.defaultEncoding;
      } else {
        if (!encoding) encoding = state.defaultEncoding;
        else if (encoding !== "buffer" && !Buffer2.isEncoding(encoding)) throw new ERR_UNKNOWN_ENCODING(encoding);
        if (typeof cb !== "function") cb = nop;
      }
      if (chunk === null) {
        throw new ERR_STREAM_NULL_VALUES();
      } else if (!state.objectMode) {
        if (typeof chunk === "string") {
          if (state.decodeStrings !== false) {
            chunk = Buffer2.from(chunk, encoding);
            encoding = "buffer";
          }
        } else if (chunk instanceof Buffer2) {
          encoding = "buffer";
        } else if (Stream._isUint8Array(chunk)) {
          chunk = Stream._uint8ArrayToBuffer(chunk);
          encoding = "buffer";
        } else {
          throw new ERR_INVALID_ARG_TYPE("chunk", ["string", "Buffer", "Uint8Array"], chunk);
        }
      }
      let err;
      if (state.ending) {
        err = new ERR_STREAM_WRITE_AFTER_END();
      } else if (state.destroyed) {
        err = new ERR_STREAM_DESTROYED("write");
      }
      if (err) {
        process2.nextTick(cb, err);
        errorOrDestroy(stream, err, true);
        return err;
      }
      state.pendingcb++;
      return writeOrBuffer(stream, state, chunk, encoding, cb);
    }
    Writable.prototype.write = function(chunk, encoding, cb) {
      return _write(this, chunk, encoding, cb) === true;
    };
    Writable.prototype.cork = function() {
      this._writableState.corked++;
    };
    Writable.prototype.uncork = function() {
      const state = this._writableState;
      if (state.corked) {
        state.corked--;
        if (!state.writing) clearBuffer(this, state);
      }
    };
    Writable.prototype.setDefaultEncoding = function setDefaultEncoding(encoding) {
      if (typeof encoding === "string") encoding = StringPrototypeToLowerCase(encoding);
      if (!Buffer2.isEncoding(encoding)) throw new ERR_UNKNOWN_ENCODING(encoding);
      this._writableState.defaultEncoding = encoding;
      return this;
    };
    function writeOrBuffer(stream, state, chunk, encoding, callback) {
      const len = state.objectMode ? 1 : chunk.length;
      state.length += len;
      const ret = state.length < state.highWaterMark;
      if (!ret) state.needDrain = true;
      if (state.writing || state.corked || state.errored || !state.constructed) {
        state.buffered.push({
          chunk,
          encoding,
          callback
        });
        if (state.allBuffers && encoding !== "buffer") {
          state.allBuffers = false;
        }
        if (state.allNoop && callback !== nop) {
          state.allNoop = false;
        }
      } else {
        state.writelen = len;
        state.writecb = callback;
        state.writing = true;
        state.sync = true;
        stream._write(chunk, encoding, state.onwrite);
        state.sync = false;
      }
      return ret && !state.errored && !state.destroyed;
    }
    function doWrite(stream, state, writev, len, chunk, encoding, cb) {
      state.writelen = len;
      state.writecb = cb;
      state.writing = true;
      state.sync = true;
      if (state.destroyed) state.onwrite(new ERR_STREAM_DESTROYED("write"));
      else if (writev) stream._writev(chunk, state.onwrite);
      else stream._write(chunk, encoding, state.onwrite);
      state.sync = false;
    }
    function onwriteError(stream, state, er, cb) {
      --state.pendingcb;
      cb(er);
      errorBuffer(state);
      errorOrDestroy(stream, er);
    }
    function onwrite(stream, er) {
      const state = stream._writableState;
      const sync = state.sync;
      const cb = state.writecb;
      if (typeof cb !== "function") {
        errorOrDestroy(stream, new ERR_MULTIPLE_CALLBACK());
        return;
      }
      state.writing = false;
      state.writecb = null;
      state.length -= state.writelen;
      state.writelen = 0;
      if (er) {
        er.stack;
        if (!state.errored) {
          state.errored = er;
        }
        if (stream._readableState && !stream._readableState.errored) {
          stream._readableState.errored = er;
        }
        if (sync) {
          process2.nextTick(onwriteError, stream, state, er, cb);
        } else {
          onwriteError(stream, state, er, cb);
        }
      } else {
        if (state.buffered.length > state.bufferedIndex) {
          clearBuffer(stream, state);
        }
        if (sync) {
          if (state.afterWriteTickInfo !== null && state.afterWriteTickInfo.cb === cb) {
            state.afterWriteTickInfo.count++;
          } else {
            state.afterWriteTickInfo = {
              count: 1,
              cb,
              stream,
              state
            };
            process2.nextTick(afterWriteTick, state.afterWriteTickInfo);
          }
        } else {
          afterWrite(stream, state, 1, cb);
        }
      }
    }
    function afterWriteTick({ stream, state, count, cb }) {
      state.afterWriteTickInfo = null;
      return afterWrite(stream, state, count, cb);
    }
    function afterWrite(stream, state, count, cb) {
      const needDrain = !state.ending && !stream.destroyed && state.length === 0 && state.needDrain;
      if (needDrain) {
        state.needDrain = false;
        stream.emit("drain");
      }
      while (count-- > 0) {
        state.pendingcb--;
        cb();
      }
      if (state.destroyed) {
        errorBuffer(state);
      }
      finishMaybe(stream, state);
    }
    function errorBuffer(state) {
      if (state.writing) {
        return;
      }
      for (let n = state.bufferedIndex; n < state.buffered.length; ++n) {
        var _state$errored;
        const { chunk, callback } = state.buffered[n];
        const len = state.objectMode ? 1 : chunk.length;
        state.length -= len;
        callback(
          (_state$errored = state.errored) !== null && _state$errored !== void 0 ? _state$errored : new ERR_STREAM_DESTROYED("write")
        );
      }
      const onfinishCallbacks = state[kOnFinished].splice(0);
      for (let i = 0; i < onfinishCallbacks.length; i++) {
        var _state$errored2;
        onfinishCallbacks[i](
          (_state$errored2 = state.errored) !== null && _state$errored2 !== void 0 ? _state$errored2 : new ERR_STREAM_DESTROYED("end")
        );
      }
      resetBuffer(state);
    }
    function clearBuffer(stream, state) {
      if (state.corked || state.bufferProcessing || state.destroyed || !state.constructed) {
        return;
      }
      const { buffered, bufferedIndex, objectMode } = state;
      const bufferedLength = buffered.length - bufferedIndex;
      if (!bufferedLength) {
        return;
      }
      let i = bufferedIndex;
      state.bufferProcessing = true;
      if (bufferedLength > 1 && stream._writev) {
        state.pendingcb -= bufferedLength - 1;
        const callback = state.allNoop ? nop : (err) => {
          for (let n = i; n < buffered.length; ++n) {
            buffered[n].callback(err);
          }
        };
        const chunks = state.allNoop && i === 0 ? buffered : ArrayPrototypeSlice(buffered, i);
        chunks.allBuffers = state.allBuffers;
        doWrite(stream, state, true, state.length, chunks, "", callback);
        resetBuffer(state);
      } else {
        do {
          const { chunk, encoding, callback } = buffered[i];
          buffered[i++] = null;
          const len = objectMode ? 1 : chunk.length;
          doWrite(stream, state, false, len, chunk, encoding, callback);
        } while (i < buffered.length && !state.writing);
        if (i === buffered.length) {
          resetBuffer(state);
        } else if (i > 256) {
          buffered.splice(0, i);
          state.bufferedIndex = 0;
        } else {
          state.bufferedIndex = i;
        }
      }
      state.bufferProcessing = false;
    }
    Writable.prototype._write = function(chunk, encoding, cb) {
      if (this._writev) {
        this._writev(
          [
            {
              chunk,
              encoding
            }
          ],
          cb
        );
      } else {
        throw new ERR_METHOD_NOT_IMPLEMENTED("_write()");
      }
    };
    Writable.prototype._writev = null;
    Writable.prototype.end = function(chunk, encoding, cb) {
      const state = this._writableState;
      if (typeof chunk === "function") {
        cb = chunk;
        chunk = null;
        encoding = null;
      } else if (typeof encoding === "function") {
        cb = encoding;
        encoding = null;
      }
      let err;
      if (chunk !== null && chunk !== void 0) {
        const ret = _write(this, chunk, encoding);
        if (ret instanceof Error2) {
          err = ret;
        }
      }
      if (state.corked) {
        state.corked = 1;
        this.uncork();
      }
      if (err) {
      } else if (!state.errored && !state.ending) {
        state.ending = true;
        finishMaybe(this, state, true);
        state.ended = true;
      } else if (state.finished) {
        err = new ERR_STREAM_ALREADY_FINISHED("end");
      } else if (state.destroyed) {
        err = new ERR_STREAM_DESTROYED("end");
      }
      if (typeof cb === "function") {
        if (err || state.finished) {
          process2.nextTick(cb, err);
        } else {
          state[kOnFinished].push(cb);
        }
      }
      return this;
    };
    function needFinish(state) {
      return state.ending && !state.destroyed && state.constructed && state.length === 0 && !state.errored && state.buffered.length === 0 && !state.finished && !state.writing && !state.errorEmitted && !state.closeEmitted;
    }
    function callFinal(stream, state) {
      let called = false;
      function onFinish(err) {
        if (called) {
          errorOrDestroy(stream, err !== null && err !== void 0 ? err : ERR_MULTIPLE_CALLBACK());
          return;
        }
        called = true;
        state.pendingcb--;
        if (err) {
          const onfinishCallbacks = state[kOnFinished].splice(0);
          for (let i = 0; i < onfinishCallbacks.length; i++) {
            onfinishCallbacks[i](err);
          }
          errorOrDestroy(stream, err, state.sync);
        } else if (needFinish(state)) {
          state.prefinished = true;
          stream.emit("prefinish");
          state.pendingcb++;
          process2.nextTick(finish, stream, state);
        }
      }
      state.sync = true;
      state.pendingcb++;
      try {
        stream._final(onFinish);
      } catch (err) {
        onFinish(err);
      }
      state.sync = false;
    }
    function prefinish(stream, state) {
      if (!state.prefinished && !state.finalCalled) {
        if (typeof stream._final === "function" && !state.destroyed) {
          state.finalCalled = true;
          callFinal(stream, state);
        } else {
          state.prefinished = true;
          stream.emit("prefinish");
        }
      }
    }
    function finishMaybe(stream, state, sync) {
      if (needFinish(state)) {
        prefinish(stream, state);
        if (state.pendingcb === 0) {
          if (sync) {
            state.pendingcb++;
            process2.nextTick(
              (stream2, state2) => {
                if (needFinish(state2)) {
                  finish(stream2, state2);
                } else {
                  state2.pendingcb--;
                }
              },
              stream,
              state
            );
          } else if (needFinish(state)) {
            state.pendingcb++;
            finish(stream, state);
          }
        }
      }
    }
    function finish(stream, state) {
      state.pendingcb--;
      state.finished = true;
      const onfinishCallbacks = state[kOnFinished].splice(0);
      for (let i = 0; i < onfinishCallbacks.length; i++) {
        onfinishCallbacks[i]();
      }
      stream.emit("finish");
      if (state.autoDestroy) {
        const rState = stream._readableState;
        const autoDestroy = !rState || rState.autoDestroy && // We don't expect the readable to ever 'end'
        // if readable is explicitly set to false.
        (rState.endEmitted || rState.readable === false);
        if (autoDestroy) {
          stream.destroy();
        }
      }
    }
    ObjectDefineProperties(Writable.prototype, {
      closed: {
        __proto__: null,
        get() {
          return this._writableState ? this._writableState.closed : false;
        }
      },
      destroyed: {
        __proto__: null,
        get() {
          return this._writableState ? this._writableState.destroyed : false;
        },
        set(value) {
          if (this._writableState) {
            this._writableState.destroyed = value;
          }
        }
      },
      writable: {
        __proto__: null,
        get() {
          const w = this._writableState;
          return !!w && w.writable !== false && !w.destroyed && !w.errored && !w.ending && !w.ended;
        },
        set(val) {
          if (this._writableState) {
            this._writableState.writable = !!val;
          }
        }
      },
      writableFinished: {
        __proto__: null,
        get() {
          return this._writableState ? this._writableState.finished : false;
        }
      },
      writableObjectMode: {
        __proto__: null,
        get() {
          return this._writableState ? this._writableState.objectMode : false;
        }
      },
      writableBuffer: {
        __proto__: null,
        get() {
          return this._writableState && this._writableState.getBuffer();
        }
      },
      writableEnded: {
        __proto__: null,
        get() {
          return this._writableState ? this._writableState.ending : false;
        }
      },
      writableNeedDrain: {
        __proto__: null,
        get() {
          const wState = this._writableState;
          if (!wState) return false;
          return !wState.destroyed && !wState.ending && wState.needDrain;
        }
      },
      writableHighWaterMark: {
        __proto__: null,
        get() {
          return this._writableState && this._writableState.highWaterMark;
        }
      },
      writableCorked: {
        __proto__: null,
        get() {
          return this._writableState ? this._writableState.corked : 0;
        }
      },
      writableLength: {
        __proto__: null,
        get() {
          return this._writableState && this._writableState.length;
        }
      },
      errored: {
        __proto__: null,
        enumerable: false,
        get() {
          return this._writableState ? this._writableState.errored : null;
        }
      },
      writableAborted: {
        __proto__: null,
        enumerable: false,
        get: function() {
          return !!(this._writableState.writable !== false && (this._writableState.destroyed || this._writableState.errored) && !this._writableState.finished);
        }
      }
    });
    var destroy = destroyImpl.destroy;
    Writable.prototype.destroy = function(err, cb) {
      const state = this._writableState;
      if (!state.destroyed && (state.bufferedIndex < state.buffered.length || state[kOnFinished].length)) {
        process2.nextTick(errorBuffer, state);
      }
      destroy.call(this, err, cb);
      return this;
    };
    Writable.prototype._undestroy = destroyImpl.undestroy;
    Writable.prototype._destroy = function(err, cb) {
      cb(err);
    };
    Writable.prototype[EE.captureRejectionSymbol] = function(err) {
      this.destroy(err);
    };
    var webStreamsAdapters;
    function lazyWebStreams() {
      if (webStreamsAdapters === void 0) webStreamsAdapters = {};
      return webStreamsAdapters;
    }
    Writable.fromWeb = function(writableStream, options) {
      return lazyWebStreams().newStreamWritableFromWritableStream(writableStream, options);
    };
    Writable.toWeb = function(streamWritable) {
      return lazyWebStreams().newWritableStreamFromStreamWritable(streamWritable);
    };
  }
});

// ../vscode/node_modules/readable-stream/lib/internal/streams/duplexify.js
var require_duplexify = __commonJS({
  "../vscode/node_modules/readable-stream/lib/internal/streams/duplexify.js"(exports2, module2) {
    var process2 = require_process2();
    var bufferModule = require("buffer");
    var {
      isReadable,
      isWritable,
      isIterable,
      isNodeStream,
      isReadableNodeStream,
      isWritableNodeStream,
      isDuplexNodeStream,
      isReadableStream,
      isWritableStream
    } = require_utils();
    var eos = require_end_of_stream();
    var {
      AbortError,
      codes: { ERR_INVALID_ARG_TYPE, ERR_INVALID_RETURN_VALUE }
    } = require_errors();
    var { destroyer } = require_destroy();
    var Duplex = require_duplex();
    var Readable = require_readable();
    var Writable = require_writable();
    var { createDeferredPromise } = require_util();
    var from = require_from();
    var Blob = globalThis.Blob || bufferModule.Blob;
    var isBlob = typeof Blob !== "undefined" ? function isBlob2(b) {
      return b instanceof Blob;
    } : function isBlob2(b) {
      return false;
    };
    var AbortController = globalThis.AbortController || require_abort_controller().AbortController;
    var { FunctionPrototypeCall } = require_primordials();
    var Duplexify = class extends Duplex {
      constructor(options) {
        super(options);
        if ((options === null || options === void 0 ? void 0 : options.readable) === false) {
          this._readableState.readable = false;
          this._readableState.ended = true;
          this._readableState.endEmitted = true;
        }
        if ((options === null || options === void 0 ? void 0 : options.writable) === false) {
          this._writableState.writable = false;
          this._writableState.ending = true;
          this._writableState.ended = true;
          this._writableState.finished = true;
        }
      }
    };
    module2.exports = function duplexify(body, name) {
      if (isDuplexNodeStream(body)) {
        return body;
      }
      if (isReadableNodeStream(body)) {
        return _duplexify({
          readable: body
        });
      }
      if (isWritableNodeStream(body)) {
        return _duplexify({
          writable: body
        });
      }
      if (isNodeStream(body)) {
        return _duplexify({
          writable: false,
          readable: false
        });
      }
      if (isReadableStream(body)) {
        return _duplexify({
          readable: Readable.fromWeb(body)
        });
      }
      if (isWritableStream(body)) {
        return _duplexify({
          writable: Writable.fromWeb(body)
        });
      }
      if (typeof body === "function") {
        const { value, write, final, destroy } = fromAsyncGen(body);
        if (isIterable(value)) {
          return from(Duplexify, value, {
            // TODO (ronag): highWaterMark?
            objectMode: true,
            write,
            final,
            destroy
          });
        }
        const then2 = value === null || value === void 0 ? void 0 : value.then;
        if (typeof then2 === "function") {
          let d;
          const promise = FunctionPrototypeCall(
            then2,
            value,
            (val) => {
              if (val != null) {
                throw new ERR_INVALID_RETURN_VALUE("nully", "body", val);
              }
            },
            (err) => {
              destroyer(d, err);
            }
          );
          return d = new Duplexify({
            // TODO (ronag): highWaterMark?
            objectMode: true,
            readable: false,
            write,
            final(cb) {
              final(async () => {
                try {
                  await promise;
                  process2.nextTick(cb, null);
                } catch (err) {
                  process2.nextTick(cb, err);
                }
              });
            },
            destroy
          });
        }
        throw new ERR_INVALID_RETURN_VALUE("Iterable, AsyncIterable or AsyncFunction", name, value);
      }
      if (isBlob(body)) {
        return duplexify(body.arrayBuffer());
      }
      if (isIterable(body)) {
        return from(Duplexify, body, {
          // TODO (ronag): highWaterMark?
          objectMode: true,
          writable: false
        });
      }
      if (isReadableStream(body === null || body === void 0 ? void 0 : body.readable) && isWritableStream(body === null || body === void 0 ? void 0 : body.writable)) {
        return Duplexify.fromWeb(body);
      }
      if (typeof (body === null || body === void 0 ? void 0 : body.writable) === "object" || typeof (body === null || body === void 0 ? void 0 : body.readable) === "object") {
        const readable = body !== null && body !== void 0 && body.readable ? isReadableNodeStream(body === null || body === void 0 ? void 0 : body.readable) ? body === null || body === void 0 ? void 0 : body.readable : duplexify(body.readable) : void 0;
        const writable = body !== null && body !== void 0 && body.writable ? isWritableNodeStream(body === null || body === void 0 ? void 0 : body.writable) ? body === null || body === void 0 ? void 0 : body.writable : duplexify(body.writable) : void 0;
        return _duplexify({
          readable,
          writable
        });
      }
      const then = body === null || body === void 0 ? void 0 : body.then;
      if (typeof then === "function") {
        let d;
        FunctionPrototypeCall(
          then,
          body,
          (val) => {
            if (val != null) {
              d.push(val);
            }
            d.push(null);
          },
          (err) => {
            destroyer(d, err);
          }
        );
        return d = new Duplexify({
          objectMode: true,
          writable: false,
          read() {
          }
        });
      }
      throw new ERR_INVALID_ARG_TYPE(
        name,
        [
          "Blob",
          "ReadableStream",
          "WritableStream",
          "Stream",
          "Iterable",
          "AsyncIterable",
          "Function",
          "{ readable, writable } pair",
          "Promise"
        ],
        body
      );
    };
    function fromAsyncGen(fn) {
      let { promise, resolve: resolve3 } = createDeferredPromise();
      const ac = new AbortController();
      const signal = ac.signal;
      const value = fn(
        (async function* () {
          while (true) {
            const _promise = promise;
            promise = null;
            const { chunk, done, cb } = await _promise;
            process2.nextTick(cb);
            if (done) return;
            if (signal.aborted)
              throw new AbortError(void 0, {
                cause: signal.reason
              });
            ({ promise, resolve: resolve3 } = createDeferredPromise());
            yield chunk;
          }
        })(),
        {
          signal
        }
      );
      return {
        value,
        write(chunk, encoding, cb) {
          const _resolve = resolve3;
          resolve3 = null;
          _resolve({
            chunk,
            done: false,
            cb
          });
        },
        final(cb) {
          const _resolve = resolve3;
          resolve3 = null;
          _resolve({
            done: true,
            cb
          });
        },
        destroy(err, cb) {
          ac.abort();
          cb(err);
        }
      };
    }
    function _duplexify(pair) {
      const r = pair.readable && typeof pair.readable.read !== "function" ? Readable.wrap(pair.readable) : pair.readable;
      const w = pair.writable;
      let readable = !!isReadable(r);
      let writable = !!isWritable(w);
      let ondrain;
      let onfinish;
      let onreadable;
      let onclose;
      let d;
      function onfinished(err) {
        const cb = onclose;
        onclose = null;
        if (cb) {
          cb(err);
        } else if (err) {
          d.destroy(err);
        }
      }
      d = new Duplexify({
        // TODO (ronag): highWaterMark?
        readableObjectMode: !!(r !== null && r !== void 0 && r.readableObjectMode),
        writableObjectMode: !!(w !== null && w !== void 0 && w.writableObjectMode),
        readable,
        writable
      });
      if (writable) {
        eos(w, (err) => {
          writable = false;
          if (err) {
            destroyer(r, err);
          }
          onfinished(err);
        });
        d._write = function(chunk, encoding, callback) {
          if (w.write(chunk, encoding)) {
            callback();
          } else {
            ondrain = callback;
          }
        };
        d._final = function(callback) {
          w.end();
          onfinish = callback;
        };
        w.on("drain", function() {
          if (ondrain) {
            const cb = ondrain;
            ondrain = null;
            cb();
          }
        });
        w.on("finish", function() {
          if (onfinish) {
            const cb = onfinish;
            onfinish = null;
            cb();
          }
        });
      }
      if (readable) {
        eos(r, (err) => {
          readable = false;
          if (err) {
            destroyer(r, err);
          }
          onfinished(err);
        });
        r.on("readable", function() {
          if (onreadable) {
            const cb = onreadable;
            onreadable = null;
            cb();
          }
        });
        r.on("end", function() {
          d.push(null);
        });
        d._read = function() {
          while (true) {
            const buf = r.read();
            if (buf === null) {
              onreadable = d._read;
              return;
            }
            if (!d.push(buf)) {
              return;
            }
          }
        };
      }
      d._destroy = function(err, callback) {
        if (!err && onclose !== null) {
          err = new AbortError();
        }
        onreadable = null;
        ondrain = null;
        onfinish = null;
        if (onclose === null) {
          callback(err);
        } else {
          onclose = callback;
          destroyer(w, err);
          destroyer(r, err);
        }
      };
      return d;
    }
  }
});

// ../vscode/node_modules/readable-stream/lib/internal/streams/duplex.js
var require_duplex = __commonJS({
  "../vscode/node_modules/readable-stream/lib/internal/streams/duplex.js"(exports2, module2) {
    "use strict";
    var {
      ObjectDefineProperties,
      ObjectGetOwnPropertyDescriptor,
      ObjectKeys,
      ObjectSetPrototypeOf
    } = require_primordials();
    module2.exports = Duplex;
    var Readable = require_readable();
    var Writable = require_writable();
    ObjectSetPrototypeOf(Duplex.prototype, Readable.prototype);
    ObjectSetPrototypeOf(Duplex, Readable);
    {
      const keys = ObjectKeys(Writable.prototype);
      for (let i = 0; i < keys.length; i++) {
        const method = keys[i];
        if (!Duplex.prototype[method]) Duplex.prototype[method] = Writable.prototype[method];
      }
    }
    function Duplex(options) {
      if (!(this instanceof Duplex)) return new Duplex(options);
      Readable.call(this, options);
      Writable.call(this, options);
      if (options) {
        this.allowHalfOpen = options.allowHalfOpen !== false;
        if (options.readable === false) {
          this._readableState.readable = false;
          this._readableState.ended = true;
          this._readableState.endEmitted = true;
        }
        if (options.writable === false) {
          this._writableState.writable = false;
          this._writableState.ending = true;
          this._writableState.ended = true;
          this._writableState.finished = true;
        }
      } else {
        this.allowHalfOpen = true;
      }
    }
    ObjectDefineProperties(Duplex.prototype, {
      writable: {
        __proto__: null,
        ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writable")
      },
      writableHighWaterMark: {
        __proto__: null,
        ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableHighWaterMark")
      },
      writableObjectMode: {
        __proto__: null,
        ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableObjectMode")
      },
      writableBuffer: {
        __proto__: null,
        ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableBuffer")
      },
      writableLength: {
        __proto__: null,
        ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableLength")
      },
      writableFinished: {
        __proto__: null,
        ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableFinished")
      },
      writableCorked: {
        __proto__: null,
        ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableCorked")
      },
      writableEnded: {
        __proto__: null,
        ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableEnded")
      },
      writableNeedDrain: {
        __proto__: null,
        ...ObjectGetOwnPropertyDescriptor(Writable.prototype, "writableNeedDrain")
      },
      destroyed: {
        __proto__: null,
        get() {
          if (this._readableState === void 0 || this._writableState === void 0) {
            return false;
          }
          return this._readableState.destroyed && this._writableState.destroyed;
        },
        set(value) {
          if (this._readableState && this._writableState) {
            this._readableState.destroyed = value;
            this._writableState.destroyed = value;
          }
        }
      }
    });
    var webStreamsAdapters;
    function lazyWebStreams() {
      if (webStreamsAdapters === void 0) webStreamsAdapters = {};
      return webStreamsAdapters;
    }
    Duplex.fromWeb = function(pair, options) {
      return lazyWebStreams().newStreamDuplexFromReadableWritablePair(pair, options);
    };
    Duplex.toWeb = function(duplex) {
      return lazyWebStreams().newReadableWritablePairFromDuplex(duplex);
    };
    var duplexify;
    Duplex.from = function(body) {
      if (!duplexify) {
        duplexify = require_duplexify();
      }
      return duplexify(body, "body");
    };
  }
});

// ../vscode/node_modules/readable-stream/lib/internal/streams/transform.js
var require_transform = __commonJS({
  "../vscode/node_modules/readable-stream/lib/internal/streams/transform.js"(exports2, module2) {
    "use strict";
    var { ObjectSetPrototypeOf, Symbol: Symbol2 } = require_primordials();
    module2.exports = Transform;
    var { ERR_METHOD_NOT_IMPLEMENTED } = require_errors().codes;
    var Duplex = require_duplex();
    var { getHighWaterMark } = require_state();
    ObjectSetPrototypeOf(Transform.prototype, Duplex.prototype);
    ObjectSetPrototypeOf(Transform, Duplex);
    var kCallback = Symbol2("kCallback");
    function Transform(options) {
      if (!(this instanceof Transform)) return new Transform(options);
      const readableHighWaterMark = options ? getHighWaterMark(this, options, "readableHighWaterMark", true) : null;
      if (readableHighWaterMark === 0) {
        options = {
          ...options,
          highWaterMark: null,
          readableHighWaterMark,
          // TODO (ronag): 0 is not optimal since we have
          // a "bug" where we check needDrain before calling _write and not after.
          // Refs: https://github.com/nodejs/node/pull/32887
          // Refs: https://github.com/nodejs/node/pull/35941
          writableHighWaterMark: options.writableHighWaterMark || 0
        };
      }
      Duplex.call(this, options);
      this._readableState.sync = false;
      this[kCallback] = null;
      if (options) {
        if (typeof options.transform === "function") this._transform = options.transform;
        if (typeof options.flush === "function") this._flush = options.flush;
      }
      this.on("prefinish", prefinish);
    }
    function final(cb) {
      if (typeof this._flush === "function" && !this.destroyed) {
        this._flush((er, data) => {
          if (er) {
            if (cb) {
              cb(er);
            } else {
              this.destroy(er);
            }
            return;
          }
          if (data != null) {
            this.push(data);
          }
          this.push(null);
          if (cb) {
            cb();
          }
        });
      } else {
        this.push(null);
        if (cb) {
          cb();
        }
      }
    }
    function prefinish() {
      if (this._final !== final) {
        final.call(this);
      }
    }
    Transform.prototype._final = final;
    Transform.prototype._transform = function(chunk, encoding, callback) {
      throw new ERR_METHOD_NOT_IMPLEMENTED("_transform()");
    };
    Transform.prototype._write = function(chunk, encoding, callback) {
      const rState = this._readableState;
      const wState = this._writableState;
      const length = rState.length;
      this._transform(chunk, encoding, (err, val) => {
        if (err) {
          callback(err);
          return;
        }
        if (val != null) {
          this.push(val);
        }
        if (wState.ended || // Backwards compat.
        length === rState.length || // Backwards compat.
        rState.length < rState.highWaterMark) {
          callback();
        } else {
          this[kCallback] = callback;
        }
      });
    };
    Transform.prototype._read = function() {
      if (this[kCallback]) {
        const callback = this[kCallback];
        this[kCallback] = null;
        callback();
      }
    };
  }
});

// ../vscode/node_modules/readable-stream/lib/internal/streams/passthrough.js
var require_passthrough = __commonJS({
  "../vscode/node_modules/readable-stream/lib/internal/streams/passthrough.js"(exports2, module2) {
    "use strict";
    var { ObjectSetPrototypeOf } = require_primordials();
    module2.exports = PassThrough;
    var Transform = require_transform();
    ObjectSetPrototypeOf(PassThrough.prototype, Transform.prototype);
    ObjectSetPrototypeOf(PassThrough, Transform);
    function PassThrough(options) {
      if (!(this instanceof PassThrough)) return new PassThrough(options);
      Transform.call(this, options);
    }
    PassThrough.prototype._transform = function(chunk, encoding, cb) {
      cb(null, chunk);
    };
  }
});

// ../vscode/node_modules/readable-stream/lib/internal/streams/pipeline.js
var require_pipeline = __commonJS({
  "../vscode/node_modules/readable-stream/lib/internal/streams/pipeline.js"(exports2, module2) {
    var process2 = require_process2();
    var { ArrayIsArray, Promise: Promise2, SymbolAsyncIterator, SymbolDispose } = require_primordials();
    var eos = require_end_of_stream();
    var { once } = require_util();
    var destroyImpl = require_destroy();
    var Duplex = require_duplex();
    var {
      aggregateTwoErrors,
      codes: {
        ERR_INVALID_ARG_TYPE,
        ERR_INVALID_RETURN_VALUE,
        ERR_MISSING_ARGS,
        ERR_STREAM_DESTROYED,
        ERR_STREAM_PREMATURE_CLOSE
      },
      AbortError
    } = require_errors();
    var { validateFunction, validateAbortSignal } = require_validators();
    var {
      isIterable,
      isReadable,
      isReadableNodeStream,
      isNodeStream,
      isTransformStream,
      isWebStream,
      isReadableStream,
      isReadableFinished
    } = require_utils();
    var AbortController = globalThis.AbortController || require_abort_controller().AbortController;
    var PassThrough;
    var Readable;
    var addAbortListener;
    function destroyer(stream, reading, writing) {
      let finished = false;
      stream.on("close", () => {
        finished = true;
      });
      const cleanup = eos(
        stream,
        {
          readable: reading,
          writable: writing
        },
        (err) => {
          finished = !err;
        }
      );
      return {
        destroy: (err) => {
          if (finished) return;
          finished = true;
          destroyImpl.destroyer(stream, err || new ERR_STREAM_DESTROYED("pipe"));
        },
        cleanup
      };
    }
    function popCallback(streams) {
      validateFunction(streams[streams.length - 1], "streams[stream.length - 1]");
      return streams.pop();
    }
    function makeAsyncIterable(val) {
      if (isIterable(val)) {
        return val;
      } else if (isReadableNodeStream(val)) {
        return fromReadable(val);
      }
      throw new ERR_INVALID_ARG_TYPE("val", ["Readable", "Iterable", "AsyncIterable"], val);
    }
    async function* fromReadable(val) {
      if (!Readable) {
        Readable = require_readable();
      }
      yield* Readable.prototype[SymbolAsyncIterator].call(val);
    }
    async function pumpToNode(iterable, writable, finish, { end }) {
      let error;
      let onresolve = null;
      const resume = (err) => {
        if (err) {
          error = err;
        }
        if (onresolve) {
          const callback = onresolve;
          onresolve = null;
          callback();
        }
      };
      const wait = () => new Promise2((resolve3, reject) => {
        if (error) {
          reject(error);
        } else {
          onresolve = () => {
            if (error) {
              reject(error);
            } else {
              resolve3();
            }
          };
        }
      });
      writable.on("drain", resume);
      const cleanup = eos(
        writable,
        {
          readable: false
        },
        resume
      );
      try {
        if (writable.writableNeedDrain) {
          await wait();
        }
        for await (const chunk of iterable) {
          if (!writable.write(chunk)) {
            await wait();
          }
        }
        if (end) {
          writable.end();
          await wait();
        }
        finish();
      } catch (err) {
        finish(error !== err ? aggregateTwoErrors(error, err) : err);
      } finally {
        cleanup();
        writable.off("drain", resume);
      }
    }
    async function pumpToWeb(readable, writable, finish, { end }) {
      if (isTransformStream(writable)) {
        writable = writable.writable;
      }
      const writer = writable.getWriter();
      try {
        for await (const chunk of readable) {
          await writer.ready;
          writer.write(chunk).catch(() => {
          });
        }
        await writer.ready;
        if (end) {
          await writer.close();
        }
        finish();
      } catch (err) {
        try {
          await writer.abort(err);
          finish(err);
        } catch (err2) {
          finish(err2);
        }
      }
    }
    function pipeline(...streams) {
      return pipelineImpl(streams, once(popCallback(streams)));
    }
    function pipelineImpl(streams, callback, opts) {
      if (streams.length === 1 && ArrayIsArray(streams[0])) {
        streams = streams[0];
      }
      if (streams.length < 2) {
        throw new ERR_MISSING_ARGS("streams");
      }
      const ac = new AbortController();
      const signal = ac.signal;
      const outerSignal = opts === null || opts === void 0 ? void 0 : opts.signal;
      const lastStreamCleanup = [];
      validateAbortSignal(outerSignal, "options.signal");
      function abort() {
        finishImpl(new AbortError());
      }
      addAbortListener = addAbortListener || require_util().addAbortListener;
      let disposable;
      if (outerSignal) {
        disposable = addAbortListener(outerSignal, abort);
      }
      let error;
      let value;
      const destroys = [];
      let finishCount = 0;
      function finish(err) {
        finishImpl(err, --finishCount === 0);
      }
      function finishImpl(err, final) {
        var _disposable;
        if (err && (!error || error.code === "ERR_STREAM_PREMATURE_CLOSE")) {
          error = err;
        }
        if (!error && !final) {
          return;
        }
        while (destroys.length) {
          destroys.shift()(error);
        }
        ;
        (_disposable = disposable) === null || _disposable === void 0 ? void 0 : _disposable[SymbolDispose]();
        ac.abort();
        if (final) {
          if (!error) {
            lastStreamCleanup.forEach((fn) => fn());
          }
          process2.nextTick(callback, error, value);
        }
      }
      let ret;
      for (let i = 0; i < streams.length; i++) {
        const stream = streams[i];
        const reading = i < streams.length - 1;
        const writing = i > 0;
        const end = reading || (opts === null || opts === void 0 ? void 0 : opts.end) !== false;
        const isLastStream = i === streams.length - 1;
        if (isNodeStream(stream)) {
          let onError2 = function(err) {
            if (err && err.name !== "AbortError" && err.code !== "ERR_STREAM_PREMATURE_CLOSE") {
              finish(err);
            }
          };
          var onError = onError2;
          if (end) {
            const { destroy, cleanup } = destroyer(stream, reading, writing);
            destroys.push(destroy);
            if (isReadable(stream) && isLastStream) {
              lastStreamCleanup.push(cleanup);
            }
          }
          stream.on("error", onError2);
          if (isReadable(stream) && isLastStream) {
            lastStreamCleanup.push(() => {
              stream.removeListener("error", onError2);
            });
          }
        }
        if (i === 0) {
          if (typeof stream === "function") {
            ret = stream({
              signal
            });
            if (!isIterable(ret)) {
              throw new ERR_INVALID_RETURN_VALUE("Iterable, AsyncIterable or Stream", "source", ret);
            }
          } else if (isIterable(stream) || isReadableNodeStream(stream) || isTransformStream(stream)) {
            ret = stream;
          } else {
            ret = Duplex.from(stream);
          }
        } else if (typeof stream === "function") {
          if (isTransformStream(ret)) {
            var _ret;
            ret = makeAsyncIterable((_ret = ret) === null || _ret === void 0 ? void 0 : _ret.readable);
          } else {
            ret = makeAsyncIterable(ret);
          }
          ret = stream(ret, {
            signal
          });
          if (reading) {
            if (!isIterable(ret, true)) {
              throw new ERR_INVALID_RETURN_VALUE("AsyncIterable", `transform[${i - 1}]`, ret);
            }
          } else {
            var _ret2;
            if (!PassThrough) {
              PassThrough = require_passthrough();
            }
            const pt = new PassThrough({
              objectMode: true
            });
            const then = (_ret2 = ret) === null || _ret2 === void 0 ? void 0 : _ret2.then;
            if (typeof then === "function") {
              finishCount++;
              then.call(
                ret,
                (val) => {
                  value = val;
                  if (val != null) {
                    pt.write(val);
                  }
                  if (end) {
                    pt.end();
                  }
                  process2.nextTick(finish);
                },
                (err) => {
                  pt.destroy(err);
                  process2.nextTick(finish, err);
                }
              );
            } else if (isIterable(ret, true)) {
              finishCount++;
              pumpToNode(ret, pt, finish, {
                end
              });
            } else if (isReadableStream(ret) || isTransformStream(ret)) {
              const toRead = ret.readable || ret;
              finishCount++;
              pumpToNode(toRead, pt, finish, {
                end
              });
            } else {
              throw new ERR_INVALID_RETURN_VALUE("AsyncIterable or Promise", "destination", ret);
            }
            ret = pt;
            const { destroy, cleanup } = destroyer(ret, false, true);
            destroys.push(destroy);
            if (isLastStream) {
              lastStreamCleanup.push(cleanup);
            }
          }
        } else if (isNodeStream(stream)) {
          if (isReadableNodeStream(ret)) {
            finishCount += 2;
            const cleanup = pipe(ret, stream, finish, {
              end
            });
            if (isReadable(stream) && isLastStream) {
              lastStreamCleanup.push(cleanup);
            }
          } else if (isTransformStream(ret) || isReadableStream(ret)) {
            const toRead = ret.readable || ret;
            finishCount++;
            pumpToNode(toRead, stream, finish, {
              end
            });
          } else if (isIterable(ret)) {
            finishCount++;
            pumpToNode(ret, stream, finish, {
              end
            });
          } else {
            throw new ERR_INVALID_ARG_TYPE(
              "val",
              ["Readable", "Iterable", "AsyncIterable", "ReadableStream", "TransformStream"],
              ret
            );
          }
          ret = stream;
        } else if (isWebStream(stream)) {
          if (isReadableNodeStream(ret)) {
            finishCount++;
            pumpToWeb(makeAsyncIterable(ret), stream, finish, {
              end
            });
          } else if (isReadableStream(ret) || isIterable(ret)) {
            finishCount++;
            pumpToWeb(ret, stream, finish, {
              end
            });
          } else if (isTransformStream(ret)) {
            finishCount++;
            pumpToWeb(ret.readable, stream, finish, {
              end
            });
          } else {
            throw new ERR_INVALID_ARG_TYPE(
              "val",
              ["Readable", "Iterable", "AsyncIterable", "ReadableStream", "TransformStream"],
              ret
            );
          }
          ret = stream;
        } else {
          ret = Duplex.from(stream);
        }
      }
      if (signal !== null && signal !== void 0 && signal.aborted || outerSignal !== null && outerSignal !== void 0 && outerSignal.aborted) {
        process2.nextTick(abort);
      }
      return ret;
    }
    function pipe(src, dst, finish, { end }) {
      let ended = false;
      dst.on("close", () => {
        if (!ended) {
          finish(new ERR_STREAM_PREMATURE_CLOSE());
        }
      });
      src.pipe(dst, {
        end: false
      });
      if (end) {
        let endFn2 = function() {
          ended = true;
          dst.end();
        };
        var endFn = endFn2;
        if (isReadableFinished(src)) {
          process2.nextTick(endFn2);
        } else {
          src.once("end", endFn2);
        }
      } else {
        finish();
      }
      eos(
        src,
        {
          readable: true,
          writable: false
        },
        (err) => {
          const rState = src._readableState;
          if (err && err.code === "ERR_STREAM_PREMATURE_CLOSE" && rState && rState.ended && !rState.errored && !rState.errorEmitted) {
            src.once("end", finish).once("error", finish);
          } else {
            finish(err);
          }
        }
      );
      return eos(
        dst,
        {
          readable: false,
          writable: true
        },
        finish
      );
    }
    module2.exports = {
      pipelineImpl,
      pipeline
    };
  }
});

// ../vscode/node_modules/readable-stream/lib/internal/streams/compose.js
var require_compose = __commonJS({
  "../vscode/node_modules/readable-stream/lib/internal/streams/compose.js"(exports2, module2) {
    "use strict";
    var { pipeline } = require_pipeline();
    var Duplex = require_duplex();
    var { destroyer } = require_destroy();
    var {
      isNodeStream,
      isReadable,
      isWritable,
      isWebStream,
      isTransformStream,
      isWritableStream,
      isReadableStream
    } = require_utils();
    var {
      AbortError,
      codes: { ERR_INVALID_ARG_VALUE, ERR_MISSING_ARGS }
    } = require_errors();
    var eos = require_end_of_stream();
    module2.exports = function compose(...streams) {
      if (streams.length === 0) {
        throw new ERR_MISSING_ARGS("streams");
      }
      if (streams.length === 1) {
        return Duplex.from(streams[0]);
      }
      const orgStreams = [...streams];
      if (typeof streams[0] === "function") {
        streams[0] = Duplex.from(streams[0]);
      }
      if (typeof streams[streams.length - 1] === "function") {
        const idx = streams.length - 1;
        streams[idx] = Duplex.from(streams[idx]);
      }
      for (let n = 0; n < streams.length; ++n) {
        if (!isNodeStream(streams[n]) && !isWebStream(streams[n])) {
          continue;
        }
        if (n < streams.length - 1 && !(isReadable(streams[n]) || isReadableStream(streams[n]) || isTransformStream(streams[n]))) {
          throw new ERR_INVALID_ARG_VALUE(`streams[${n}]`, orgStreams[n], "must be readable");
        }
        if (n > 0 && !(isWritable(streams[n]) || isWritableStream(streams[n]) || isTransformStream(streams[n]))) {
          throw new ERR_INVALID_ARG_VALUE(`streams[${n}]`, orgStreams[n], "must be writable");
        }
      }
      let ondrain;
      let onfinish;
      let onreadable;
      let onclose;
      let d;
      function onfinished(err) {
        const cb = onclose;
        onclose = null;
        if (cb) {
          cb(err);
        } else if (err) {
          d.destroy(err);
        } else if (!readable && !writable) {
          d.destroy();
        }
      }
      const head = streams[0];
      const tail = pipeline(streams, onfinished);
      const writable = !!(isWritable(head) || isWritableStream(head) || isTransformStream(head));
      const readable = !!(isReadable(tail) || isReadableStream(tail) || isTransformStream(tail));
      d = new Duplex({
        // TODO (ronag): highWaterMark?
        writableObjectMode: !!(head !== null && head !== void 0 && head.writableObjectMode),
        readableObjectMode: !!(tail !== null && tail !== void 0 && tail.readableObjectMode),
        writable,
        readable
      });
      if (writable) {
        if (isNodeStream(head)) {
          d._write = function(chunk, encoding, callback) {
            if (head.write(chunk, encoding)) {
              callback();
            } else {
              ondrain = callback;
            }
          };
          d._final = function(callback) {
            head.end();
            onfinish = callback;
          };
          head.on("drain", function() {
            if (ondrain) {
              const cb = ondrain;
              ondrain = null;
              cb();
            }
          });
        } else if (isWebStream(head)) {
          const writable2 = isTransformStream(head) ? head.writable : head;
          const writer = writable2.getWriter();
          d._write = async function(chunk, encoding, callback) {
            try {
              await writer.ready;
              writer.write(chunk).catch(() => {
              });
              callback();
            } catch (err) {
              callback(err);
            }
          };
          d._final = async function(callback) {
            try {
              await writer.ready;
              writer.close().catch(() => {
              });
              onfinish = callback;
            } catch (err) {
              callback(err);
            }
          };
        }
        const toRead = isTransformStream(tail) ? tail.readable : tail;
        eos(toRead, () => {
          if (onfinish) {
            const cb = onfinish;
            onfinish = null;
            cb();
          }
        });
      }
      if (readable) {
        if (isNodeStream(tail)) {
          tail.on("readable", function() {
            if (onreadable) {
              const cb = onreadable;
              onreadable = null;
              cb();
            }
          });
          tail.on("end", function() {
            d.push(null);
          });
          d._read = function() {
            while (true) {
              const buf = tail.read();
              if (buf === null) {
                onreadable = d._read;
                return;
              }
              if (!d.push(buf)) {
                return;
              }
            }
          };
        } else if (isWebStream(tail)) {
          const readable2 = isTransformStream(tail) ? tail.readable : tail;
          const reader = readable2.getReader();
          d._read = async function() {
            while (true) {
              try {
                const { value, done } = await reader.read();
                if (!d.push(value)) {
                  return;
                }
                if (done) {
                  d.push(null);
                  return;
                }
              } catch {
                return;
              }
            }
          };
        }
      }
      d._destroy = function(err, callback) {
        if (!err && onclose !== null) {
          err = new AbortError();
        }
        onreadable = null;
        ondrain = null;
        onfinish = null;
        if (onclose === null) {
          callback(err);
        } else {
          onclose = callback;
          if (isNodeStream(tail)) {
            destroyer(tail, err);
          }
        }
      };
      return d;
    };
  }
});

// ../vscode/node_modules/readable-stream/lib/internal/streams/operators.js
var require_operators = __commonJS({
  "../vscode/node_modules/readable-stream/lib/internal/streams/operators.js"(exports2, module2) {
    "use strict";
    var AbortController = globalThis.AbortController || require_abort_controller().AbortController;
    var {
      codes: { ERR_INVALID_ARG_VALUE, ERR_INVALID_ARG_TYPE, ERR_MISSING_ARGS, ERR_OUT_OF_RANGE },
      AbortError
    } = require_errors();
    var { validateAbortSignal, validateInteger, validateObject } = require_validators();
    var kWeakHandler = require_primordials().Symbol("kWeak");
    var kResistStopPropagation = require_primordials().Symbol("kResistStopPropagation");
    var { finished } = require_end_of_stream();
    var staticCompose = require_compose();
    var { addAbortSignalNoValidate } = require_add_abort_signal();
    var { isWritable, isNodeStream } = require_utils();
    var { deprecate } = require_util();
    var {
      ArrayPrototypePush,
      Boolean: Boolean2,
      MathFloor,
      Number: Number2,
      NumberIsNaN,
      Promise: Promise2,
      PromiseReject,
      PromiseResolve,
      PromisePrototypeThen,
      Symbol: Symbol2
    } = require_primordials();
    var kEmpty = Symbol2("kEmpty");
    var kEof = Symbol2("kEof");
    function compose(stream, options) {
      if (options != null) {
        validateObject(options, "options");
      }
      if ((options === null || options === void 0 ? void 0 : options.signal) != null) {
        validateAbortSignal(options.signal, "options.signal");
      }
      if (isNodeStream(stream) && !isWritable(stream)) {
        throw new ERR_INVALID_ARG_VALUE("stream", stream, "must be writable");
      }
      const composedStream = staticCompose(this, stream);
      if (options !== null && options !== void 0 && options.signal) {
        addAbortSignalNoValidate(options.signal, composedStream);
      }
      return composedStream;
    }
    function map(fn, options) {
      if (typeof fn !== "function") {
        throw new ERR_INVALID_ARG_TYPE("fn", ["Function", "AsyncFunction"], fn);
      }
      if (options != null) {
        validateObject(options, "options");
      }
      if ((options === null || options === void 0 ? void 0 : options.signal) != null) {
        validateAbortSignal(options.signal, "options.signal");
      }
      let concurrency = 1;
      if ((options === null || options === void 0 ? void 0 : options.concurrency) != null) {
        concurrency = MathFloor(options.concurrency);
      }
      let highWaterMark = concurrency - 1;
      if ((options === null || options === void 0 ? void 0 : options.highWaterMark) != null) {
        highWaterMark = MathFloor(options.highWaterMark);
      }
      validateInteger(concurrency, "options.concurrency", 1);
      validateInteger(highWaterMark, "options.highWaterMark", 0);
      highWaterMark += concurrency;
      return async function* map2() {
        const signal = require_util().AbortSignalAny(
          [options === null || options === void 0 ? void 0 : options.signal].filter(Boolean2)
        );
        const stream = this;
        const queue = [];
        const signalOpt = {
          signal
        };
        let next;
        let resume;
        let done = false;
        let cnt = 0;
        function onCatch() {
          done = true;
          afterItemProcessed();
        }
        function afterItemProcessed() {
          cnt -= 1;
          maybeResume();
        }
        function maybeResume() {
          if (resume && !done && cnt < concurrency && queue.length < highWaterMark) {
            resume();
            resume = null;
          }
        }
        async function pump() {
          try {
            for await (let val of stream) {
              if (done) {
                return;
              }
              if (signal.aborted) {
                throw new AbortError();
              }
              try {
                val = fn(val, signalOpt);
                if (val === kEmpty) {
                  continue;
                }
                val = PromiseResolve(val);
              } catch (err) {
                val = PromiseReject(err);
              }
              cnt += 1;
              PromisePrototypeThen(val, afterItemProcessed, onCatch);
              queue.push(val);
              if (next) {
                next();
                next = null;
              }
              if (!done && (queue.length >= highWaterMark || cnt >= concurrency)) {
                await new Promise2((resolve3) => {
                  resume = resolve3;
                });
              }
            }
            queue.push(kEof);
          } catch (err) {
            const val = PromiseReject(err);
            PromisePrototypeThen(val, afterItemProcessed, onCatch);
            queue.push(val);
          } finally {
            done = true;
            if (next) {
              next();
              next = null;
            }
          }
        }
        pump();
        try {
          while (true) {
            while (queue.length > 0) {
              const val = await queue[0];
              if (val === kEof) {
                return;
              }
              if (signal.aborted) {
                throw new AbortError();
              }
              if (val !== kEmpty) {
                yield val;
              }
              queue.shift();
              maybeResume();
            }
            await new Promise2((resolve3) => {
              next = resolve3;
            });
          }
        } finally {
          done = true;
          if (resume) {
            resume();
            resume = null;
          }
        }
      }.call(this);
    }
    function asIndexedPairs(options = void 0) {
      if (options != null) {
        validateObject(options, "options");
      }
      if ((options === null || options === void 0 ? void 0 : options.signal) != null) {
        validateAbortSignal(options.signal, "options.signal");
      }
      return async function* asIndexedPairs2() {
        let index = 0;
        for await (const val of this) {
          var _options$signal;
          if (options !== null && options !== void 0 && (_options$signal = options.signal) !== null && _options$signal !== void 0 && _options$signal.aborted) {
            throw new AbortError({
              cause: options.signal.reason
            });
          }
          yield [index++, val];
        }
      }.call(this);
    }
    async function some(fn, options = void 0) {
      for await (const unused of filter.call(this, fn, options)) {
        return true;
      }
      return false;
    }
    async function every(fn, options = void 0) {
      if (typeof fn !== "function") {
        throw new ERR_INVALID_ARG_TYPE("fn", ["Function", "AsyncFunction"], fn);
      }
      return !await some.call(
        this,
        async (...args) => {
          return !await fn(...args);
        },
        options
      );
    }
    async function find(fn, options) {
      for await (const result of filter.call(this, fn, options)) {
        return result;
      }
      return void 0;
    }
    async function forEach(fn, options) {
      if (typeof fn !== "function") {
        throw new ERR_INVALID_ARG_TYPE("fn", ["Function", "AsyncFunction"], fn);
      }
      async function forEachFn(value, options2) {
        await fn(value, options2);
        return kEmpty;
      }
      for await (const unused of map.call(this, forEachFn, options)) ;
    }
    function filter(fn, options) {
      if (typeof fn !== "function") {
        throw new ERR_INVALID_ARG_TYPE("fn", ["Function", "AsyncFunction"], fn);
      }
      async function filterFn(value, options2) {
        if (await fn(value, options2)) {
          return value;
        }
        return kEmpty;
      }
      return map.call(this, filterFn, options);
    }
    var ReduceAwareErrMissingArgs = class extends ERR_MISSING_ARGS {
      constructor() {
        super("reduce");
        this.message = "Reduce of an empty stream requires an initial value";
      }
    };
    async function reduce(reducer, initialValue, options) {
      var _options$signal2;
      if (typeof reducer !== "function") {
        throw new ERR_INVALID_ARG_TYPE("reducer", ["Function", "AsyncFunction"], reducer);
      }
      if (options != null) {
        validateObject(options, "options");
      }
      if ((options === null || options === void 0 ? void 0 : options.signal) != null) {
        validateAbortSignal(options.signal, "options.signal");
      }
      let hasInitialValue = arguments.length > 1;
      if (options !== null && options !== void 0 && (_options$signal2 = options.signal) !== null && _options$signal2 !== void 0 && _options$signal2.aborted) {
        const err = new AbortError(void 0, {
          cause: options.signal.reason
        });
        this.once("error", () => {
        });
        await finished(this.destroy(err));
        throw err;
      }
      const ac = new AbortController();
      const signal = ac.signal;
      if (options !== null && options !== void 0 && options.signal) {
        const opts = {
          once: true,
          [kWeakHandler]: this,
          [kResistStopPropagation]: true
        };
        options.signal.addEventListener("abort", () => ac.abort(), opts);
      }
      let gotAnyItemFromStream = false;
      try {
        for await (const value of this) {
          var _options$signal3;
          gotAnyItemFromStream = true;
          if (options !== null && options !== void 0 && (_options$signal3 = options.signal) !== null && _options$signal3 !== void 0 && _options$signal3.aborted) {
            throw new AbortError();
          }
          if (!hasInitialValue) {
            initialValue = value;
            hasInitialValue = true;
          } else {
            initialValue = await reducer(initialValue, value, {
              signal
            });
          }
        }
        if (!gotAnyItemFromStream && !hasInitialValue) {
          throw new ReduceAwareErrMissingArgs();
        }
      } finally {
        ac.abort();
      }
      return initialValue;
    }
    async function toArray(options) {
      if (options != null) {
        validateObject(options, "options");
      }
      if ((options === null || options === void 0 ? void 0 : options.signal) != null) {
        validateAbortSignal(options.signal, "options.signal");
      }
      const result = [];
      for await (const val of this) {
        var _options$signal4;
        if (options !== null && options !== void 0 && (_options$signal4 = options.signal) !== null && _options$signal4 !== void 0 && _options$signal4.aborted) {
          throw new AbortError(void 0, {
            cause: options.signal.reason
          });
        }
        ArrayPrototypePush(result, val);
      }
      return result;
    }
    function flatMap(fn, options) {
      const values = map.call(this, fn, options);
      return async function* flatMap2() {
        for await (const val of values) {
          yield* val;
        }
      }.call(this);
    }
    function toIntegerOrInfinity(number) {
      number = Number2(number);
      if (NumberIsNaN(number)) {
        return 0;
      }
      if (number < 0) {
        throw new ERR_OUT_OF_RANGE("number", ">= 0", number);
      }
      return number;
    }
    function drop(number, options = void 0) {
      if (options != null) {
        validateObject(options, "options");
      }
      if ((options === null || options === void 0 ? void 0 : options.signal) != null) {
        validateAbortSignal(options.signal, "options.signal");
      }
      number = toIntegerOrInfinity(number);
      return async function* drop2() {
        var _options$signal5;
        if (options !== null && options !== void 0 && (_options$signal5 = options.signal) !== null && _options$signal5 !== void 0 && _options$signal5.aborted) {
          throw new AbortError();
        }
        for await (const val of this) {
          var _options$signal6;
          if (options !== null && options !== void 0 && (_options$signal6 = options.signal) !== null && _options$signal6 !== void 0 && _options$signal6.aborted) {
            throw new AbortError();
          }
          if (number-- <= 0) {
            yield val;
          }
        }
      }.call(this);
    }
    function take(number, options = void 0) {
      if (options != null) {
        validateObject(options, "options");
      }
      if ((options === null || options === void 0 ? void 0 : options.signal) != null) {
        validateAbortSignal(options.signal, "options.signal");
      }
      number = toIntegerOrInfinity(number);
      return async function* take2() {
        var _options$signal7;
        if (options !== null && options !== void 0 && (_options$signal7 = options.signal) !== null && _options$signal7 !== void 0 && _options$signal7.aborted) {
          throw new AbortError();
        }
        for await (const val of this) {
          var _options$signal8;
          if (options !== null && options !== void 0 && (_options$signal8 = options.signal) !== null && _options$signal8 !== void 0 && _options$signal8.aborted) {
            throw new AbortError();
          }
          if (number-- > 0) {
            yield val;
          }
          if (number <= 0) {
            return;
          }
        }
      }.call(this);
    }
    module2.exports.streamReturningOperators = {
      asIndexedPairs: deprecate(asIndexedPairs, "readable.asIndexedPairs will be removed in a future version."),
      drop,
      filter,
      flatMap,
      map,
      take,
      compose
    };
    module2.exports.promiseReturningOperators = {
      every,
      forEach,
      reduce,
      toArray,
      some,
      find
    };
  }
});

// ../vscode/node_modules/readable-stream/lib/stream/promises.js
var require_promises = __commonJS({
  "../vscode/node_modules/readable-stream/lib/stream/promises.js"(exports2, module2) {
    "use strict";
    var { ArrayPrototypePop, Promise: Promise2 } = require_primordials();
    var { isIterable, isNodeStream, isWebStream } = require_utils();
    var { pipelineImpl: pl } = require_pipeline();
    var { finished } = require_end_of_stream();
    require_stream();
    function pipeline(...streams) {
      return new Promise2((resolve3, reject) => {
        let signal;
        let end;
        const lastArg = streams[streams.length - 1];
        if (lastArg && typeof lastArg === "object" && !isNodeStream(lastArg) && !isIterable(lastArg) && !isWebStream(lastArg)) {
          const options = ArrayPrototypePop(streams);
          signal = options.signal;
          end = options.end;
        }
        pl(
          streams,
          (err, value) => {
            if (err) {
              reject(err);
            } else {
              resolve3(value);
            }
          },
          {
            signal,
            end
          }
        );
      });
    }
    module2.exports = {
      finished,
      pipeline
    };
  }
});

// ../vscode/node_modules/readable-stream/lib/stream.js
var require_stream = __commonJS({
  "../vscode/node_modules/readable-stream/lib/stream.js"(exports2, module2) {
    "use strict";
    var { Buffer: Buffer2 } = require("buffer");
    var { ObjectDefineProperty, ObjectKeys, ReflectApply } = require_primordials();
    var {
      promisify: { custom: customPromisify }
    } = require_util();
    var { streamReturningOperators, promiseReturningOperators } = require_operators();
    var {
      codes: { ERR_ILLEGAL_CONSTRUCTOR }
    } = require_errors();
    var compose = require_compose();
    var { setDefaultHighWaterMark, getDefaultHighWaterMark } = require_state();
    var { pipeline } = require_pipeline();
    var { destroyer } = require_destroy();
    var eos = require_end_of_stream();
    var promises2 = require_promises();
    var utils = require_utils();
    var Stream = module2.exports = require_legacy().Stream;
    Stream.isDestroyed = utils.isDestroyed;
    Stream.isDisturbed = utils.isDisturbed;
    Stream.isErrored = utils.isErrored;
    Stream.isReadable = utils.isReadable;
    Stream.isWritable = utils.isWritable;
    Stream.Readable = require_readable();
    for (const key of ObjectKeys(streamReturningOperators)) {
      let fn = function(...args) {
        if (new.target) {
          throw ERR_ILLEGAL_CONSTRUCTOR();
        }
        return Stream.Readable.from(ReflectApply(op, this, args));
      };
      const op = streamReturningOperators[key];
      ObjectDefineProperty(fn, "name", {
        __proto__: null,
        value: op.name
      });
      ObjectDefineProperty(fn, "length", {
        __proto__: null,
        value: op.length
      });
      ObjectDefineProperty(Stream.Readable.prototype, key, {
        __proto__: null,
        value: fn,
        enumerable: false,
        configurable: true,
        writable: true
      });
    }
    for (const key of ObjectKeys(promiseReturningOperators)) {
      let fn = function(...args) {
        if (new.target) {
          throw ERR_ILLEGAL_CONSTRUCTOR();
        }
        return ReflectApply(op, this, args);
      };
      const op = promiseReturningOperators[key];
      ObjectDefineProperty(fn, "name", {
        __proto__: null,
        value: op.name
      });
      ObjectDefineProperty(fn, "length", {
        __proto__: null,
        value: op.length
      });
      ObjectDefineProperty(Stream.Readable.prototype, key, {
        __proto__: null,
        value: fn,
        enumerable: false,
        configurable: true,
        writable: true
      });
    }
    Stream.Writable = require_writable();
    Stream.Duplex = require_duplex();
    Stream.Transform = require_transform();
    Stream.PassThrough = require_passthrough();
    Stream.pipeline = pipeline;
    var { addAbortSignal } = require_add_abort_signal();
    Stream.addAbortSignal = addAbortSignal;
    Stream.finished = eos;
    Stream.destroy = destroyer;
    Stream.compose = compose;
    Stream.setDefaultHighWaterMark = setDefaultHighWaterMark;
    Stream.getDefaultHighWaterMark = getDefaultHighWaterMark;
    ObjectDefineProperty(Stream, "promises", {
      __proto__: null,
      configurable: true,
      enumerable: true,
      get() {
        return promises2;
      }
    });
    ObjectDefineProperty(pipeline, customPromisify, {
      __proto__: null,
      enumerable: true,
      get() {
        return promises2.pipeline;
      }
    });
    ObjectDefineProperty(eos, customPromisify, {
      __proto__: null,
      enumerable: true,
      get() {
        return promises2.finished;
      }
    });
    Stream.Stream = Stream;
    Stream._isUint8Array = function isUint8Array(value) {
      return value instanceof Uint8Array;
    };
    Stream._uint8ArrayToBuffer = function _uint8ArrayToBuffer(chunk) {
      return Buffer2.from(chunk.buffer, chunk.byteOffset, chunk.byteLength);
    };
  }
});

// ../vscode/node_modules/readable-stream/lib/ours/index.js
var require_ours = __commonJS({
  "../vscode/node_modules/readable-stream/lib/ours/index.js"(exports2, module2) {
    "use strict";
    var Stream = require("stream");
    if (Stream && process.env.READABLE_STREAM === "disable") {
      const promises2 = Stream.promises;
      module2.exports._uint8ArrayToBuffer = Stream._uint8ArrayToBuffer;
      module2.exports._isUint8Array = Stream._isUint8Array;
      module2.exports.isDisturbed = Stream.isDisturbed;
      module2.exports.isErrored = Stream.isErrored;
      module2.exports.isReadable = Stream.isReadable;
      module2.exports.Readable = Stream.Readable;
      module2.exports.Writable = Stream.Writable;
      module2.exports.Duplex = Stream.Duplex;
      module2.exports.Transform = Stream.Transform;
      module2.exports.PassThrough = Stream.PassThrough;
      module2.exports.addAbortSignal = Stream.addAbortSignal;
      module2.exports.finished = Stream.finished;
      module2.exports.destroy = Stream.destroy;
      module2.exports.pipeline = Stream.pipeline;
      module2.exports.compose = Stream.compose;
      Object.defineProperty(Stream, "promises", {
        configurable: true,
        enumerable: true,
        get() {
          return promises2;
        }
      });
      module2.exports.Stream = Stream.Stream;
    } else {
      const CustomStream = require_stream();
      const promises2 = require_promises();
      const originalDestroy = CustomStream.Readable.destroy;
      module2.exports = CustomStream.Readable;
      module2.exports._uint8ArrayToBuffer = CustomStream._uint8ArrayToBuffer;
      module2.exports._isUint8Array = CustomStream._isUint8Array;
      module2.exports.isDisturbed = CustomStream.isDisturbed;
      module2.exports.isErrored = CustomStream.isErrored;
      module2.exports.isReadable = CustomStream.isReadable;
      module2.exports.Readable = CustomStream.Readable;
      module2.exports.Writable = CustomStream.Writable;
      module2.exports.Duplex = CustomStream.Duplex;
      module2.exports.Transform = CustomStream.Transform;
      module2.exports.PassThrough = CustomStream.PassThrough;
      module2.exports.addAbortSignal = CustomStream.addAbortSignal;
      module2.exports.finished = CustomStream.finished;
      module2.exports.destroy = CustomStream.destroy;
      module2.exports.destroy = originalDestroy;
      module2.exports.pipeline = CustomStream.pipeline;
      module2.exports.compose = CustomStream.compose;
      Object.defineProperty(CustomStream, "promises", {
        configurable: true,
        enumerable: true,
        get() {
          return promises2;
        }
      });
      module2.exports.Stream = CustomStream.Stream;
    }
    module2.exports.default = module2.exports;
  }
});

// ../vscode/node_modules/n3/lib/N3Store.js
var require_N3Store = __commonJS({
  "../vscode/node_modules/n3/lib/N3Store.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    exports2.default = exports2.N3EntityIndex = void 0;
    var _readableStream = require_ours();
    var _N3DataFactory = _interopRequireWildcard(require_N3DataFactory());
    var _IRIs = _interopRequireDefault(require_IRIs());
    var _N3Util = require_N3Util();
    var _N3Writer = _interopRequireDefault(require_N3Writer());
    function _interopRequireDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    function _interopRequireWildcard(e, t) {
      if ("function" == typeof WeakMap) var r = /* @__PURE__ */ new WeakMap(), n = /* @__PURE__ */ new WeakMap();
      return (_interopRequireWildcard = function(e2, t2) {
        if (!t2 && e2 && e2.__esModule) return e2;
        var o, i, f = { __proto__: null, default: e2 };
        if (null === e2 || "object" != typeof e2 && "function" != typeof e2) return f;
        if (o = t2 ? n : r) {
          if (o.has(e2)) return o.get(e2);
          o.set(e2, f);
        }
        for (const t3 in e2) "default" !== t3 && {}.hasOwnProperty.call(e2, t3) && ((i = (o = Object.defineProperty) && Object.getOwnPropertyDescriptor(e2, t3)) && (i.get || i.set) ? o(f, t3, i) : f[t3] = e2[t3]);
        return f;
      })(e, t);
    }
    var ITERATOR = /* @__PURE__ */ Symbol("iter");
    var SIZE = /* @__PURE__ */ Symbol("size");
    var observerRegistry;
    function finalizeObserver({
      store,
      observer
    }) {
      const target = store.deref();
      if (target) target._removeObserver(observer);
    }
    function hasInIndex(index0, key0, key1, key2) {
      const index1 = index0 && index0[key0];
      const index2 = index1 && index1[key1];
      return !!index2 && key2 in index2;
    }
    var markedIRI = /^[?_"[.<]/;
    function entityKey(term) {
      if (typeof term === "string") {
        const first2 = term.charCodeAt(0);
        return first2 !== 60 && first2 !== 46 || term === "<>" ? term : `<${term}>`;
      }
      const id = (0, _N3DataFactory.termToId)(term);
      if (id.charCodeAt(0) >= 97 || !term) return id;
      if (term.termType === "Quad") return JSON.stringify(quadKeyParts(term));
      return term.termType !== "NamedNode" || !markedIRI.test(term.value) ? id : `<${term.value}>`;
    }
    function quadKeyParts(quad) {
      const parts = [nestedKey(quad.subject), nestedKey(quad.predicate), nestedKey(quad.object)];
      if (quad.graph && !(0, _N3Util.isDefaultGraph)(quad.graph)) parts.push(nestedKey(quad.graph));
      return parts;
    }
    function nestedKey(term) {
      return term.termType === "Quad" ? quadKeyParts(term) : entityKey(term);
    }
    var N3EntityIndex = class {
      constructor(options = {}) {
        this._id = 1;
        this._ids = /* @__PURE__ */ Object.create(null);
        this._ids[""] = 1;
        this._entities = /* @__PURE__ */ Object.create(null);
        this._entities[1] = "";
        this._blankNodeIndex = 0;
        this._factory = options.factory || _N3DataFactory.default;
      }
      _termFromId(id) {
        if (id[0] === "<") return this._factory.namedNode(id.substring(1, id.length - 1));
        if (id[0] === ".") {
          const entities = this._entities;
          const terms = id.split(".");
          const q = this._factory.quad(this._termFromId(entities[terms[1]]), this._termFromId(entities[terms[2]]), this._termFromId(entities[terms[3]]), terms[4] && this._termFromId(entities[terms[4]]));
          return q;
        }
        return (0, _N3DataFactory.termFromId)(id, this._factory);
      }
      _termToNumericId(term) {
        if (term.termType === "Quad") {
          const s = this._termToNumericId(term.subject), p = this._termToNumericId(term.predicate), o = this._termToNumericId(term.object);
          let g;
          return s && p && o && ((0, _N3Util.isDefaultGraph)(term.graph) || (g = this._termToNumericId(term.graph))) && this._ids[g ? `.${s}.${p}.${o}.${g}` : `.${s}.${p}.${o}`];
        }
        return typeof term === "string" ? this._stringToNumericId(term) : this._ids[entityKey(term)];
      }
      // Returns the numeric id of a term given as a string id
      _stringToNumericId(term) {
        const id = this._ids[term];
        const first2 = id ? this._entities[id].charCodeAt(0) : term.charCodeAt(0);
        if (first2 !== 60 && first2 !== 46) return id;
        return term === "<>" ? id : this._ids[`<${term}>`];
      }
      _termToNewNumericId(term) {
        if (typeof term === "string") return this._stringToNumericId(term) || this._addEntity(entityKey(term));
        const str = term && term.termType === "Quad" ? `.${this._termToNewNumericId(term.subject)}.${this._termToNewNumericId(term.predicate)}.${this._termToNewNumericId(term.object)}${(0, _N3Util.isDefaultGraph)(term.graph) ? "" : `.${this._termToNewNumericId(term.graph)}`}` : entityKey(term);
        return this._ids[str] || this._addEntity(str);
      }
      _addEntity(key) {
        return this._ids[this._entities[++this._id] = key] = this._id;
      }
      createBlankNode(suggestedName) {
        let name, index;
        if (suggestedName) {
          name = suggestedName = `_:${suggestedName}`, index = 1;
          while (this._ids[name]) name = suggestedName + index++;
        } else {
          do {
            name = `_:b${this._blankNodeIndex++}`;
          } while (this._ids[name]);
        }
        this._ids[name] = ++this._id;
        this._entities[this._id] = name;
        return this._factory.blankNode(name.substr(2));
      }
    };
    exports2.N3EntityIndex = N3EntityIndex;
    function knownSize(dataset) {
      return dataset instanceof N3Store ? dataset._size : null;
    }
    var N3Store = class _N3Store {
      constructor(quads, options) {
        this._size = 0;
        this._graphs = /* @__PURE__ */ Object.create(null);
        this._graphCount = 0;
        this._observers = null;
        if (!options && quads && !quads[0] && !(typeof quads.match === "function")) options = quads, quads = null;
        options = options || {};
        this._factory = options.factory || _N3DataFactory.default;
        this._matchSemantics = validateMatchSemantics(options.matchSemantics);
        this._entityIndex = options.entityIndex || new N3EntityIndex({
          factory: this._factory
        });
        this._entities = this._entityIndex._entities;
        this._termFromId = this._entityIndex._termFromId.bind(this._entityIndex);
        this._termToNumericId = this._entityIndex._termToNumericId.bind(this._entityIndex);
        this._termToNewNumericId = this._entityIndex._termToNewNumericId.bind(this._entityIndex);
        if (quads) this.addAll(quads);
      }
      // ## Public properties
      // ### `size` returns the number of quads in the store
      get size() {
        if (this._size === null) this._size = this.countQuads();
        return this._size;
      }
      // ## Private methods
      // ### `_addToIndex` adds a quad to a three-layered index.
      // Returns if the index has changed, if the entry did not already exist.
      _addToIndex(index0, key0, key1, key2) {
        let index1 = index0[key0];
        if (!index1) {
          index0[key0] = index1 = {
            [SIZE]: 0
          };
          index0[SIZE]++;
        }
        let index2 = index1[key1];
        if (!index2) {
          index1[key1] = index2 = {
            [SIZE]: 0
          };
          index1[SIZE]++;
        }
        const existed = key2 in index2;
        if (!existed) {
          index2[key2] = null;
          index2[SIZE]++;
        }
        return !existed;
      }
      // ### `_removeFromIndex` removes a quad from a three-layered index
      _removeFromIndex(index0, key0, key1, key2) {
        const index1 = index0[key0], index2 = index1[key1];
        delete index2[key2];
        if (--index2[SIZE] !== 0) return;
        delete index1[key1];
        if (--index1[SIZE] !== 0) return;
        delete index0[key0];
        index0[SIZE]--;
      }
      // ### `_findInIndex` finds a set of quads in a three-layered index.
      // The index base is `index0` and the keys at each level are `key0`, `key1`, and `key2`.
      // A key and any keys after it can be null or undefined, which is interpreted as a wildcard.
      // `name0`, `name1`, and `name2` are the names of the keys at each level,
      // used when reconstructing the resulting quad
      // (for instance: _subject_, _predicate_, and _object_).
      // Finally, `graphId` will be the graph of the created quads.
      *_findInIndex(index0, key0, key1, key2, name0, name1, name2, graphId) {
        const entityKeys = this._entities;
        const graph = this._termFromId(entityKeys[graphId]);
        const parts = {
          subject: null,
          predicate: null,
          object: null
        };
        if (key2) {
          const index1 = index0[key0];
          const index2 = index1 && index1[key1];
          if (!index2 || !(key2 in index2)) return;
          parts[name0] = this._termFromId(entityKeys[key0]);
          parts[name1] = this._termFromId(entityKeys[key1]);
          parts[name2] = this._termFromId(entityKeys[key2]);
          yield this._factory.quad(parts.subject, parts.predicate, parts.object, graph);
          return;
        }
        if (key0 && !(key0 in index0)) return;
        const keys0 = key0 ? null : Object.keys(index0);
        for (let i0 = 0, value0 = key0 || keys0[0]; value0; value0 = keys0 && keys0[++i0]) {
          const index1 = index0[value0];
          if (!index1) continue;
          parts[name0] = this._termFromId(entityKeys[value0]);
          if (key1 && !(key1 in index1)) return;
          const keys1 = key1 ? null : Object.keys(index1);
          for (let i1 = 0, value1 = key1 || keys1[0]; value1; value1 = keys1 && keys1[++i1]) {
            const index2 = index1[value1];
            if (!index2) continue;
            parts[name1] = this._termFromId(entityKeys[value1]);
            const values = Object.keys(index2);
            for (let l = 0; l < values.length; l++) {
              parts[name2] = this._termFromId(entityKeys[values[l]]);
              yield this._factory.quad(parts.subject, parts.predicate, parts.object, graph);
            }
          }
        }
      }
      // ### `_loop` executes the callback on all keys of index 0
      _loop(index0, callback) {
        for (const key0 in index0) callback(key0);
      }
      // ### `_loopByKey0` executes the callback on all keys of a certain entry in index 0
      _loopByKey0(index0, key0, callback) {
        let index1, key1;
        if (index1 = index0[key0]) {
          for (key1 in index1) callback(key1);
        }
      }
      // ### `_loopByKey1` executes the callback on given keys of all entries in index 0
      _loopByKey1(index0, key1, callback) {
        let key0, index1;
        for (key0 in index0) {
          index1 = index0[key0];
          if (index1[key1]) callback(key0);
        }
      }
      // ### `_loopBy2Keys` executes the callback on given keys of certain entries in index 2
      _loopBy2Keys(index0, key0, key1, callback) {
        let index1, index2, key2;
        if ((index1 = index0[key0]) && (index2 = index1[key1])) {
          for (key2 in index2) callback(key2);
        }
      }
      // ### `_loopByKey0Deep` executes the callback on all keys of index 2
      // for a certain entry in index 0, possibly repeating keys
      _loopByKey0Deep(index0, key0, callback) {
        let index1, index2, key1, key2;
        if (index1 = index0[key0]) {
          for (key1 in index1) {
            index2 = index1[key1];
            for (key2 in index2) callback(key2);
          }
        }
      }
      // ### `_countInIndex` counts matching quads in a three-layered index.
      // The index base is `index0` and the keys at each level are `key0`, `key1`, and `key2`.
      // A key and any keys after it can be null or undefined, which is interpreted as a wildcard.
      _countInIndex(index0, key0, key1, key2) {
        let count = 0, index1, index2;
        if (key0) {
          if (!(index1 = index0[key0])) return 0;
          if (key1) {
            if (!(index2 = index1[key1])) return 0;
            return key2 ? key2 in index2 ? 1 : 0 : index2[SIZE];
          }
          const keys1 = Object.keys(index1);
          for (let i1 = 0; i1 < keys1.length; i1++) count += index1[keys1[i1]][SIZE];
          return count;
        }
        const keys0 = Object.keys(index0);
        for (let i0 = 0; i0 < keys0.length; i0++) {
          index1 = index0[keys0[i0]];
          const keys1 = Object.keys(index1);
          for (let i1 = 0; i1 < keys1.length; i1++) count += index1[keys1[i1]][SIZE];
        }
        return count;
      }
      // ### `_getGraphs` returns an array with the given graph,
      // or all graphs if the argument is null or undefined.
      _getGraphs(graph) {
        graph = graph === "" ? 1 : graph && (this._termToNumericId(graph) || -1);
        return typeof graph !== "number" ? this._graphs : {
          [graph]: this._graphs[graph]
        };
      }
      // ### `_addObserver` registers a mutation observer.
      _addObserver(view) {
        const observer = new WeakRef(view);
        const registry = observerRegistry || (observerRegistry = new FinalizationRegistry(finalizeObserver));
        registry.register(view, {
          store: new WeakRef(this),
          observer
        }, observer);
        (this._observers || (this._observers = /* @__PURE__ */ new Set())).add(observer);
        return observer;
      }
      // ### `_removeObserver` unregisters a mutation observer.
      _removeObserver(observer) {
        observerRegistry.unregister(observer);
        if (this._observers) {
          this._observers.delete(observer);
          if (this._observers.size === 0) this._observers = null;
        }
      }
      // ### `_notifyObservers` notifies observers of a mutation.
      _notifyObservers(subjectId, predicateId, objectId, graphId, added) {
        for (const observer of this._observers) {
          const view = observer.deref();
          if (view) view._onParentMutation(subjectId, predicateId, objectId, graphId, added);
          else
            this._removeObserver(observer);
        }
      }
      // ### `_uniqueEntities` returns a function that accepts an entity ID
      // and passes the corresponding entity to callback if it hasn't occurred before.
      _uniqueEntities(callback) {
        const uniqueIds = /* @__PURE__ */ Object.create(null);
        return (id) => {
          if (!(id in uniqueIds)) {
            uniqueIds[id] = true;
            callback(this._termFromId(this._entities[id], this._factory));
          }
        };
      }
      // ## Public methods
      // ### `add` adds the specified quad to the dataset.
      // Returns the dataset instance it was called on.
      // Existing quads, as defined in Quad.equals, will be ignored.
      add(quad) {
        this.addQuad(quad);
        return this;
      }
      // ### `addQuad` adds a new quad to the store.
      // Returns if the quad index has changed, if the quad did not already exist.
      addQuad(subject, predicate, object, graph) {
        if (!predicate) graph = subject.graph, object = subject.object, predicate = subject.predicate, subject = subject.subject;
        graph = graph ? this._termToNewNumericId(graph) : 1;
        subject = this._termToNewNumericId(subject);
        predicate = this._termToNewNumericId(predicate);
        object = this._termToNewNumericId(object);
        return this._addQuad(subject, predicate, object, graph);
      }
      // ### `_addQuad` adds a quad using identifiers from this store's entity index.
      _addQuad(subject, predicate, object, graph) {
        let graphItem = this._graphs[graph];
        if (!graphItem) {
          graphItem = this._graphs[graph] = {
            subjects: {
              [SIZE]: 0
            },
            predicates: {
              [SIZE]: 0
            },
            objects: {
              [SIZE]: 0
            }
          };
          Object.freeze(graphItem);
          this._graphCount++;
        }
        if (this._observers !== null) {
          if (hasInIndex(graphItem.subjects, subject, predicate, object)) return false;
          this._notifyObservers(subject, predicate, object, graph, true);
        }
        if (!this._addToIndex(graphItem.subjects, subject, predicate, object)) return false;
        this._addToIndex(graphItem.predicates, predicate, object, subject);
        this._addToIndex(graphItem.objects, object, subject, predicate);
        if (this._size !== null) this._size++;
        return true;
      }
      // ### `_addFromIndex` adds the quads in the given graph indexes of a store
      // that shares this store's entity index, so no terms need to be converted.
      // With `otherGraphs`, it only adds the quads that are not in those indexes.
      // Index keys are strings, so the ids are converted back to the numbers that
      // `addQuad` uses: forwarded views compare the ids they are notified with to
      // their own numeric ids.
      _addFromIndex(graphs, otherGraphs = null) {
        for (const graphKey in graphs) {
          const subjects = graphs[graphKey].subjects, other = otherGraphs && otherGraphs[graphKey];
          const otherSubjects = other ? other.subjects : null;
          for (const subjectKey in subjects) {
            const subject = Number(subjectKey), predicates = subjects[subjectKey];
            const otherPredicates = otherSubjects && otherSubjects[subjectKey];
            for (const predicateKey in predicates) {
              const predicate = Number(predicateKey), objects = predicates[predicateKey];
              const otherObjects = otherPredicates && otherPredicates[predicateKey];
              for (const objectKey in objects) {
                if (!otherObjects || !(objectKey in otherObjects)) this._addQuad(subject, predicate, Number(objectKey), Number(graphKey));
              }
            }
          }
        }
      }
      // ### `_addIntersectionFromIndex` adds the quads that are in both of the
      // given graph indexes, walking the graphs of the first and, below them,
      // whichever index has fewer keys
      _addIntersectionFromIndex(graphs, otherGraphs) {
        for (const graphKey in graphs) {
          const other = otherGraphs[graphKey];
          if (other) {
            let subjects = graphs[graphKey].subjects, otherSubjects = other.subjects;
            if (otherSubjects[SIZE] < subjects[SIZE]) [subjects, otherSubjects] = [otherSubjects, subjects];
            for (const subjectKey in subjects) {
              let predicates = subjects[subjectKey], otherPredicates = otherSubjects[subjectKey];
              if (otherPredicates) {
                if (otherPredicates[SIZE] < predicates[SIZE]) [predicates, otherPredicates] = [otherPredicates, predicates];
                for (const predicateKey in predicates) {
                  let objects = predicates[predicateKey], otherObjects = otherPredicates[predicateKey];
                  if (otherObjects) {
                    if (otherObjects[SIZE] < objects[SIZE]) [objects, otherObjects] = [otherObjects, objects];
                    for (const objectKey in objects) {
                      if (objectKey in otherObjects) this._addQuad(Number(subjectKey), Number(predicateKey), Number(objectKey), Number(graphKey));
                    }
                  }
                }
              }
            }
          }
        }
      }
      // ### `addQuads` adds multiple quads to the store
      addQuads(quads) {
        for (let i = 0; i < quads.length; i++) this.addQuad(quads[i]);
      }
      // ### `delete` removes the specified quad from the dataset.
      // Returns the dataset instance it was called on.
      delete(quad) {
        this.removeQuad(quad);
        return this;
      }
      // ### `has` determines whether a dataset includes a certain quad or quad pattern.
      has(subjectOrQuad, predicate, object, graph) {
        if (subjectOrQuad && subjectOrQuad.subject && (predicate === void 0 || predicate === null) && (object === void 0 || object === null) && (graph === void 0 || graph === null)) ({
          subject: subjectOrQuad,
          predicate,
          object,
          graph
        } = subjectOrQuad);
        if (subjectOrQuad && predicate && object && graph !== void 0 && graph !== null) {
          const subjectId = this._termToNumericId(subjectOrQuad);
          const predicateId = this._termToNumericId(predicate);
          const objectId = this._termToNumericId(object);
          const graphId = graph === "" || (0, _N3Util.isDefaultGraph)(graph) ? 1 : this._termToNumericId(graph);
          const graphItem = graphId && this._graphs[graphId];
          return !!subjectId && !!predicateId && !!objectId && !!graphItem && hasInIndex(graphItem.subjects, subjectId, predicateId, objectId);
        }
        return !this.readQuads(subjectOrQuad, predicate, object, graph).next().done;
      }
      // ### `import` adds a stream of quads to the store
      import(stream) {
        stream.on("data", (quad) => {
          this.addQuad(quad);
        });
        return stream;
      }
      // ### `removeQuad` removes a quad from the store if it exists
      removeQuad(subject, predicate, object, graph) {
        if (!predicate) ({
          subject,
          predicate,
          object,
          graph
        } = subject);
        graph = graph ? this._termToNumericId(graph) : 1;
        if (!(subject = subject && this._termToNumericId(subject)) || !(predicate = predicate && this._termToNumericId(predicate)) || !(object = object && this._termToNumericId(object))) return false;
        return this._removeQuad(subject, predicate, object, graph);
      }
      // ### `_removeQuad` removes a quad using identifiers from this store's entity index.
      _removeQuad(subject, predicate, object, graph) {
        const graphs = this._graphs;
        const graphItem = graphs[graph];
        if (!graphItem || !hasInIndex(graphItem.subjects, subject, predicate, object)) return false;
        if (this._observers !== null) this._notifyObservers(subject, predicate, object, graph, false);
        this._removeFromIndex(graphItem.subjects, subject, predicate, object);
        this._removeFromIndex(graphItem.predicates, predicate, object, subject);
        this._removeFromIndex(graphItem.objects, object, subject, predicate);
        if (this._size !== null) this._size--;
        if (graphItem.subjects[SIZE] === 0) {
          delete graphs[graph];
          this._graphCount--;
        }
        return true;
      }
      // ### `removeQuads` removes multiple quads from the store
      removeQuads(quads) {
        for (let i = 0; i < quads.length; i++) this.removeQuad(quads[i]);
      }
      // ### `remove` removes a stream of quads from the store
      remove(stream) {
        stream.on("data", (quad) => {
          this.removeQuad(quad);
        });
        return stream;
      }
      // ### `removeMatches` removes all matching quads from the store
      // Setting any field to `undefined` or `null` indicates a wildcard.
      removeMatches(subject, predicate, object, graph) {
        const stream = new _readableStream.Readable({
          objectMode: true
        });
        const iterable = this.readQuads(subject, predicate, object, graph);
        stream._read = (size) => {
          while (--size >= 0) {
            const {
              done,
              value
            } = iterable.next();
            if (done) {
              stream.push(null);
              return;
            }
            stream.push(value);
          }
        };
        return this.remove(stream);
      }
      // ### `deleteGraph` removes all triples with the given graph from the store
      deleteGraph(graph) {
        return this.removeMatches(null, null, null, graph);
      }
      // ### `getQuads` returns an array of quads matching a pattern.
      // Setting any field to `undefined` or `null` indicates a wildcard.
      getQuads(subject, predicate, object, graph) {
        return [...this.readQuads(subject, predicate, object, graph)];
      }
      /**
       * `readQuads` returns a generator of quads matching a pattern.
       * Setting any field to `undefined` or `null` indicates a wildcard.
       * @deprecated Use `match` instead.
       */
      *readQuads(subject, predicate, object, graph) {
        const graphs = this._getGraphs(graph);
        let content, subjectId, predicateId, objectId;
        if (subject && !(subjectId = this._termToNumericId(subject)) || predicate && !(predicateId = this._termToNumericId(predicate)) || object && !(objectId = this._termToNumericId(object))) return;
        for (const graphId in graphs) {
          if (content = graphs[graphId]) {
            if (subjectId) {
              if (objectId)
                yield* this._findInIndex(content.objects, objectId, subjectId, predicateId, "object", "subject", "predicate", graphId);
              else
                yield* this._findInIndex(content.subjects, subjectId, predicateId, null, "subject", "predicate", "object", graphId);
            } else if (predicateId)
              yield* this._findInIndex(content.predicates, predicateId, objectId, null, "predicate", "object", "subject", graphId);
            else if (objectId)
              yield* this._findInIndex(content.objects, objectId, null, null, "object", "subject", "predicate", graphId);
            else
              yield* this._findInIndex(content.subjects, null, null, null, "subject", "predicate", "object", graphId);
          }
        }
      }
      // ### `match` returns a new dataset that is comprised of all quads in the current instance matching the given arguments.
      // The logic described in Quad Matching is applied for each quad in this dataset to check if it should be included in the output dataset.
      // Note: This method always returns a new DatasetCore, even if that dataset contains no quads.
      // Note: Since a DatasetCore is an unordered set, the order of the quads within the returned sequence is arbitrary.
      // Setting any field to `undefined` or `null` indicates a wildcard.
      // For backwards compatibility, the object return also implements the Readable stream interface.
      // `options.matchSemantics` controls how the view reacts to later mutations.
      match(subject, predicate, object, graph, options = null) {
        return new DatasetCoreAndReadableStream(this, subject, predicate, object, graph, {
          entityIndex: this._entityIndex,
          matchSemantics: options && options.matchSemantics !== void 0 ? options.matchSemantics : this._matchSemantics
        });
      }
      // ### `countQuads` returns the number of quads matching a pattern.
      // Setting any field to `undefined` or `null` indicates a wildcard.
      countQuads(subject, predicate, object, graph) {
        const graphs = this._getGraphs(graph);
        let count = 0, content, subjectId, predicateId, objectId;
        if (subject && !(subjectId = this._termToNumericId(subject)) || predicate && !(predicateId = this._termToNumericId(predicate)) || object && !(objectId = this._termToNumericId(object))) return 0;
        for (const graphId in graphs) {
          if (content = graphs[graphId]) {
            if (subject) {
              if (object)
                count += this._countInIndex(content.objects, objectId, subjectId, predicateId);
              else
                count += this._countInIndex(content.subjects, subjectId, predicateId, objectId);
            } else if (predicate) {
              count += this._countInIndex(content.predicates, predicateId, objectId, subjectId);
            } else if (object) {
              count += this._countInIndex(content.objects, objectId, subjectId, predicateId);
            } else {
              count += this._countInIndex(content.subjects);
            }
          }
        }
        return count;
      }
      // ### `forEach` executes the callback on all quads.
      // Setting any field to `undefined` or `null` indicates a wildcard.
      forEach(callback, subject, predicate, object, graph) {
        this.some((quad) => {
          callback(quad, this);
          return false;
        }, subject, predicate, object, graph);
      }
      // ### `every` executes the callback on all quads,
      // and returns `true` if it returns truthy for all them.
      // Setting any field to `undefined` or `null` indicates a wildcard.
      every(callback, subject, predicate, object, graph) {
        return !this.some((quad) => !callback(quad, this), subject, predicate, object, graph);
      }
      // ### `some` executes the callback on all quads,
      // and returns `true` if it returns truthy for any of them.
      // Setting any field to `undefined` or `null` indicates a wildcard.
      some(callback, subject, predicate, object, graph) {
        for (const quad of this.readQuads(subject, predicate, object, graph)) if (callback(quad, this)) return true;
        return false;
      }
      // ### `getSubjects` returns all subjects that match the pattern.
      // Setting any field to `undefined` or `null` indicates a wildcard.
      getSubjects(predicate, object, graph) {
        const results = [];
        this.forSubjects((s) => {
          results.push(s);
        }, predicate, object, graph);
        return results;
      }
      // ### `forSubjects` executes the callback on all subjects that match the pattern.
      // Setting any field to `undefined` or `null` indicates a wildcard.
      forSubjects(callback, predicate, object, graph) {
        const graphs = this._getGraphs(graph);
        let content, predicateId, objectId;
        callback = this._uniqueEntities(callback);
        if (predicate && !(predicateId = this._termToNumericId(predicate)) || object && !(objectId = this._termToNumericId(object))) return;
        for (graph in graphs) {
          if (content = graphs[graph]) {
            if (predicateId) {
              if (objectId)
                this._loopBy2Keys(content.predicates, predicateId, objectId, callback);
              else
                this._loopByKey1(content.subjects, predicateId, callback);
            } else if (objectId)
              this._loopByKey0(content.objects, objectId, callback);
            else
              this._loop(content.subjects, callback);
          }
        }
      }
      // ### `getPredicates` returns all predicates that match the pattern.
      // Setting any field to `undefined` or `null` indicates a wildcard.
      getPredicates(subject, object, graph) {
        const results = [];
        this.forPredicates((p) => {
          results.push(p);
        }, subject, object, graph);
        return results;
      }
      // ### `forPredicates` executes the callback on all predicates that match the pattern.
      // Setting any field to `undefined` or `null` indicates a wildcard.
      forPredicates(callback, subject, object, graph) {
        const graphs = this._getGraphs(graph);
        let content, subjectId, objectId;
        callback = this._uniqueEntities(callback);
        if (subject && !(subjectId = this._termToNumericId(subject)) || object && !(objectId = this._termToNumericId(object))) return;
        for (graph in graphs) {
          if (content = graphs[graph]) {
            if (subjectId) {
              if (objectId)
                this._loopBy2Keys(content.objects, objectId, subjectId, callback);
              else
                this._loopByKey0(content.subjects, subjectId, callback);
            } else if (objectId)
              this._loopByKey1(content.predicates, objectId, callback);
            else
              this._loop(content.predicates, callback);
          }
        }
      }
      // ### `getObjects` returns all objects that match the pattern.
      // Setting any field to `undefined` or `null` indicates a wildcard.
      getObjects(subject, predicate, graph) {
        const results = [];
        this.forObjects((o) => {
          results.push(o);
        }, subject, predicate, graph);
        return results;
      }
      // ### `forObjects` executes the callback on all objects that match the pattern.
      // Setting any field to `undefined` or `null` indicates a wildcard.
      forObjects(callback, subject, predicate, graph) {
        const graphs = this._getGraphs(graph);
        let content, subjectId, predicateId;
        callback = this._uniqueEntities(callback);
        if (subject && !(subjectId = this._termToNumericId(subject)) || predicate && !(predicateId = this._termToNumericId(predicate))) return;
        for (graph in graphs) {
          if (content = graphs[graph]) {
            if (subjectId) {
              if (predicateId)
                this._loopBy2Keys(content.subjects, subjectId, predicateId, callback);
              else
                this._loopByKey0Deep(content.subjects, subjectId, callback);
            } else if (predicateId)
              this._loopByKey0(content.predicates, predicateId, callback);
            else
              this._loop(content.objects, callback);
          }
        }
      }
      // ### `getGraphs` returns all graphs that match the pattern.
      // Setting any field to `undefined` or `null` indicates a wildcard.
      getGraphs(subject, predicate, object) {
        const results = [];
        this.forGraphs((g) => {
          results.push(g);
        }, subject, predicate, object);
        return results;
      }
      // ### `forGraphs` executes the callback on all graphs that match the pattern.
      // Setting any field to `undefined` or `null` indicates a wildcard.
      forGraphs(callback, subject, predicate, object) {
        for (const graph in this._graphs) {
          this.some((quad) => {
            callback(quad.graph);
            return true;
          }, subject, predicate, object, this._termFromId(this._entities[graph]));
        }
      }
      // ### `createBlankNode` creates a new blank node, returning its name
      createBlankNode(suggestedName) {
        return this._entityIndex.createBlankNode(suggestedName);
      }
      // ### `extractLists` finds and removes all list triples
      // and returns the items per list.
      // With `allowExtraArcs`, lists whose nodes carry arcs other than
      // rdf:first/rdf:rest are returned as well,
      // but left intact when `remove` is set. Ambiguous unreferenced list heads
      // with multiple non-list arcs remain errors.
      extractLists({
        remove = false,
        ignoreErrors = false,
        allowExtraArcs = false
      } = {}) {
        const lists = /* @__PURE__ */ Object.create(null);
        const onError = ignoreErrors ? () => true : (node, message) => {
          throw new Error(`${node.value} ${message}`);
        };
        const tails = this.getQuads(null, _IRIs.default.rdf.rest, _IRIs.default.rdf.nil, null);
        const toRemove = [];
        tails.forEach((tailQuad) => {
          const items = [];
          let malformed = false;
          let extraArcs = false;
          let head;
          let headPos;
          const graph = tailQuad.graph;
          const listQuads = [];
          let current = tailQuad.subject;
          while (current && !malformed) {
            const objectQuads = this.getQuads(null, null, current, null);
            const subjectQuads = this.getQuads(current, null, null, null);
            let quad, first2 = null, rest = null, parent = null;
            for (let i = 0; i < subjectQuads.length && !malformed; i++) {
              quad = subjectQuads[i];
              if (!quad.graph.equals(graph)) malformed = onError(current, "not confined to single graph");
              else if (head) malformed = onError(current, "has non-list arcs out");
              else if (quad.predicate.value === _IRIs.default.rdf.first) {
                if (first2) malformed = onError(current, "has multiple rdf:first arcs");
                else first2 = quad;
                if (remove && first2 === quad) listQuads.push(quad);
              } else if (quad.predicate.value === _IRIs.default.rdf.rest) {
                if (rest) malformed = onError(current, "has multiple rdf:rest arcs");
                else rest = quad;
                if (remove && rest === quad) listQuads.push(quad);
              } else if (objectQuads.length) {
                if (allowExtraArcs) extraArcs = true;
                else malformed = onError(current, `has non-list arc ${quad.predicate.value}`);
              } else {
                head = quad;
                headPos = "subject";
              }
            }
            for (let i = 0; i < objectQuads.length && !malformed; ++i) {
              quad = objectQuads[i];
              if (head) malformed = onError(current, "can't have coreferences");
              else if (quad.predicate.value === _IRIs.default.rdf.rest) {
                if (parent) malformed = onError(current, "has incoming rdf:rest arcs");
                else parent = quad;
              } else {
                head = quad;
                headPos = "object";
              }
            }
            if (!first2) malformed = onError(current, "has no list head");
            else items.push(first2.object);
            current = parent && parent.subject;
          }
          if (malformed) remove = false;
          else {
            items.reverse();
            if (head) lists[head[headPos].value] = items;
            if (remove && !extraArcs) {
              for (let i = 0; i < listQuads.length; i++) toRemove.push(listQuads[i]);
            }
          }
        });
        if (remove) this.removeQuads(toRemove);
        return lists;
      }
      /**
       * Returns `true` if the current dataset is a superset of the given dataset; in other words, returns `true` if
       * the given dataset is a subset of, i.e., is contained within, the current dataset.
       *
       * Blank Nodes will be normalized.
       */
      addAll(quads) {
        if (quads instanceof DatasetCoreAndReadableStream) quads = quads.filtered;
        if (Array.isArray(quads)) this.addQuads(quads);
        else if (quads instanceof _N3Store && quads._entityIndex === this._entityIndex) this._addFromIndex(quads._graphs);
        else {
          for (const quad of quads) this.add(quad);
        }
        return this;
      }
      /**
       * Returns `true` if the current dataset is a superset of the given dataset; in other words, returns `true` if
       * the given dataset is a subset of, i.e., is contained within, the current dataset.
       *
       * Blank Nodes will be normalized.
       */
      contains(other) {
        if (other instanceof DatasetCoreAndReadableStream) other = other.filtered;
        if (other === this) return true;
        if (!(other instanceof _N3Store) || this._entityIndex !== other._entityIndex) {
          const otherSize = knownSize(other), thisSize = this._size;
          if (otherSize !== null && thisSize !== null && otherSize > thisSize) return false;
          return other.every((quad) => this.has(quad));
        }
        const g1 = this._graphs, g2 = other._graphs;
        let s1, s2, p1, p2, o1, o2;
        for (const graph in g2) {
          if (!(s1 = g1[graph])) return false;
          s1 = s1.subjects;
          if ((s2 = g2[graph].subjects)[SIZE] > s1[SIZE]) return false;
          for (const subject in s2) {
            if (!(p1 = s1[subject]) || (p2 = s2[subject])[SIZE] > p1[SIZE]) return false;
            for (const predicate in p2) {
              if (!(o1 = p1[predicate]) || (o2 = p2[predicate])[SIZE] > o1[SIZE]) return false;
              for (const object in o2) if (!(object in o1)) return false;
            }
          }
        }
        return true;
      }
      /**
       * This method removes the quads in the current dataset that match the given arguments.
       *
       * The logic described in {@link https://rdf.js.org/dataset-spec/#quad-matching|Quad Matching} is applied for each
       * quad in this dataset, to select the quads which will be deleted.
       *
       * @param subject   The optional exact subject to match.
       * @param predicate The optional exact predicate to match.
       * @param object    The optional exact object to match.
       * @param graph     The optional exact graph to match.
       */
      deleteMatches(subject, predicate, object, graph) {
        for (const quad of this.match(subject, predicate, object, graph, {
          matchSemantics: "lazy"
        })) this.removeQuad(quad);
        return this;
      }
      /**
       * Returns a new dataset that contains all quads from the current dataset that are not included in the given dataset.
       */
      difference(other) {
        if (other && other instanceof DatasetCoreAndReadableStream) other = other.filtered;
        if (other === this) return new _N3Store({
          entityIndex: this._entityIndex
        });
        if (other instanceof _N3Store && other._entityIndex === this._entityIndex) {
          const store = new _N3Store({
            entityIndex: this._entityIndex
          });
          store._addFromIndex(this._graphs, other._graphs);
          return store;
        }
        return this.filter((quad) => !other.has(quad));
      }
      /**
       * Returns true if the current dataset contains the same graph structure as the given dataset.
       *
       * Blank Nodes will be normalized.
       */
      equals(other) {
        if (other instanceof DatasetCoreAndReadableStream) other = other.filtered;
        return other === this || this.size === other.size && this.contains(other);
      }
      /**
       * Creates a new dataset with all the quads that pass the test implemented by the provided `iteratee`.
       *
       * This method is aligned with Array.prototype.filter() in ECMAScript-262.
       */
      filter(iteratee) {
        const store = new _N3Store({
          entityIndex: this._entityIndex
        });
        for (const quad of this) if (iteratee(quad, this)) store.add(quad);
        return store;
      }
      /**
       * Returns a new dataset containing all quads from the current dataset that are also included in the given dataset.
       */
      intersection(other) {
        if (other instanceof DatasetCoreAndReadableStream) other = other.filtered;
        if (other === this) {
          const store = new _N3Store({
            entityIndex: this._entityIndex
          });
          store._addFromIndex(this._graphs);
          return store;
        } else if (other instanceof _N3Store && this._entityIndex === other._entityIndex) {
          const store = new _N3Store({
            entityIndex: this._entityIndex
          });
          if (this._size !== 0 && other._size !== 0) {
            if (other._graphCount < this._graphCount) store._addIntersectionFromIndex(other._graphs, this._graphs);
            else store._addIntersectionFromIndex(this._graphs, other._graphs);
          }
          return store;
        }
        const otherSize = knownSize(other), thisSize = this._size;
        if (otherSize !== null && thisSize !== null && otherSize < thisSize && typeof other[Symbol.iterator] === "function" && // unless it is a store whose custom factories may not create RDF/JS quads,
        // either for its quads or, through its entity index, for their terms
        other._factory === _N3DataFactory.default && other._entityIndex._factory === _N3DataFactory.default) {
          const store = new _N3Store({
            entityIndex: this._entityIndex
          });
          for (const quad of other) if (this.has(quad)) store.add(quad);
          return store;
        }
        return this.filter((quad) => other.has(quad));
      }
      /**
       * Returns a new dataset containing all quads returned by applying `iteratee` to each quad in the current dataset.
       */
      map(iteratee) {
        const store = new _N3Store({
          entityIndex: this._entityIndex
        });
        for (const quad of this) store.add(iteratee(quad, this));
        return store;
      }
      /**
       * This method calls the `iteratee` method on each `quad` of the `Dataset`. The first time the `iteratee` method
       * is called, the `accumulator` value is the `initialValue`, or, if not given, equals the first quad of the `Dataset`.
       * The return value of each call to the `iteratee` method is used as the `accumulator` value for the next call.
       *
       * This method returns the return value of the last `iteratee` call.
       *
       * This method is aligned with `Array.prototype.reduce()` in ECMAScript-262.
       */
      reduce(callback, initialValue) {
        const iter = this.readQuads();
        let accumulator = initialValue === void 0 ? iter.next().value : initialValue;
        for (const quad of iter) accumulator = callback(accumulator, quad, this);
        return accumulator;
      }
      /**
       * Returns the set of quads within the dataset as a host-language-native sequence, for example an `Array` in
       * ECMAScript-262.
       *
       * Since a `Dataset` is an unordered set, the order of the quads within the returned sequence is arbitrary.
       */
      toArray() {
        return this.getQuads();
      }
      /**
       * Returns an N-Quads string representation of the dataset, preprocessed with the
       * {@link https://json-ld.github.io/normalization/spec/|RDF Dataset Normalization} algorithm.
       */
      toCanonical() {
        throw new Error("not implemented");
      }
      /**
       * Returns a stream that contains all quads of the dataset.
       */
      toStream() {
        return this.match(null, null, null, null, {
          matchSemantics: "lazy"
        });
      }
      /**
       * Returns an N-Quads string representation of the dataset.
       *
       * No prior normalization is required, therefore the results for the same quads may vary depending on the `Dataset`
       * implementation.
       */
      toString() {
        return new _N3Writer.default().quadsToString(this);
      }
      /**
       * Returns a new `Dataset` that is a concatenation of this dataset and the quads given as an argument.
       */
      union(quads) {
        const store = new _N3Store({
          entityIndex: this._entityIndex
        });
        store._addFromIndex(this._graphs);
        store.addAll(quads);
        return store;
      }
      // ### Store is an iterable.
      // Returns the quad iterator directly; order is not guaranteed.
      [Symbol.iterator]() {
        return this.readQuads();
      }
    };
    exports2.default = N3Store;
    function indexMatch(index, ids, depth = 0) {
      const ind = ids[depth];
      if (ind && !(ind in index)) return false;
      let target = false, size = 0;
      for (const key in ind ? {
        [ind]: index[ind]
      } : index) {
        const result = depth === 2 ? null : indexMatch(index[key], ids, depth + 1);
        if (result !== false) {
          target = target || /* @__PURE__ */ Object.create(null);
          target[key] = result;
          size++;
        }
      }
      if (target) target[SIZE] = size;
      return target;
    }
    function snapshotMatch(store, subject, predicate, object, graph) {
      const snapshot = {
        store,
        ids: []
      };
      const subjectId = subject && store._termToNumericId(subject);
      const predicateId = predicate && store._termToNumericId(predicate);
      const objectId = object && store._termToNumericId(object);
      let indexName, key0, key1, key2, positions;
      if (objectId && (subjectId || !predicateId)) {
        indexName = "objects";
        [key0, key1, key2] = [objectId, subjectId, predicateId];
        positions = [2, 0, 1];
      } else if (!subjectId && predicateId) {
        indexName = "predicates";
        [key0, key1, key2] = [predicateId, objectId, subjectId];
        positions = [1, 2, 0];
      } else {
        indexName = "subjects";
        [key0, key1, key2] = [subjectId, predicateId, objectId];
        positions = [0, 1, 2];
      }
      const graphs = store._getGraphs(graph), parts = [];
      for (const graphId in graphs) {
        const index = graphs[graphId][indexName];
        const graphKey = Number(graphId);
        for (const value0 in key0 ? {
          [key0]: index[key0]
        } : index) {
          const index1 = index[value0];
          if (!index1) continue;
          parts[positions[0]] = Number(value0);
          for (const value1 in key1 ? {
            [key1]: index1[key1]
          } : index1) {
            const index2 = index1[value1];
            if (!index2) continue;
            parts[positions[1]] = Number(value1);
            for (const value2 in key2 ? key2 in index2 ? {
              [key2]: null
            } : {} : index2) {
              parts[positions[2]] = Number(value2);
              snapshot.ids.push(parts[0], parts[1], parts[2], graphKey);
            }
          }
        }
      }
      return snapshot;
    }
    function* iterateSnapshot({
      store,
      ids
    }, offset) {
      const entities = store._entities;
      let subject, predicate, object, graph;
      let subjectId, predicateId, objectId, graphId;
      for (let i = offset * 4; i < ids.length; i += 4) {
        if (subjectId !== ids[i]) subject = store._termFromId(entities[subjectId = ids[i]]);
        if (predicateId !== ids[i + 1]) predicate = store._termFromId(entities[predicateId = ids[i + 1]]);
        if (objectId !== ids[i + 2]) object = store._termFromId(entities[objectId = ids[i + 2]]);
        if (graphId !== ids[i + 3]) graph = store._termFromId(entities[graphId = ids[i + 3]]);
        yield store._factory.quad(subject, predicate, object, graph);
      }
    }
    function validateMatchSemantics(semantics = "lazy") {
      if (semantics !== "lazy" && semantics !== "snapshot" && semantics !== "forwarded") throw new Error(`Unknown matchSemantics: ${semantics}`);
      if (semantics !== "lazy" && (typeof WeakRef !== "function" || typeof FinalizationRegistry !== "function")) throw new Error("Non-lazy matchSemantics requires WeakRef and FinalizationRegistry support");
      return semantics;
    }
    function intersectMatchPatterns(left, right) {
      const result = new Array(4);
      for (let i = 0; i < 4; i++) {
        const leftTerm = left[i], rightTerm = right[i];
        if (leftTerm === null || leftTerm === void 0) result[i] = rightTerm;
        else if (rightTerm === null || rightTerm === void 0 || entityKey(leftTerm) === entityKey(rightTerm)) result[i] = leftTerm;
        else return false;
      }
      return result;
    }
    var DatasetCoreAndReadableStream = class _DatasetCoreAndReadableStream extends _readableStream.Readable {
      constructor(n3Store, subject, predicate, object, graph, options) {
        super({
          objectMode: true
        });
        Object.assign(this, {
          n3Store,
          subject,
          predicate,
          object,
          graph,
          options
        });
        const semantics = this._semantics = validateMatchSemantics(options.matchSemantics);
        if (options.matchesNothing) {
          this._matchesNothing = true;
          this._filtered = new N3Store({
            factory: n3Store._factory,
            entityIndex: options.entityIndex
          });
        }
        if (semantics !== "lazy") {
          this._readers = null;
          this._subjectId = this._predicateId = this._objectId = this._graphId = void 0;
          if (!this._matchesNothing) {
            this._observer = n3Store._addObserver(this);
          }
        }
      }
      // ### `_matchesPattern` tests quad ids against this view.
      _matchesPattern(subjectId, predicateId, objectId, graphId) {
        const {
          subject,
          predicate,
          object,
          graph,
          n3Store
        } = this;
        if (subject && subjectId !== (this._subjectId || (this._subjectId = n3Store._termToNumericId(subject)))) return false;
        if (predicate && predicateId !== (this._predicateId || (this._predicateId = n3Store._termToNumericId(predicate)))) return false;
        if (object && objectId !== (this._objectId || (this._objectId = n3Store._termToNumericId(object)))) return false;
        return graph === null || graph === void 0 || graphId === (this._graphId || (this._graphId = graph === "" || (0, _N3Util.isDefaultGraph)(graph) ? 1 : n3Store._termToNumericId(graph)));
      }
      // ### `_matchesQuad` tests a Quad against this view.
      _matchesQuad(quad) {
        const {
          subject,
          predicate,
          object,
          graph
        } = this;
        return !this._matchesNothing && (subject === null || subject === void 0 || entityKey(subject) === entityKey(quad.subject)) && (predicate === null || predicate === void 0 || entityKey(predicate) === entityKey(quad.predicate)) && (object === null || object === void 0 || entityKey(object) === entityKey(quad.object)) && (graph === null || graph === void 0 || entityKey(graph) === entityKey(quad.graph));
      }
      // ### `_assertMatchesPattern` rejects a Quad outside this view.
      _assertMatchesPattern(quad) {
        if (!this._matchesQuad(quad)) throw new Error("Quad does not match the forwarded view pattern");
      }
      // ### `_sourceIterator` returns an iterator over the current backing store.
      _sourceIterator() {
        return this._filtered ? this._filtered[Symbol.iterator]() : this.n3Store.readQuads(this.subject, this.predicate, this.object, this.graph);
      }
      // ### `_freezeCurrentIterators` freezes only readers still using the live source.
      _freezeCurrentIterators() {
        if (this._readers) {
          this._readers.snapshot = this._filtered ? snapshotMatch(this._filtered) : snapshotMatch(this.n3Store, this.subject, this.predicate, this.object, this.graph);
          this._readers = null;
        }
      }
      // ### `_onParentMutation` applies a parent mutation to this view.
      _onParentMutation(subjectId, predicateId, objectId, graphId, added) {
        if (!this._matchesPattern(subjectId, predicateId, objectId, graphId)) return;
        this._freezeCurrentIterators();
        if (this._semantics === "forwarded") {
          if (this._filtered) {
            if (added) this._filtered._addQuad(subjectId, predicateId, objectId, graphId);
            else this._filtered._removeQuad(subjectId, predicateId, objectId, graphId);
          }
          return;
        }
        this._filtered = this.filtered;
      }
      get filtered() {
        if (!this._filtered) {
          const {
            n3Store,
            graph,
            object,
            predicate,
            subject
          } = this;
          if (this._semantics !== "lazy") this._freezeCurrentIterators();
          const newStore = this._filtered = new N3Store({
            factory: n3Store._factory,
            entityIndex: this.options.entityIndex
          });
          if (this._semantics === "snapshot") this._detachObserver();
          let subjectId, predicateId, objectId;
          if (subject && !(subjectId = newStore._termToNumericId(subject)) || predicate && !(predicateId = newStore._termToNumericId(predicate)) || object && !(objectId = newStore._termToNumericId(object))) return newStore;
          const graphs = n3Store._getGraphs(graph);
          for (const graphKey in graphs) {
            let subjects, predicates, objects, content;
            if (content = graphs[graphKey]) {
              if (!subjectId && predicateId) {
                if (predicates = indexMatch(content.predicates, [predicateId, objectId, subjectId])) {
                  subjects = indexMatch(content.subjects, [subjectId, predicateId, objectId]);
                  objects = indexMatch(content.objects, [objectId, subjectId, predicateId]);
                }
              } else if (objectId) {
                if (objects = indexMatch(content.objects, [objectId, subjectId, predicateId])) {
                  subjects = indexMatch(content.subjects, [subjectId, predicateId, objectId]);
                  predicates = indexMatch(content.predicates, [predicateId, objectId, subjectId]);
                }
              } else if (subjects = indexMatch(content.subjects, [subjectId, predicateId, objectId])) {
                predicates = indexMatch(content.predicates, [predicateId, objectId, subjectId]);
                objects = indexMatch(content.objects, [objectId, subjectId, predicateId]);
              }
              if (subjects) {
                newStore._graphs[graphKey] = {
                  subjects,
                  predicates,
                  objects
                };
                newStore._graphCount++;
              }
            }
          }
          newStore._size = null;
        }
        return this._filtered;
      }
      get size() {
        return this.filtered.size;
      }
      _read(size) {
        if (size > 0 && !this[ITERATOR]) this[ITERATOR] = this[Symbol.iterator]();
        const iterable = this[ITERATOR];
        while (--size >= 0) {
          const {
            done,
            value
          } = iterable.next();
          if (done) {
            this.push(null);
            return;
          }
          this.push(value);
        }
      }
      // ### `_destroy` closes the cached iterator.
      _destroy(error, callback) {
        if (this[ITERATOR]) {
          this[ITERATOR].return();
          this[ITERATOR] = null;
        }
        callback(error);
      }
      // ### `_detachObserver` stops observing the parent store.
      _detachObserver() {
        if (this._observer) {
          this.n3Store._removeObserver(this._observer);
          this._observer = null;
        }
      }
      // ### `_detach` freezes the view and stops observing the parent.
      _detach() {
        this._filtered = this.filtered;
        this._detachObserver();
        if (this._semantics === "lazy") this._readers = null;
        this._semantics = "snapshot";
        return this;
      }
      addAll(quads) {
        if (this._semantics === "forwarded") {
          for (const quad of quads) {
            this._assertMatchesPattern(quad);
            this.n3Store.addQuad(quad);
          }
          return this;
        }
        return this.filtered.addAll(quads);
      }
      contains(other) {
        return this.filtered.contains(other);
      }
      deleteMatches(subject, predicate, object, graph) {
        if (this._semantics === "forwarded") {
          if (this._matchesNothing) throw new Error("Cannot delete from a conflicting forwarded view pattern");
          const pattern = intersectMatchPatterns([this.subject, this.predicate, this.object, this.graph], [subject, predicate, object, graph]);
          if (!pattern) throw new Error("Deletion pattern does not match the forwarded view pattern");
          this.n3Store.deleteMatches(...pattern);
          return this;
        }
        return this.filtered.deleteMatches(subject, predicate, object, graph);
      }
      difference(other) {
        return this.filtered.difference(other);
      }
      equals(other) {
        return this.filtered.equals(other);
      }
      every(callback, subject, predicate, object, graph) {
        return this.filtered.every(this._semantics === "forwarded" ? (quad) => callback(quad, this) : callback, subject, predicate, object, graph);
      }
      filter(iteratee) {
        return this.filtered.filter(this._semantics === "forwarded" ? (quad) => iteratee(quad, this) : iteratee);
      }
      forEach(callback, subject, predicate, object, graph) {
        return this.filtered.forEach(this._semantics === "forwarded" ? (quad) => callback(quad, this) : callback, subject, predicate, object, graph);
      }
      import(stream) {
        if (this._semantics !== "forwarded") return this.filtered.import(stream);
        const view = this;
        function onData(quad) {
          try {
            view._assertMatchesPattern(quad);
            view.n3Store.addQuad(quad);
          } catch (error) {
            stream.removeListener("data", onData);
            if (typeof stream.destroy === "function") stream.destroy(error);
            else stream.emit("error", error);
          }
        }
        stream.on("data", onData);
        return stream;
      }
      intersection(other) {
        return this.filtered.intersection(other);
      }
      map(iteratee) {
        return this.filtered.map(this._semantics === "forwarded" ? (quad) => iteratee(quad, this) : iteratee);
      }
      some(callback, subject, predicate, object, graph) {
        return this.filtered.some(this._semantics === "forwarded" ? (quad) => callback(quad, this) : callback, subject, predicate, object, graph);
      }
      toCanonical() {
        return this.filtered.toCanonical();
      }
      toStream() {
        if (this._semantics !== "lazy")
          return _readableStream.Readable.from(this[Symbol.iterator]());
        return this._filtered ? this._filtered.toStream() : this.n3Store.match(this.subject, this.predicate, this.object, this.graph, {
          matchSemantics: "lazy"
        });
      }
      union(quads) {
        return this._filtered ? this._filtered.union(quads) : this.n3Store.match(this.subject, this.predicate, this.object, this.graph, {
          matchSemantics: "lazy"
        }).addAll(quads);
      }
      toArray() {
        if (this._semantics !== "lazy") return [...this];
        return this._filtered ? this._filtered.toArray() : this.n3Store.getQuads(this.subject, this.predicate, this.object, this.graph);
      }
      reduce(callback, initialValue) {
        return this.filtered.reduce(this._semantics === "forwarded" ? (accumulator, quad) => callback(accumulator, quad, this) : callback, initialValue);
      }
      toString() {
        return new _N3Writer.default().quadsToString(this);
      }
      add(quad) {
        if (this._semantics === "forwarded") {
          this._assertMatchesPattern(quad);
          this.n3Store.addQuad(quad);
          return this;
        }
        return this.filtered.add(quad);
      }
      delete(quad) {
        if (this._semantics === "forwarded") {
          this._assertMatchesPattern(quad);
          this.n3Store.removeQuad(quad);
          return this;
        }
        return this.filtered.delete(quad);
      }
      has(quad) {
        return this.filtered.has(quad);
      }
      match(subject, predicate, object, graph, options = null) {
        const requestedSemantics = options && options.matchSemantics;
        if (options && requestedSemantics !== void 0) {
          validateMatchSemantics(requestedSemantics);
          if (requestedSemantics !== this._semantics) throw new Error(`Cannot override matchSemantics on a view: inherited "${this._semantics}", received "${requestedSemantics}"`);
        }
        if (this._semantics !== "forwarded") return new _DatasetCoreAndReadableStream(this.filtered, subject, predicate, object, graph, {
          entityIndex: this.options.entityIndex,
          matchSemantics: this._semantics
        });
        const pattern = !this._matchesNothing && intersectMatchPatterns([this.subject, this.predicate, this.object, this.graph], [subject, predicate, object, graph]);
        const [matchedSubject, matchedPredicate, matchedObject, matchedGraph] = pattern || [null, null, null, null];
        return new _DatasetCoreAndReadableStream(this.n3Store, matchedSubject, matchedPredicate, matchedObject, matchedGraph, {
          entityIndex: this.options.entityIndex,
          matchSemantics: "forwarded",
          matchesNothing: !pattern
        });
      }
      [Symbol.iterator]() {
        return this._semantics === "lazy" ? this._sourceIterator() : this._iterateStable();
      }
      *_iterateStable() {
        const readers = this._readers || (this._readers = {
          count: 0,
          snapshot: null
        });
        const source = this._sourceIterator();
        let yielded = 0;
        readers.count++;
        try {
          while (!readers.snapshot) {
            const {
              value,
              done
            } = source.next();
            if (readers.snapshot || done) break;
            yielded++;
            yield value;
          }
          if (readers.snapshot) yield* iterateSnapshot(readers.snapshot, yielded);
        } finally {
          source.return();
          if (--readers.count === 0) {
            readers.snapshot = null;
            if (this._readers === readers) this._readers = null;
          }
        }
      }
    };
  }
});

// ../vscode/node_modules/n3/lib/N3StoreFactory.js
var require_N3StoreFactory = __commonJS({
  "../vscode/node_modules/n3/lib/N3StoreFactory.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    exports2.default = void 0;
    var _N3Store = _interopRequireDefault(require_N3Store());
    function _interopRequireDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var N3DatasetCoreFactory = class {
      dataset(quads) {
        return new _N3Store.default(quads);
      }
    };
    exports2.default = N3DatasetCoreFactory;
  }
});

// ../vscode/node_modules/n3/lib/N3Reasoner.js
var require_N3Reasoner = __commonJS({
  "../vscode/node_modules/n3/lib/N3Reasoner.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    exports2.default = void 0;
    exports2.getRulesFromDataset = getRulesFromDataset;
    var _N3DataFactory = _interopRequireDefault(require_N3DataFactory());
    function _interopRequireDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    function getRulesFromDataset(dataset) {
      const rules = [];
      for (const {
        subject,
        object
      } of dataset.match(null, _N3DataFactory.default.namedNode("http://www.w3.org/2000/10/swap/log#implies"), null, _N3DataFactory.default.defaultGraph())) {
        const premise = [...dataset.match(null, null, null, subject)];
        const conclusion = [...dataset.match(null, null, null, object)];
        rules.push({
          premise,
          conclusion
        });
      }
      return rules;
    }
    var N3Reasoner = class {
      constructor(store, options = {}) {
        this._store = store;
        this._maxDerivations = options.maxDerivations === void 0 ? Infinity : options.maxDerivations;
        this._maxPremiseDepth = options.maxPremiseDepth === void 0 ? Infinity : options.maxPremiseDepth;
      }
      _add(subject, predicate, object, graphItem, c, cb) {
        const store = this._store;
        if (store._observers) {
          if (!store._addQuad(subject, predicate, object, this._graphId)) return;
        } else {
          if (!store._addToIndex(graphItem.subjects, subject, predicate, object)) return;
          store._addToIndex(graphItem.predicates, predicate, object, subject);
          store._addToIndex(graphItem.objects, object, subject, predicate);
          this._indexed++;
        }
        if (++this._derivations > this._maxDerivations) throw new Error(`Reasoning exceeded the maximum of ${this._maxDerivations} derivations`);
        cb(c);
      }
      // Emit conclusions without allocating per-match callbacks
      _emit(rule, content, cb) {
        const conclusion = rule.conclusion;
        for (let k = 0; k < conclusion.length; k++) {
          const c = conclusion[k];
          this._add(c.subject.value, c.predicate.value, c.object.value, content, c, cb);
        }
      }
      // Bound values use direct lookups; unbound values scan the index
      _evaluatePremise(rule, content, cb, i = 0) {
        let value, index1;
        const [val0, val1, val2] = rule.premise[i].value, index = content[rule.premise[i].content];
        const last = i === rule.premise.length - 1;
        const v0 = !(value = val0.value);
        if (v0) {
          for (value in index) {
            index1 = index[value];
            val0.value = Number(value);
            this._evaluateLevel1(rule, content, cb, i, last, val1, val2, index1);
          }
          val0.value = null;
        } else if (index1 = index[value]) {
          this._evaluateLevel1(rule, content, cb, i, last, val1, val2, index1);
        }
      }
      _evaluateLevel1(rule, content, cb, i, last, val1, val2, index1) {
        let value, index2;
        const v1 = !(value = val1.value);
        if (v1) {
          for (value in index1) {
            index2 = index1[value];
            val1.value = Number(value);
            this._evaluateLevel2(rule, content, cb, i, last, val2, index2);
          }
          val1.value = null;
        } else if (index2 = index1[value]) {
          this._evaluateLevel2(rule, content, cb, i, last, val2, index2);
        }
      }
      _evaluateLevel2(rule, content, cb, i, last, val2, index2) {
        let value;
        const v2 = !(value = val2.value);
        if (v2) {
          for (value in index2) {
            val2.value = Number(value);
            if (last) this._emit(rule, content, cb);
            else this._evaluatePremise(rule, content, cb, i + 1);
          }
          val2.value = null;
        } else if (value in index2) {
          if (last) this._emit(rule, content, cb);
          else this._evaluatePremise(rule, content, cb, i + 1);
        }
      }
      _evaluateRules(rules, content, cb) {
        for (let i = 0; i < rules.length; i++) {
          this._evaluatePremise(rules[i], content, cb);
        }
      }
      // A naive reasoning algorithm where rules are just applied by repeatedly applying rules
      // until no more evaluations are made
      _reasonGraphNaive(rules, content) {
        const newRules = [];
        function addRule(conclusion) {
          if (conclusion.next) conclusion.next.forEach((rule) => {
            newRules.push([conclusion.subject.value, conclusion.predicate.value, conclusion.object.value, rule]);
          });
        }
        const addConclusions = (conclusion) => {
          for (let k = 0; k < conclusion.length; k++) {
            const c = conclusion[k];
            this._add(c.subject.value, c.predicate.value, c.object.value, content, c, addRule);
          }
        };
        this._evaluateRules(rules, content, addRule);
        let r;
        while ((r = newRules.pop()) !== void 0) {
          const [subject, predicate, object, rule] = r;
          const v1 = rule.basePremise.subject.value;
          if (!v1) rule.basePremise.subject.value = subject;
          const v2 = rule.basePremise.predicate.value;
          if (!v2) rule.basePremise.predicate.value = predicate;
          const v3 = rule.basePremise.object.value;
          if (!v3) rule.basePremise.object.value = object;
          const {
            basePremise
          } = rule;
          if (basePremise.subject.value === subject && basePremise.predicate.value === predicate && basePremise.object.value === object) {
            if (rule.premise.length === 0) addConclusions(rule.conclusion);
            else this._evaluatePremise(rule, content, addRule);
          }
          if (!v1) rule.basePremise.subject.value = null;
          if (!v2) rule.basePremise.predicate.value = null;
          if (!v3) rule.basePremise.object.value = null;
        }
      }
      _createRule({
        premise,
        conclusion
      }) {
        const varMapping = /* @__PURE__ */ Object.create(null);
        const toId = (value) => value.termType === "Variable" ? (
          // If the term is a variable, then create an empty object that values can be placed into
          varMapping[value.value] = varMapping[value.value] || {}
        ) : (
          // If the term is not a variable, then set the ID value
          {
            value: this._store._termToNewNumericId(value)
          }
        );
        const t = (term) => ({
          subject: toId(term.subject),
          predicate: toId(term.predicate),
          object: toId(term.object)
        });
        return {
          premise: premise.map((p) => t(p)),
          conclusion: conclusion.map((p) => t(p)),
          variables: Object.values(varMapping)
        };
      }
      reason(rules) {
        this._derivations = this._indexed = 0;
        if (!Array.isArray(rules)) {
          rules = getRulesFromDataset(rules);
        }
        rules = rules.map((rule) => this._createRule(rule));
        for (const rule of rules) {
          if (rule.premise.length > this._maxPremiseDepth) throw new Error(`Reasoning rule exceeds the maximum premise depth of ${this._maxPremiseDepth}`);
        }
        for (const r1 of rules) {
          for (const r2 of rules) {
            for (let i = 0; i < r2.premise.length; i++) {
              const p = r2.premise[i];
              for (const c of r1.conclusion) {
                if (termEq(p.subject, c.subject) && termEq(p.predicate, c.predicate) && termEq(p.object, c.object)) {
                  const set = /* @__PURE__ */ new Set();
                  const premise = [];
                  p.subject.value = p.subject.value || 1;
                  p.object.value = p.object.value || 1;
                  p.predicate.value = p.predicate.value || 1;
                  for (let j = 0; j < r2.premise.length; j++) {
                    if (j !== i) {
                      premise.push(getIndex(r2.premise[j], set));
                    }
                  }
                  (c.next = c.next || []).push({
                    premise,
                    conclusion: r2.conclusion,
                    // This is a single premise of the form { subject, predicate, object },
                    // which we can use to instantiate the rule using the new data that was emitted
                    basePremise: p
                  });
                }
                for (let k = 0; k < r2.variables.length; k++) r2.variables[k].value = null;
              }
            }
          }
        }
        for (const rule of rules) {
          const set = /* @__PURE__ */ new Set();
          rule.premise = rule.premise.map((p) => getIndex(p, set));
        }
        const graphs = this._store._getGraphs();
        try {
          for (const graphId in graphs) {
            this._graphId = Number(graphId);
            this._reasonGraphNaive(rules, graphs[graphId]);
          }
        } finally {
          if (this._store._size !== null) this._store._size += this._indexed;
        }
      }
    };
    exports2.default = N3Reasoner;
    function getIndex({
      subject,
      predicate,
      object
    }, set) {
      const s = subject.value || set.has(subject) || (set.add(subject), false);
      const p = predicate.value || set.has(predicate) || (set.add(predicate), false);
      const o = object.value || set.has(object) || (set.add(object), false);
      return !s && p ? {
        content: "predicates",
        value: [predicate, object, subject]
      } : o ? {
        content: "objects",
        value: [object, subject, predicate]
      } : {
        content: "subjects",
        value: [subject, predicate, object]
      };
    }
    function termEq(t1, t2) {
      if (t1.value === null) {
        t1.value = t2.value;
      }
      return t1.value === t2.value;
    }
  }
});

// ../vscode/node_modules/n3/lib/N3StreamParser.js
var require_N3StreamParser = __commonJS({
  "../vscode/node_modules/n3/lib/N3StreamParser.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    exports2.default = void 0;
    var _readableStream = require_ours();
    var _N3Parser = _interopRequireDefault(require_N3Parser());
    function _interopRequireDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var N3StreamParser = class extends _readableStream.Transform {
      constructor(options) {
        super({
          decodeStrings: true,
          readableObjectMode: true
        });
        const parser = new _N3Parser.default(options);
        let onData, onEnd;
        const callbacks = {
          // Handle quads by pushing them down the pipeline
          onQuad: (error, quad) => {
            error && this.emit("error", error) || quad && this.push(quad);
          },
          // Emit prefixes through the `prefix` event
          onPrefix: (prefix, uri) => {
            this.emit("prefix", prefix, uri);
          },
          // Emit additional directives through the `directive` event
          onDirective: (name) => {
            this.emit("directive", name);
          }
        };
        if (options && options.comments) callbacks.onComment = (comment) => {
          this.emit("comment", comment);
        };
        parser.parse({
          on: (event, callback) => {
            switch (event) {
              case "data":
                onData = callback;
                break;
              case "end":
                onEnd = callback;
                break;
            }
          }
        }, callbacks);
        this._transform = (chunk, encoding, done) => {
          onData(chunk);
          done();
        };
        this._flush = (done) => {
          onEnd();
          done();
        };
      }
      // ### Parses a stream of strings
      import(stream) {
        stream.on("error", (error) => {
          this.emit("error", error);
        });
        if (typeof stream.pipe === "function") stream.pipe(this);
        else {
          stream.on("data", (chunk) => {
            this.write(chunk);
          });
          stream.on("end", () => {
            this.end();
          });
        }
        return this;
      }
    };
    exports2.default = N3StreamParser;
  }
});

// ../vscode/node_modules/n3/lib/N3StreamWriter.js
var require_N3StreamWriter = __commonJS({
  "../vscode/node_modules/n3/lib/N3StreamWriter.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    exports2.default = void 0;
    var _readableStream = require_ours();
    var _N3Writer = _interopRequireDefault(require_N3Writer());
    function _interopRequireDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var MIN_CHUNK_SIZE = 16 * 1024;
    var DEFAULT_FLUSH_DELAY_MS = 20;
    var N3StreamWriter = class extends _readableStream.Transform {
      constructor(options) {
        super({
          encoding: "utf8",
          writableObjectMode: true
        });
        this._buffer = "";
        this._flushTimer = null;
        this._flushDelay = options && options.flushDelay !== void 0 ? options.flushDelay : DEFAULT_FLUSH_DELAY_MS;
        const writer = this._writer = new _N3Writer.default({
          write: (chunk, encoding, callback) => {
            this._buffer += chunk;
            if (this._buffer.length >= MIN_CHUNK_SIZE) this._pushBuffer();
            else if (this._flushTimer === null) this._armFlushTimer();
            callback && callback();
          },
          end: (callback) => {
            this._pushBuffer();
            this.push(null);
            callback && callback();
          }
        }, options);
        let pendingDone = null;
        const quadDone = (error) => {
          const done = pendingDone;
          pendingDone = null;
          if (error) this._pushBuffer();
          done(error);
        };
        this._transform = (quad, encoding, done) => {
          pendingDone = done;
          writer.addQuad(quad, quadDone);
        };
        this._flush = (done) => {
          writer.end(done);
        };
      }
      // ### `_pushBuffer` flushes coalesced output to the stream queue
      _pushBuffer() {
        this._clearFlushTimer();
        if (this._buffer !== "") {
          this.push(this._buffer);
          this._buffer = "";
        }
      }
      // ### `_armFlushTimer` schedules a partial-chunk flush
      _armFlushTimer() {
        this._flushTimer = setTimeout(() => {
          this._flushTimer = null;
          this._pushBuffer();
        }, this._flushDelay);
        this._flushTimer.unref && this._flushTimer.unref();
      }
      // ### `_clearFlushTimer` cancels a scheduled flush
      _clearFlushTimer() {
        if (this._flushTimer !== null) {
          clearTimeout(this._flushTimer);
          this._flushTimer = null;
        }
      }
      // ### `_destroy` cancels a scheduled flush, so it cannot fire afterwards
      _destroy(error, callback) {
        this._clearFlushTimer();
        super._destroy(error, callback);
      }
      // ### Serializes a stream of quads
      import(stream) {
        stream.on("data", (quad) => {
          this.write(quad);
        });
        stream.on("end", () => {
          this.end();
        });
        stream.on("error", (error) => {
          this._pushBuffer();
          this.emit("error", error);
        });
        stream.on("prefix", (prefix, iri) => {
          this._writer.addPrefix(prefix, iri);
        });
        return this;
      }
    };
    exports2.default = N3StreamWriter;
  }
});

// ../vscode/node_modules/n3/lib/index.js
var require_lib = __commonJS({
  "../vscode/node_modules/n3/lib/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", {
      value: true
    });
    Object.defineProperty(exports2, "BaseIRI", {
      enumerable: true,
      get: function() {
        return _BaseIRI.default;
      }
    });
    Object.defineProperty(exports2, "BlankNode", {
      enumerable: true,
      get: function() {
        return _N3DataFactory.BlankNode;
      }
    });
    Object.defineProperty(exports2, "DataFactory", {
      enumerable: true,
      get: function() {
        return _N3DataFactory.default;
      }
    });
    Object.defineProperty(exports2, "DefaultGraph", {
      enumerable: true,
      get: function() {
        return _N3DataFactory.DefaultGraph;
      }
    });
    Object.defineProperty(exports2, "EntityIndex", {
      enumerable: true,
      get: function() {
        return _N3Store.N3EntityIndex;
      }
    });
    Object.defineProperty(exports2, "Lexer", {
      enumerable: true,
      get: function() {
        return _N3Lexer.default;
      }
    });
    Object.defineProperty(exports2, "Literal", {
      enumerable: true,
      get: function() {
        return _N3DataFactory.Literal;
      }
    });
    Object.defineProperty(exports2, "NamedNode", {
      enumerable: true,
      get: function() {
        return _N3DataFactory.NamedNode;
      }
    });
    Object.defineProperty(exports2, "Parser", {
      enumerable: true,
      get: function() {
        return _N3Parser.default;
      }
    });
    Object.defineProperty(exports2, "Quad", {
      enumerable: true,
      get: function() {
        return _N3DataFactory.Quad;
      }
    });
    Object.defineProperty(exports2, "Reasoner", {
      enumerable: true,
      get: function() {
        return _N3Reasoner.default;
      }
    });
    Object.defineProperty(exports2, "Store", {
      enumerable: true,
      get: function() {
        return _N3Store.default;
      }
    });
    Object.defineProperty(exports2, "StoreFactory", {
      enumerable: true,
      get: function() {
        return _N3StoreFactory.default;
      }
    });
    Object.defineProperty(exports2, "StreamParser", {
      enumerable: true,
      get: function() {
        return _N3StreamParser.default;
      }
    });
    Object.defineProperty(exports2, "StreamWriter", {
      enumerable: true,
      get: function() {
        return _N3StreamWriter.default;
      }
    });
    Object.defineProperty(exports2, "Term", {
      enumerable: true,
      get: function() {
        return _N3DataFactory.Term;
      }
    });
    Object.defineProperty(exports2, "Triple", {
      enumerable: true,
      get: function() {
        return _N3DataFactory.Triple;
      }
    });
    exports2.Util = void 0;
    Object.defineProperty(exports2, "Variable", {
      enumerable: true,
      get: function() {
        return _N3DataFactory.Variable;
      }
    });
    Object.defineProperty(exports2, "Writer", {
      enumerable: true,
      get: function() {
        return _N3Writer.default;
      }
    });
    exports2.default = void 0;
    Object.defineProperty(exports2, "getRulesFromDataset", {
      enumerable: true,
      get: function() {
        return _N3Reasoner.getRulesFromDataset;
      }
    });
    Object.defineProperty(exports2, "termFromId", {
      enumerable: true,
      get: function() {
        return _N3DataFactory.termFromId;
      }
    });
    Object.defineProperty(exports2, "termToId", {
      enumerable: true,
      get: function() {
        return _N3DataFactory.termToId;
      }
    });
    var _N3Lexer = _interopRequireDefault(require_N3Lexer());
    var _N3Parser = _interopRequireDefault(require_N3Parser());
    var _N3Writer = _interopRequireDefault(require_N3Writer());
    var _N3Store = _interopRequireWildcard(require_N3Store());
    var _N3StoreFactory = _interopRequireDefault(require_N3StoreFactory());
    var _N3Reasoner = _interopRequireWildcard(require_N3Reasoner());
    var _N3StreamParser = _interopRequireDefault(require_N3StreamParser());
    var _N3StreamWriter = _interopRequireDefault(require_N3StreamWriter());
    var Util = _interopRequireWildcard(require_N3Util());
    exports2.Util = Util;
    var _BaseIRI = _interopRequireDefault(require_BaseIRI());
    var _N3DataFactory = _interopRequireWildcard(require_N3DataFactory());
    function _interopRequireWildcard(e, t) {
      if ("function" == typeof WeakMap) var r = /* @__PURE__ */ new WeakMap(), n = /* @__PURE__ */ new WeakMap();
      return (_interopRequireWildcard = function(e2, t2) {
        if (!t2 && e2 && e2.__esModule) return e2;
        var o, i, f = { __proto__: null, default: e2 };
        if (null === e2 || "object" != typeof e2 && "function" != typeof e2) return f;
        if (o = t2 ? n : r) {
          if (o.has(e2)) return o.get(e2);
          o.set(e2, f);
        }
        for (const t3 in e2) "default" !== t3 && {}.hasOwnProperty.call(e2, t3) && ((i = (o = Object.defineProperty) && Object.getOwnPropertyDescriptor(e2, t3)) && (i.get || i.set) ? o(f, t3, i) : f[t3] = e2[t3]);
        return f;
      })(e, t);
    }
    function _interopRequireDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var _default = exports2.default = {
      Lexer: _N3Lexer.default,
      Parser: _N3Parser.default,
      Writer: _N3Writer.default,
      Store: _N3Store.default,
      StoreFactory: _N3StoreFactory.default,
      EntityIndex: _N3Store.N3EntityIndex,
      StreamParser: _N3StreamParser.default,
      StreamWriter: _N3StreamWriter.default,
      Util,
      Reasoner: _N3Reasoner.default,
      BaseIRI: _BaseIRI.default,
      DataFactory: _N3DataFactory.default,
      Term: _N3DataFactory.Term,
      NamedNode: _N3DataFactory.NamedNode,
      Literal: _N3DataFactory.Literal,
      BlankNode: _N3DataFactory.BlankNode,
      Variable: _N3DataFactory.Variable,
      DefaultGraph: _N3DataFactory.DefaultGraph,
      Quad: _N3DataFactory.Quad,
      Triple: _N3DataFactory.Triple,
      termFromId: _N3DataFactory.termFromId,
      termToId: _N3DataFactory.termToId
    };
  }
});

// src/worker.ts
var worker_exports = {};
__export(worker_exports, {
  Engine: () => Engine,
  byteOffset: () => byteOffset,
  expandSnippet: () => expandSnippet,
  snippet: () => snippet,
  utf16Offset: () => utf16Offset
});
module.exports = __toCommonJS(worker_exports);
var fs = __toESM(require("fs"));
var path = __toESM(require("path"));
var readline = __toESM(require("readline"));

// src/core/model.ts
var NS = {
  rdf: "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
  rdfs: "http://www.w3.org/2000/01/rdf-schema#",
  cims: "http://iec.ch/TC57/1999/rdf-schema-extensions-19990926#",
  owl: "http://www.w3.org/2002/07/owl#",
  dcat: "http://www.w3.org/ns/dcat#",
  xsd: "http://www.w3.org/2001/XMLSchema#",
  sh: "http://www.w3.org/ns/shacl#",
  md: "http://iec.ch/TC57/61970-552/ModelDescription/1#",
  xml: "http://www.w3.org/XML/1998/namespace"
};
function localName(uri) {
  const i = Math.max(uri.lastIndexOf("#"), uri.lastIndexOf("/"));
  return i >= 0 ? uri.slice(i + 1) : uri;
}
function namespaceOf(uri) {
  const i = uri.lastIndexOf("#");
  if (i >= 0) return uri.slice(0, i + 1);
  const j = uri.lastIndexOf("/");
  return j >= 0 ? uri.slice(0, j + 1) : "";
}
function formatMultiplicity(min, max) {
  return `${min}..${max}`;
}

// src/core/profileIndex.ts
var ProfileIndex = class {
  bundle;
  classes = /* @__PURE__ */ new Map();
  props = /* @__PURE__ */ new Map();
  byLocal = /* @__PURE__ */ new Map();
  ancestorCache = /* @__PURE__ */ new Map();
  propsCache = /* @__PURE__ */ new Map();
  constructor(bundle) {
    this.bundle = bundle;
    for (const p of bundle.profiles) {
      for (const c of Object.values(p.classes)) push(this.classes, c.uri, { def: c, profile: p });
      for (const pr of Object.values(p.properties)) push(this.props, pr.uri, { def: pr, profile: p });
    }
    for (const uri of [...this.classes.keys(), ...this.props.keys()]) {
      const l = localName(uri);
      const arr = this.byLocal.get(l) ?? [];
      if (!arr.includes(uri)) arr.push(uri);
      this.byLocal.set(l, arr);
    }
  }
  get profiles() {
    return this.bundle.profiles;
  }
  profile(keyword) {
    return this.bundle.profiles.find((p) => p.keyword === keyword);
  }
  /** Class definition, preferring the active profiles, then any profile with a comment. */
  classDef(uri, active) {
    const list = this.classes.get(uri);
    if (!list) return void 0;
    const inActive = active ? list.find((e) => active.includes(e.profile)) : void 0;
    const def = (inActive ?? list[0]).def;
    if (!def.comment) {
      const withComment = list.find((e) => e.def.comment);
      if (withComment) return { ...def, comment: withComment.def.comment };
    }
    return def;
  }
  classProfiles(uri) {
    return (this.classes.get(uri) ?? []).map((e) => e.profile);
  }
  propDef(uri, active) {
    const list = this.props.get(uri);
    if (!list) return void 0;
    return ((active && list.find((e) => active.includes(e.profile))) ?? list[0]).def;
  }
  propProfiles(uri) {
    return (this.props.get(uri) ?? []).map((e) => e.profile);
  }
  /** Other URIs (any namespace) with the same local name. */
  sameLocalName(uri) {
    return (this.byLocal.get(localName(uri)) ?? []).filter((u) => u !== uri);
  }
  /** The class itself followed by all its ancestors (nearest first). */
  ancestors(uri) {
    const cached = this.ancestorCache.get(uri);
    if (cached) return cached;
    const out = [];
    const queue = [uri];
    while (queue.length) {
      const u = queue.shift();
      if (out.includes(u)) continue;
      out.push(u);
      for (const e of this.classes.get(u) ?? []) for (const s of e.def.superClasses) queue.push(s);
    }
    this.ancestorCache.set(uri, out);
    return out;
  }
  isA(cls, target) {
    return this.ancestors(cls).includes(target);
  }
  /** Exchanged properties applicable to a class in the given profiles. */
  propertiesFor(cls, active) {
    const key = cls + "|" + active.map((p) => p.keyword).join(",");
    const cached = this.propsCache.get(key);
    if (cached) return cached;
    const result = this.computeProperties(cls, active);
    this.propsCache.set(key, result);
    return result;
  }
  computeProperties(cls, active) {
    const anc = new Set(this.ancestors(cls));
    const seen = /* @__PURE__ */ new Map();
    for (const p of active) {
      for (const pr of Object.values(p.properties)) {
        if (!pr.used || !anc.has(pr.domain)) continue;
        const prev = seen.get(pr.uri);
        if (!prev || effectiveMin(pr) > effectiveMin(prev)) seen.set(pr.uri, pr);
      }
    }
    const order = this.ancestors(cls);
    return [...seen.values()].sort(
      (a, b) => effectiveMin(b) - effectiveMin(a) || order.indexOf(b.domain) - order.indexOf(a.domain) || a.label.localeCompare(b.label)
    );
  }
  concreteClasses(active) {
    const out = /* @__PURE__ */ new Map();
    for (const p of active) for (const c of Object.values(p.classes)) if (c.concrete) out.set(c.uri, c);
    return [...out.values()].sort((a, b) => a.label.localeCompare(b.label));
  }
  /** Whether a profile marks concrete classes at all (so abstract-class checks make sense). */
  marksConcrete(p) {
    return Object.values(p.classes).some((c) => c.concrete);
  }
  enumValues(enumUri) {
    for (const e of this.classes.get(enumUri) ?? []) if (e.def.enumValues?.length) return e.def.enumValues;
    return [];
  }
  /**
   * Map header profile URIs (md:Model.profile / dcterms:conformsTo) to profiles. With exact, only
   * the URIs themselves count, not a profile of the same name in another version.
   */
  profilesForHeader(uris, exact = false) {
    const matched = [];
    const unknown = [];
    for (const raw of uris) {
      if (raw.trim().endsWith("#")) continue;
      const u = norm(raw);
      let hit = this.bundle.profiles.find((p) => p.profileURIs.some((x) => norm(x) === u));
      if (!hit && !exact) {
        const seg = nameSegment(u);
        if (seg) hit = this.bundle.profiles.find((p) => p.profileURIs.some((x) => nameSegment(norm(x)) === seg));
      }
      if (hit) {
        if (!matched.includes(hit)) matched.push(hit);
      } else unknown.push(raw);
    }
    return { matched, unknown };
  }
};
function indexForHeader(indexes, uris, cimNs) {
  if (!uris.length) return void 0;
  const sameNs = (i) => !!cimNs && i.bundle.namespaces["cim"] === cimNs;
  const versionMatch = (i) => uris.some((uri) => {
    const version = /\/(\d+(?:\.\d+)+)(?:\/|#|$)/.exec(uri)?.[1];
    return version === i.bundle.version;
  });
  const best = (exact) => {
    const hits = indexes.map((i) => ({ i, n: i.profilesForHeader(uris, exact).matched.length })).filter((h) => h.n > 0).sort((x, y) => Number(sameNs(y.i)) - Number(sameNs(x.i)) || y.n - x.n || Number(versionMatch(y.i)) - Number(versionMatch(x.i)));
    return hits[0]?.i;
  };
  return best(true) ?? best(false);
}
function effectiveMin(p) {
  return p.shacl?.minCount ?? p.min;
}
function minFor(p, subProfiles) {
  const m = effectiveMin(p);
  if (!p.subProfile || !subProfiles) return m;
  return p.subProfile.split(",").some((s) => subProfiles.has(s)) ? m : p.coreMin ?? 0;
}
function effectiveMax(p) {
  return p.shacl?.maxCount ?? p.max;
}
function push(m, k, v) {
  const a = m.get(k);
  if (a) a.push(v);
  else m.set(k, [v]);
}
function norm(u) {
  return u.trim().toLowerCase().replace(/[#/]+$/, "");
}
function nameSegment(u) {
  const parts = u.replace(/^[a-z]+:\/\//, "").split("/").filter(Boolean);
  for (let i = parts.length - 1; i > 0; i--) {
    const p = parts[i];
    if (/^[\d.]+$/.test(p)) continue;
    return p.replace(/-eu$/, "").replace(/[^a-z]/g, "");
  }
  return void 0;
}

// src/core/xml.ts
var isSpace = (c) => c === 32 || c === 10 || c === 13 || c === 9 || c === 11 || c === 12 || c === 160;
var isNameChar = (c) => c === c && !isSpace(c) && c !== 61 && c !== 47 && c !== 62 && c !== 34 && c !== 39 && c !== 60;
function decodeEntities(s) {
  if (s.indexOf("&") < 0) return s;
  return s.replace(/&(#x[0-9a-fA-F]+|#\d+|lt|gt|amp|quot|apos);/g, (m, e) => {
    switch (e) {
      case "lt":
        return "<";
      case "gt":
        return ">";
      case "amp":
        return "&";
      case "quot":
        return '"';
      case "apos":
        return "'";
    }
    if (e.startsWith("#x")) return String.fromCodePoint(parseInt(e.slice(2), 16));
    if (e.startsWith("#")) return String.fromCodePoint(parseInt(e.slice(1), 10));
    return m;
  });
}
function parseXml(text) {
  const doc = { text, roots: [], problems: [] };
  const stack = [];
  const n = text.length;
  let i = 0;
  const top = () => stack[stack.length - 1];
  while (i < n) {
    const lt = text.indexOf("<", i);
    if (lt < 0) break;
    i = lt;
    if (text.startsWith("<!--", i)) {
      const e = text.indexOf("-->", i + 4);
      i = e < 0 ? n : e + 3;
      continue;
    }
    if (text.startsWith("<![CDATA[", i)) {
      const e = text.indexOf("]]>", i + 9);
      i = e < 0 ? n : e + 3;
      continue;
    }
    if (text.startsWith("<?", i)) {
      const e = text.indexOf("?>", i + 2);
      i = e < 0 ? n : e + 2;
      continue;
    }
    if (text.startsWith("<!", i)) {
      const e = text.indexOf(">", i + 2);
      i = e < 0 ? n : e + 1;
      continue;
    }
    if (text[i + 1] === "/") {
      let j2 = i + 2;
      while (j2 < n && isNameChar(text.charCodeAt(j2))) j2++;
      const name = text.slice(i + 2, j2);
      const gt = text.indexOf(">", j2);
      const nextLt = text.indexOf("<", j2);
      const tagEnd = gt < 0 || nextLt >= 0 && nextLt < gt ? j2 : gt + 1;
      let k = stack.length - 1;
      while (k >= 0 && stack[k].name !== name) k--;
      if (k < 0) {
        doc.problems.push({ start: i, end: tagEnd, message: `Unexpected end tag </${name}>` });
      } else {
        for (let u = stack.length - 1; u > k; u--) {
          const el3 = stack[u];
          doc.problems.push({ start: el3.nameStart, end: el3.nameEnd, message: `Element <${el3.name}> is not closed` });
        }
        const el2 = stack[k];
        el2.closeStart = i;
        el2.end = tagEnd;
        stack.length = k;
      }
      i = tagEnd;
      continue;
    }
    let j = i + 1;
    while (j < n && isNameChar(text.charCodeAt(j))) j++;
    const parent = top();
    const el = {
      name: text.slice(i + 1, j),
      start: i,
      nameStart: i + 1,
      nameEnd: j,
      startTagEnd: -1,
      selfClosing: false,
      closeStart: -1,
      end: -1,
      attrs: [],
      children: [],
      parent,
      ns: parent ? parent.ns : /* @__PURE__ */ new Map()
    };
    while (j < n) {
      while (j < n && isSpace(text.charCodeAt(j))) j++;
      if (j >= n) break;
      const c = text[j];
      if (c === ">") {
        el.startTagEnd = j + 1;
        j++;
        break;
      }
      if (c === "/" && text[j + 1] === ">") {
        el.startTagEnd = j + 2;
        el.selfClosing = true;
        el.end = j + 2;
        j += 2;
        break;
      }
      if (c === "<") break;
      if (c === "/") {
        j++;
        continue;
      }
      const ns = j;
      while (j < n && isNameChar(text.charCodeAt(j))) j++;
      if (j === ns) {
        j++;
        continue;
      }
      const attr2 = { name: text.slice(ns, j), nameStart: ns, nameEnd: j, value: "", valueStart: j, valueEnd: j, raw: "" };
      let k = j;
      while (k < n && isSpace(text.charCodeAt(k))) k++;
      if (text[k] === "=") {
        k++;
        while (k < n && (text.charCodeAt(k) === 32 || text.charCodeAt(k) === 9)) k++;
        const q = text[k];
        if (q === '"' || q === "'") {
          let e = k + 1;
          while (e < n && text[e] !== q && text[e] !== "\n" && text[e] !== "<") e++;
          attr2.valueStart = k + 1;
          attr2.valueEnd = e;
          attr2.raw = text.slice(k + 1, e);
          j = text[e] === q ? e + 1 : e;
        } else {
          let e = k;
          while (e < n && !isSpace(text.charCodeAt(e)) && text.charCodeAt(e) !== 62) e++;
          attr2.valueStart = k;
          attr2.valueEnd = e;
          attr2.raw = text.slice(k, e);
          j = e;
        }
        attr2.value = decodeEntities(attr2.raw);
      }
      el.attrs.push(attr2);
    }
    if (el.startTagEnd < 0) el.end = j;
    let nsCopied = false;
    for (const a of el.attrs) {
      if (a.name === "xmlns" || a.name.startsWith("xmlns:")) {
        if (!nsCopied) {
          el.ns = new Map(el.ns);
          nsCopied = true;
        }
        el.ns.set(a.name === "xmlns" ? "" : a.name.slice(6), a.value.trim());
      }
    }
    if (parent) parent.children.push(el);
    else doc.roots.push(el);
    if (!el.selfClosing && el.startTagEnd >= 0) stack.push(el);
    i = el.startTagEnd >= 0 ? el.startTagEnd : j;
  }
  for (const el of stack) {
    doc.problems.push({ start: el.nameStart, end: el.nameEnd, message: `Element <${el.name}> is not closed` });
  }
  doc.root = doc.roots[0];
  return doc;
}
function attr(el, name) {
  return el.attrs.find((a) => a.name === name);
}
function textContent(doc, el) {
  if (el.selfClosing || el.startTagEnd < 0) return "";
  const end = el.closeStart >= 0 ? el.closeStart : el.children[0]?.start ?? el.startTagEnd;
  let s = doc.text.slice(el.startTagEnd, end);
  if (el.children.length) s = s.replace(/<[^>]*>/g, "");
  if (s.includes("<![CDATA[")) s = s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1");
  return decodeEntities(s);
}
function contentRange(el) {
  if (el.selfClosing || el.startTagEnd < 0 || el.closeStart < 0) return void 0;
  return { start: el.startTagEnd, end: el.closeStart };
}
function splitQName(name) {
  const i = name.indexOf(":");
  return i < 0 ? { prefix: "", local: name } : { prefix: name.slice(0, i), local: name.slice(i + 1) };
}
function expandName(el, name) {
  const { prefix, local } = splitQName(name);
  if (prefix === "xml") return "http://www.w3.org/XML/1998/namespace" + local;
  const ns = el.ns.get(prefix);
  return ns === void 0 ? void 0 : ns + local;
}
function elementAt(doc, offset) {
  const endOf = (el) => el.end >= 0 ? el.end : el.startTagEnd >= 0 && el.selfClosing ? el.startTagEnd : Number.MAX_SAFE_INTEGER;
  let found;
  let list = doc.roots;
  for (; ; ) {
    let lo = 0, hi = list.length - 1, at = -1;
    while (lo <= hi) {
      const mid = lo + hi >> 1;
      if (list[mid].start <= offset) {
        at = mid;
        lo = mid + 1;
      } else hi = mid - 1;
    }
    let next;
    for (let k = at; k >= 0 && k >= at - 1; k--) {
      if (offset < endOf(list[k])) {
        next = list[k];
        break;
      }
    }
    if (!next) return found;
    found = next;
    list = next.children;
  }
}

// src/core/analysis.ts
var HEADER_TYPES = /* @__PURE__ */ new Set([
  NS.md + "FullModel",
  "http://iec.ch/TC57/61970-552/DifferenceModel/1#DifferenceModel",
  NS.dcat + "Dataset"
]);
function isHeaderType(uri) {
  return !!uri && HEADER_TYPES.has(uri);
}
function refKeysFor(o, base) {
  const keys = [];
  if (o.id !== void 0) {
    keys.push("#" + o.id);
    if (base) keys.push(base.replace(/#.*$/, "") + "#" + o.id);
  }
  if (o.about !== void 0) {
    keys.push(o.about);
    if (o.about.startsWith("urn:uuid:")) keys.push("#_" + o.about.slice(9));
  }
  return keys;
}
function looksLikeCim(text) {
  const head = text.slice(0, 2e4);
  if (/<(?:rdfs:(?:Class|Datatype)|rdf:Property|owl:(?:Ontology|Class|ObjectProperty|DatatypeProperty)|sh:(?:NodeShape|PropertyShape))\b/i.test(head)) return false;
  const hasRdf = /<rdf:RDF\b|xmlns:rdf\s*=/.test(head);
  const hasCimVocabulary = /https?:\/\/(?:iec\.ch\/TC57\/(?:CIM100|2013\/CIM-schema-cim\d+|ns\/CIM\/|61970-552\/ModelDescription\/1#)|entsoe\.eu\/(?:CIM\/|ns\/(?:CIM|nc)#)|(?:ap-voc\.)?cim4\.eu\/|cim\.ucaiug\.io\/ns#)/i.test(head);
  return hasRdf && hasCimVocabulary;
}
function analyze(text, opts) {
  const doc = parseXml(text);
  const named = doc.roots.filter((r) => r.name !== "");
  const root = named.find((r) => expandName(r, r.name) === NS.rdf + "RDF") ?? named[0];
  const a = {
    doc,
    isCim: looksLikeCim(text),
    root,
    headerProfiles: [],
    dependsOn: [],
    objects: [],
    refs: /* @__PURE__ */ new Map(),
    indexes: opts.indexes,
    active: [],
    profileSource: "none",
    unknownHeaderProfiles: [],
    idStyle: "rdfID",
    subProfiles: /* @__PURE__ */ new Set(),
    propertyReferences: opts.propertyReferences,
    dataset: opts.dataset
  };
  if (!root) return a;
  const base = attr(root, "xml:base")?.value;
  for (const el of root.children) {
    if (!el.name) continue;
    const type = expandName(el, el.name);
    if (isHeaderType(type)) {
      a.header ??= el;
      for (const c of el.children) {
        const ln = localName(expandName(c, c.name) ?? c.name);
        if (ln === "Model.profile" || ln === "conformsTo" || ln === "profile") {
          const v = attr(c, "rdf:resource")?.value ?? textContent(doc, c).trim();
          if (v) a.headerProfiles.push(v);
        } else if (ln === "Model.DependentOn" || ln === "DependentOn" || ln === "requires" || ln === "references") {
          const v = attr(c, "rdf:resource")?.value.trim();
          if (v) a.dependsOn.push(v);
        }
      }
      continue;
    }
    const idAttr = attr(el, "rdf:ID");
    const aboutAttr = attr(el, "rdf:about");
    const o = { el, type, id: idAttr?.value.trim(), about: aboutAttr?.value.trim(), idAttr: idAttr ?? aboutAttr };
    for (const c of el.children) {
      const ln = localName(c.name);
      if (ln === "IdentifiedObject.name" || ln === "name") {
        o.name = textContent(doc, c).trim();
        break;
      }
    }
    a.objects.push(o);
    for (const k of refKeysFor(o, base)) {
      const list = a.refs.get(k);
      if (list) list.push(o);
      else a.refs.set(k, [o]);
    }
  }
  for (const u of a.headerProfiles) {
    if (/operation/i.test(u)) a.subProfiles.add("Operation");
    if (/shortcircuit/i.test(u)) a.subProfiles.add("ShortCircuit");
  }
  const cimNs = root.ns.get("cim");
  let index;
  if (opts.version && opts.version !== "auto") index = opts.indexes.find((i) => i.bundle.id === opts.version);
  if (!index) index = indexForHeader(opts.indexes, a.headerProfiles, cimNs);
  const byNs = cimNs ? opts.indexes.filter((i) => i.bundle.namespaces["cim"] === cimNs) : [];
  if (!index && byNs.length === 1) index = byNs[0];
  if (!index) {
    let best = 0;
    for (const i of byNs.length ? byNs : opts.indexes) {
      const hits = a.objects.filter((o) => o.type && i.classDef(o.type)).length;
      if (hits > best) {
        best = hits;
        index = i;
      }
    }
  }
  index ??= byNs[0] ?? opts.indexes[0];
  a.index = index;
  if (!index) return a;
  if (opts.profiles?.length) {
    a.active = opts.profiles.map((k) => index.profile(k)).filter((p) => !!p);
    if (a.active.length) a.profileSource = "explicit";
  }
  if (!a.active.length && a.headerProfiles.length) {
    const { matched, unknown } = index.profilesForHeader(a.headerProfiles);
    a.unknownHeaderProfiles = unknown;
    if (matched.length) {
      a.active = matched;
      a.profileSource = "header";
    }
  }
  if (!a.active.length) {
    a.active = inferProfiles(index, a);
    a.profileSource = a.active.length ? "inferred" : "none";
  }
  if (opts.idStyle && opts.idStyle !== "auto") a.idStyle = opts.idStyle;
  else {
    const withAbout = a.objects.filter((o) => o.about?.startsWith("urn:uuid:")).length;
    const withId = a.objects.filter((o) => o.id !== void 0).length;
    a.idStyle = withAbout > withId ? "urnUuid" : withId > withAbout ? "rdfID" : index.bundle.idStyle;
  }
  return a;
}
function inferProfiles(index, a) {
  const terms = /* @__PURE__ */ new Set();
  for (const o of a.objects) {
    if (o.type) terms.add(o.type);
    for (const c of o.el.children) {
      const u = expandName(c, c.name);
      if (u) terms.add(u);
    }
  }
  if (!terms.size) return [];
  let best;
  let bestScore = 0;
  for (const p of index.profiles) {
    let s = 0;
    for (const t of terms) if (p.classes[t] || p.properties[t]) s++;
    if (s > bestScore) {
      bestScore = s;
      best = p;
    }
  }
  return best && bestScore / terms.size >= 0.9 ? [best] : [];
}
var objectByElement = /* @__PURE__ */ new WeakMap();
function objectOf(a, el) {
  for (let e = el; e; e = e.parent) {
    if (e.parent === a.root) {
      let m = objectByElement.get(a);
      if (!m) {
        m = new Map(a.objects.map((o) => [o.el, o]));
        objectByElement.set(a, m);
      }
      return m.get(e);
    }
  }
  return void 0;
}
function prefixFor(a, uri) {
  if (a.root) {
    for (const [p, u] of a.root.ns) if (u === uri && p) return p;
  }
  if (a.index) {
    for (const [p, u] of Object.entries(a.index.bundle.namespaces)) if (u === uri) return p;
  }
  return void 0;
}
function qname(a, uri) {
  const i = Math.max(uri.lastIndexOf("#"), uri.lastIndexOf("/"));
  const ns = i >= 0 ? uri.slice(0, i + 1) : uri;
  const local = i >= 0 ? uri.slice(i + 1) : uri;
  const p = prefixFor(a, ns);
  return p ? `${p}:${local}` : local;
}

// src/core/docs.ts
function typeLabel(a, p) {
  if (p.kind === "association") return `\u2192 ${localName(p.range ?? "")}`;
  if (p.kind === "enum") return `enum ${localName(p.range ?? "")}`;
  const dt = p.dataType ? a.index?.classDef(p.dataType) : void 0;
  const unit = dt?.datatype?.unit && dt.datatype.unit !== "none" ? `, ${unitText(dt.datatype.multiplier, dt.datatype.unit)}` : "";
  const named = p.dataType && localName(p.dataType) !== p.primitive ? `${localName(p.dataType)} (${p.primitive}${unit})` : `${p.primitive ?? "String"}${unit}`;
  return named;
}
function unitText(mult, unit) {
  const m = mult && mult !== "none" ? mult : "";
  return m + unit;
}
function propDetail(a, p) {
  const min = minFor(p, a.subProfiles), max = effectiveMax(p);
  const sub = p.subProfile ? ` \xB7 ${p.subProfile.replace(",", "/")}` : "";
  return `${typeLabel(a, p)} \xB7 ${formatMultiplicity(min, max)}${min > 0 ? " \xB7 required" : ""}${sub}`;
}
function propMarkdown(a, p) {
  const index = a.index;
  const lines = [];
  lines.push(`**${qname(a, p.uri)}** \u2014 ${propDetail(a, p)}`);
  if (p.comment) lines.push("", escape(p.comment));
  const facts = [];
  const profiles = index.propProfiles(p.uri).map((x) => x.keyword);
  if (profiles.length) facts.push(`Profiles: ${[...new Set(profiles)].join(", ")}`);
  if (p.kind === "enum" && p.range) {
    const vals = p.shacl?.in?.length ? p.shacl.in : index.enumValues(p.range);
    if (vals.length) facts.push(`Values: ${vals.map((v) => "`" + localName(v) + "`").join(", ")}`);
  }
  if (p.kind === "association") {
    facts.push(`Value: \`rdf:resource="${a.idStyle === "urnUuid" ? "urn:uuid:\u2026" : "#_\u2026"}"\` pointing to a ${localName(p.range ?? "")}`);
    if (p.inverse) facts.push(`Inverse: ${localName(p.inverse)} (not exchanged)`);
    if (p.shacl?.targetTypes?.length) facts.push(`SHACL value types: ${[...new Set(p.shacl.targetTypes.map(localName))].sort().map((c) => "`" + c + "`").join(", ")}`);
  }
  if (p.fixed !== void 0) facts.push(`Fixed value: \`${p.fixed}\``);
  const sh = p.shacl;
  if (sh) {
    const s = [];
    if (sh.minInclusive !== void 0) s.push(`\u2265 ${sh.minInclusive}`);
    if (sh.minExclusive !== void 0) s.push(`> ${sh.minExclusive}`);
    if (sh.maxInclusive !== void 0) s.push(`\u2264 ${sh.maxInclusive}`);
    if (sh.maxExclusive !== void 0) s.push(`< ${sh.maxExclusive}`);
    if (sh.maxLength !== void 0) s.push(`max length ${sh.maxLength}`);
    if (sh.pattern) s.push(`pattern \`${sh.pattern}\``);
    if (s.length) facts.push(`SHACL: ${s.join(", ")}`);
  }
  if (facts.length) lines.push("", ...facts.map((f) => `- ${f}`));
  return lines.join("\n");
}
function classMarkdown(a, c, withProps = true) {
  const index = a.index;
  const lines = [];
  const profiles = [...new Set(index.classProfiles(c.uri).map((p) => p.keyword))];
  const flags = [c.concrete ? "concrete" : c.enumValues ? "enumeration" : c.datatype ? "datatype" : "abstract"];
  lines.push(`**${qname(a, c.uri)}** \u2014 ${flags.join(", ")} \xB7 ${index.bundle.label}${profiles.length ? ` \xB7 ${profiles.join(", ")}` : ""}`);
  if (c.comment) lines.push("", escape(c.comment));
  const anc = index.ancestors(c.uri);
  if (anc.length > 1) lines.push("", `Inherits: ${anc.slice(1).map(localName).join(" \u2192 ")}`);
  if (c.enumValues?.length) lines.push("", `Values: ${c.enumValues.map((v) => "`" + localName(v) + "`").join(", ")}`);
  if (withProps && !c.enumValues && !c.datatype) {
    const props = index.propertiesFor(c.uri, a.active.length ? a.active : index.profiles);
    if (props.length) {
      const shown = props.slice(0, 40);
      lines.push("", `| Property | Type | Mult. |`, `|---|---|---|`);
      for (const p of shown) {
        lines.push(`| ${minFor(p, a.subProfiles) > 0 ? "**" + p.label + "**" : p.label} | ${typeLabel(a, p).replace(/\|/g, "\\|")} | ${formatMultiplicity(minFor(p, a.subProfiles), effectiveMax(p))} |`);
      }
      if (props.length > shown.length) lines.push("", `\u2026and ${props.length - shown.length} more`);
    }
  }
  if (c.extraRules?.length) {
    lines.push("", "Additional SHACL rules (checked by full validators, not in the editor):");
    for (const r of c.extraRules.slice(0, 8)) lines.push(`- ${escape(r.description ?? r.message ?? r.name)}`);
  }
  return lines.join("\n");
}
function escape(s) {
  return s.replace(/\r/g, "").replace(/([\\`*_{}[\]<>])/g, "\\$1").replace(/\n/g, "  \n");
}

// src/core/propertyReference.ts
var PROPERTY_REFERENCE_NS = "http://energy.referencedata.eu/PropertyReference/";
var NAME = /^[A-Za-z_][\w-]*\.[A-Za-z_][\w-]*$/;
function parsePropertyReferenceList(text, source) {
  const names = /* @__PURE__ */ new Set();
  for (const m of text.matchAll(/hadMember\b[^>]*?(?:rdf:resource\s*=\s*["']|<)([^"'>]+)/g)) {
    const l = localName(m[1].trim());
    if (NAME.test(l)) names.add(l);
  }
  if (!names.size) for (const m of text.matchAll(/PropertyReference[/#]([A-Za-z_][\w-]*\.[A-Za-z_][\w-]*)/g)) names.add(m[1]);
  if (!names.size) {
    for (const m of text.matchAll(/(?<![\w./#-])([A-Z][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_]*)(?![\w.-])/g)) names.add(m[1]);
  }
  const sorted = [...names].sort();
  return { names: sorted, set: new Set(sorted), source };
}
function isPropertyReference(prop) {
  return !!prop.range && localName(prop.range) === "PropertyReference";
}
function propertyReferenceName(value) {
  return value.slice(Math.max(value.lastIndexOf("/"), value.lastIndexOf("#")) + 1);
}
function withPropertyName(value, name) {
  const i = Math.max(value.lastIndexOf("/"), value.lastIndexOf("#"));
  return (i >= 0 ? value.slice(0, i + 1) : PROPERTY_REFERENCE_NS) + name;
}
var knownCache = /* @__PURE__ */ new WeakMap();
function knownPropertyNames(indexes) {
  let s = knownCache.get(indexes);
  if (!s) {
    s = /* @__PURE__ */ new Set();
    for (const i of indexes) for (const p of i.profiles) for (const uri of Object.keys(p.properties)) {
      const l = localName(uri);
      if (NAME.test(l)) s.add(l);
    }
    knownCache.set(indexes, s);
  }
  return s;
}

// src/core/templates.ts
var import_crypto = require("crypto");
function snippetEscape(s) {
  return s.replace(/[\\$}]/g, (m) => "\\" + m);
}
function choiceEscape(s) {
  return s.replace(/[\\$}|,]/g, (m) => "\\" + m);
}
function nowIso() {
  return (/* @__PURE__ */ new Date()).toISOString().replace(/\.\d{3}Z$/, "Z");
}
function newUuid() {
  return (0, import_crypto.randomUUID)();
}
function idAttribute(style, uuid) {
  return style === "urnUuid" ? `rdf:about="urn:uuid:${uuid}"` : `rdf:ID="_${uuid}"`;
}
function placeholder(p, n, uuid) {
  if (p.fixed !== void 0) return snippetEscape(p.fixed);
  if (uuid && /\.mRID$/.test(p.label)) return `\${${n}:${uuid}}`;
  switch (p.primitive) {
    case "Boolean":
      return `\${${n}|true,false|}`;
    case "Float":
    case "Decimal":
      return `\${${n}:0.0}`;
    case "Integer":
      return `\${${n}:0}`;
    case "DateTime":
    case "DateTimeStamp":
      return `\${${n}:${nowIso()}}`;
    case "Date":
      return `\${${n}:${nowIso().slice(0, 10)}}`;
    case "Duration":
      return `\${${n}:PT1H}`;
    case "MonthDay":
      return `\${${n}:--01-01}`;
    case "Version":
      return `\${${n}:1.0.0}`;
  }
  return `\${${n}:${p.label.split(".").pop()}}`;
}
function propertySnippet(a, p, n = 1, uuid) {
  const q = qname(a, p.uri);
  if (p.kind === "attribute") return `${q}>${placeholder(p, n, uuid)}</${q}>`;
  if (p.kind === "enum") {
    const values = p.shacl?.in?.length ? p.shacl.in : a.index.enumValues(p.range);
    return values.length ? `${q} rdf:resource="\${${n}|${values.map(choiceEscape).join(",")}|}"/>` : `${q} rdf:resource="\${${n}}"/>`;
  }
  const targets = referenceCandidates(a, p.range);
  if (targets.length && targets.length <= 25) return `${q} rdf:resource="\${${n}|${targets.map((t) => choiceEscape(t.ref)).join(",")}|}"/>`;
  return `${q} rdf:resource="${a.idStyle === "urnUuid" ? "urn:uuid:" : "#_"}\${${n}}"/>`;
}
function referenceCandidates(a, range) {
  const out = [];
  for (const o of a.objects) {
    if (range && (!o.type || !a.index?.isA(o.type, range))) continue;
    const ref = o.id !== void 0 ? "#" + o.id : o.about;
    if (!ref) continue;
    out.push({ ref, label: o.name ?? ref, type: o.type });
  }
  return out;
}
function objectSnippet(a, c, insertRequired) {
  const uuid = newUuid();
  const q = qname(a, c.uri);
  const lines = [`${q} ${idAttribute(a.idStyle, uuid)}>`];
  let n = 1;
  if (insertRequired && a.index) {
    const props = a.index.propertiesFor(c.uri, a.active.length ? a.active : a.index.classProfiles(c.uri));
    for (const p of props.filter((p2) => minFor(p2, a.subProfiles) > 0)) lines.push(`	<${propertySnippet(a, p, n++, uuid)}`);
  }
  lines.push("	$0", `</${q}>`);
  return lines.join("\n");
}
function headerProfile(index) {
  return index.profiles.find((p) => p.classes[NS.md + "FullModel"]);
}
function datasetMetadataProfile(index) {
  return index.profiles.find((p) => p.classes[NS.dcat + "Dataset"]);
}
function headerURIs(p) {
  const entsoe = p.profileURIs.filter((u) => /entsoe\.eu\/CIM\//.test(u));
  return entsoe.length ? entsoe : p.profileURIs.slice(0, 1);
}
function headerSnippet(a, profiles, start = 1) {
  const index = a.index;
  const hp = headerProfile(index);
  const metadataProfile = !hp ? datasetMetadataProfile(index) : void 0;
  if (metadataProfile) return datasetHeaderSnippet(a, profiles, metadataProfile, start);
  const md = (l) => qname(a, NS.md + l);
  const lines = [`${md("FullModel")} rdf:about="urn:uuid:${newUuid()}">`];
  let n = start;
  const now = nowIso();
  const done = /* @__PURE__ */ new Set();
  const add = (uri, body) => {
    if (!done.has(uri)) {
      done.add(uri);
      lines.push(`	${body}`);
    }
  };
  add(NS.md + "Model.created", `<${md("Model.created")}>${now}</${md("Model.created")}>`);
  add(NS.md + "Model.scenarioTime", `<${md("Model.scenarioTime")}>\${${n++}:${now}}</${md("Model.scenarioTime")}>`);
  if (hp) {
    const header = { ...a, active: [hp] };
    for (const p of index.propertiesFor(NS.md + "FullModel", [hp])) {
      if (effectiveMin(p) === 0 || done.has(p.uri) || p.uri === NS.md + "Model.profile") continue;
      add(p.uri, `<${propertySnippet(header, p, n++)}`);
    }
  }
  add(NS.md + "Model.modelingAuthoritySet", `<${md("Model.modelingAuthoritySet")}>\${${n++}:http://www.example.eu/OperatorX}</${md("Model.modelingAuthoritySet")}>`);
  for (const p of profiles) for (const u of headerURIs(p)) lines.push(`	<${md("Model.profile")}>${snippetEscape(u)}</${md("Model.profile")}>`);
  lines.push(`</${md("FullModel")}>`);
  return lines.join("\n");
}
function datasetHeaderSnippet(a, profiles, metadataProfile, start) {
  const index = a.index;
  const uuid = newUuid();
  const datasetType = qname(a, NS.dcat + "Dataset");
  const conformsTo = qname(a, "http://purl.org/dc/terms/conformsTo");
  const lines = [`${datasetType} ${idAttribute(index.bundle.idStyle, uuid)}>`];
  const metadata = { ...a, active: [metadataProfile] };
  const identifier = "http://purl.org/dc/terms/identifier";
  let n = start;
  const profilesToDeclare = [...metadataProfile.profileURIs, ...profiles.flatMap(headerURIs)];
  for (const uri of [...new Set(profilesToDeclare)]) {
    lines.push(`	<${conformsTo}>${snippetEscape(uri)}</${conformsTo}>`);
  }
  for (const p of index.propertiesFor(NS.dcat + "Dataset", [metadataProfile])) {
    if (minFor(p, /* @__PURE__ */ new Set()) <= 0) continue;
    const q = qname(metadata, p.uri);
    if (p.uri === identifier) lines.push(`	<${q}>\${${n++}:${uuid}}</${q}>`);
    else lines.push(`	<${propertySnippet(metadata, p, n++)}`);
  }
  lines.push(`</${datasetType}>`);
  return lines.join("\n");
}
function namespacesFor(index, profiles) {
  const used = /* @__PURE__ */ new Set([NS.rdf, NS.md]);
  const hp = headerProfile(index);
  const metadataProfile = !hp ? datasetMetadataProfile(index) : void 0;
  if (metadataProfile) used.add("http://purl.org/dc/terms/");
  for (const p of [...profiles, ...hp ? [hp] : metadataProfile ? [metadataProfile] : []]) {
    for (const c of Object.values(p.classes)) if (c.concrete) used.add(namespaceOf(c.uri));
    for (const pr of Object.values(p.properties)) if (pr.used) used.add(namespaceOf(pr.uri));
  }
  const out = [];
  const preferred = ["cim", "entsoe", "nc", "eu", "md", "rdf"];
  const entries = Object.entries(index.bundle.namespaces).sort(
    (x, y) => (preferred.indexOf(x[0]) + 1 || 99) - (preferred.indexOf(y[0]) + 1 || 99)
  );
  for (const [prefix, uri] of entries) {
    if (used.has(uri) && !out.some((e) => e[1] === uri)) out.push([prefix, uri]);
  }
  return out;
}
function documentSnippet(index, profiles) {
  const ns = namespacesFor(index, profiles);
  const root = { ns: new Map(ns) };
  const a = {
    index,
    indexes: [index],
    active: profiles,
    idStyle: index.bundle.idStyle,
    objects: [],
    refs: /* @__PURE__ */ new Map(),
    root,
    doc: { text: "", roots: [], problems: [] },
    isCim: true,
    headerProfiles: [],
    profileSource: "explicit",
    unknownHeaderProfiles: [],
    subProfiles: /* @__PURE__ */ new Set()
  };
  const header = headerSnippet(a, profiles).split("\n").map((l) => "	" + l).join("\n");
  return [
    '<?xml version="1.0" encoding="UTF-8"?>',
    `<rdf:RDF ${ns.map(([p, u]) => `xmlns:${p}="${u}"`).join("\n	")}>`,
    "	<" + header.trimStart(),
    "	$0",
    "</rdf:RDF>",
    ""
  ].join("\n");
}

// src/core/complete.ts
var NAME2 = /[\w:.\-]/;
function complete(a, offset, opts) {
  const text = a.doc.text;
  const el = elementAt(a.doc, offset);
  if (el && (el.startTagEnd < 0 || offset < el.startTagEnd)) {
    const at = el.attrs.find((x) => x.valueStart <= offset && offset <= x.valueEnd && x.valueEnd > x.nameEnd);
    if (at && at.name === "rdf:resource") return resourceValues(a, el, at.valueStart, at.valueEnd);
  }
  const look = text.slice(Math.max(0, offset - 300), offset);
  const m = /<([\w:.\-]*)$/.exec(look);
  if (m) {
    const lt = offset - m[1].length - 1;
    let end = offset;
    while (end < text.length && NAME2.test(text[end])) end++;
    let container = elementAt(a.doc, lt);
    if (container && container.start === lt) container = container.parent;
    return tagNames(a, container, lt + 1, end, opts);
  }
  if (el && el.startTagEnd >= 0 && offset >= el.startTagEnd && (el.closeStart < 0 || offset <= el.closeStart)) {
    return textValues(a, el, offset);
  }
  return [];
}
function tagNames(a, container, start, end, opts) {
  const out = [];
  if (!container || !a.root || container !== a.root && !container.parent) {
    if (a.root) return out;
    for (const index2 of a.indexes) for (const p of index2.profiles) {
      if (p.classes[NS.md + "FullModel"] && !Object.values(p.classes).some((c) => c.concrete && !isHeaderType(c.uri))) continue;
      out.push({
        label: `${index2.bundle.label} ${p.keyword} document`,
        kind: "snippet",
        detail: p.title,
        documentation: `New ${index2.bundle.label} ${p.keyword} instance file with header and namespaces.`,
        insertText: documentSnippet(index2, [p]).slice(1),
        filterText: `${p.keyword} ${index2.bundle.label}`,
        replaceStart: start,
        replaceEnd: end
      });
    }
    return out;
  }
  const index = a.index;
  if (!index) return out;
  if (container === a.root) {
    if (!a.header) {
      out.push({
        label: "md:FullModel (header)",
        kind: "snippet",
        detail: `Model header for ${a.active.map((p) => p.keyword).join(", ") || index.bundle.label}`,
        insertText: headerSnippet(a, a.active),
        filterText: "FullModel header md:FullModel",
        sortText: "0",
        replaceStart: start,
        replaceEnd: end
      });
    }
    const classes = index.concreteClasses(a.active.length ? a.active : index.profiles).filter((c) => !isHeaderType(c.uri));
    for (const c of classes) {
      const q = qname(a, c.uri);
      out.push({
        label: q,
        kind: "class",
        detail: `${index.bundle.label} \xB7 ${[...new Set(index.classProfiles(c.uri).map((p) => p.keyword))].join(", ")}`,
        documentation: classMarkdown(a, c),
        insertText: objectSnippet(a, c, opts.insertRequired),
        filterText: `${q} ${c.label}`,
        sortText: "1" + c.label,
        replaceStart: start,
        replaceEnd: end
      });
    }
    return out;
  }
  const obj = container.parent === a.root ? container : void 0;
  const type = obj ? expandName(obj, obj.name) : void 0;
  if (!type) return out;
  const profiles = isHeaderType(type) ? index.profiles.filter((p) => p.classes[NS.md + "FullModel"]) : a.active.length ? a.active : index.classProfiles(type);
  const present = /* @__PURE__ */ new Map();
  for (const c of container.children) {
    const u = expandName(c, c.name);
    if (u && c.start !== start - 1) present.set(u, (present.get(u) ?? 0) + 1);
  }
  const view = { ...a, active: profiles };
  for (const p of index.propertiesFor(type, profiles)) {
    const have = present.get(p.uri) ?? 0;
    const max = effectiveMax(p);
    if (max !== "n" && have >= max) continue;
    const q = qname(a, p.uri);
    const required = minFor(p, a.subProfiles) > have;
    out.push({
      label: q,
      kind: p.kind === "attribute" ? "property" : p.kind,
      detail: propDetail(view, p),
      documentation: propMarkdown(view, p),
      insertText: propertySnippet(view, p),
      filterText: `${q} ${p.label}`,
      sortText: (required ? "0" : "1") + p.label,
      replaceStart: start,
      replaceEnd: end,
      retrigger: p.kind === "association" && referenceCandidates(view, p.range).length > 25
    });
  }
  return out;
}
function resourceValues(a, el, start, end) {
  const index = a.index;
  if (!index) return [];
  const puri = expandName(el, el.name);
  const prop = puri ? index.propDef(puri, a.active) : void 0;
  const out = [];
  if (prop?.kind === "enum") {
    const values = prop.shacl?.in?.length ? prop.shacl.in : index.enumValues(prop.range);
    const enumDef = index.classDef(prop.range);
    for (const v of values) {
      out.push({
        label: localName(v),
        kind: "enum",
        detail: v,
        documentation: enumDef?.comment,
        insertText: v.replace(/[\\$}]/g, "\\$&"),
        filterText: `${v} ${localName(v)}`,
        replaceStart: start,
        replaceEnd: end
      });
    }
    return out;
  }
  if (prop && isPropertyReference(prop)) {
    const typed = a.doc.text.slice(start, end);
    const names = a.propertyReferences?.names ?? [...knownPropertyNames(a.indexes)].sort();
    const detail = a.propertyReferences ? "PropertyReference list" : "CIM property (no PropertyReference list loaded)";
    const keep = /PropertyReference[/#]/.test(typed);
    for (const n of names) {
      const v = withPropertyName(keep ? typed : "", n);
      out.push({ label: n, kind: "value", detail, insertText: v.replace(/[\\$}]/g, "\\$&"), filterText: keep ? v : `${n} ${v}`, replaceStart: start, replaceEnd: end });
    }
    return out;
  }
  const self = objectOf(a, el);
  for (const c of referenceCandidates(a, prop?.range)) {
    if (self && (c.ref === "#" + self.id || c.ref === self.about)) continue;
    out.push({
      label: c.label === c.ref ? c.ref : `${c.label}`,
      kind: "reference",
      detail: `${c.type ? localName(c.type) : ""} ${c.ref}`.trim(),
      insertText: c.ref.replace(/[\\$}]/g, "\\$&"),
      filterText: `${c.ref} ${c.label}`,
      replaceStart: start,
      replaceEnd: end
    });
  }
  return out;
}
function textValues(a, el, offset) {
  const index = a.index;
  if (!index || !el.parent || el.parent.parent !== a.root) return [];
  const puri = expandName(el, el.name);
  if (!puri) return [];
  const text = a.doc.text;
  let start = el.startTagEnd, end = el.closeStart >= 0 ? el.closeStart : offset;
  while (start < offset && /\s/.test(text[start])) start++;
  while (end > offset && /\s/.test(text[end - 1])) end--;
  const mk = (label, detail) => ({ label, kind: "value", detail, insertText: label.replace(/[\\$}]/g, "\\$&"), replaceStart: start, replaceEnd: end });
  if (puri === NS.md + "Model.profile") {
    return index.profiles.flatMap((p) => p.profileURIs.map((u) => mk(u, `${p.keyword} \xB7 ${p.title}`)));
  }
  const prop = index.propDef(puri, a.active);
  if (!prop || prop.kind !== "attribute") return [];
  if (prop.fixed !== void 0) return [mk(prop.fixed, "fixed value")];
  switch (prop.primitive) {
    case "Boolean":
      return [mk("true"), mk("false")];
    case "DateTime":
    case "DateTimeStamp":
      return [mk(nowIso(), "now (UTC)")];
    case "Date":
      return [mk(nowIso().slice(0, 10), "today")];
  }
  if (/\.mRID$/.test(prop.label)) {
    const o = objectOf(a, el);
    const id = o?.id?.replace(/^_/, "") ?? o?.about?.replace(/^urn:uuid:/, "");
    if (id) return [mk(id, "same as the object identifier")];
  }
  return [];
}

// src/core/hover.ts
function hover(a, offset) {
  const index = a.index;
  if (!index) return void 0;
  const el = elementAt(a.doc, offset);
  if (!el) return void 0;
  const closeNameStart = el.closeStart >= 0 ? el.closeStart + 2 : -1;
  const onName = offset >= el.nameStart && offset <= el.nameEnd || closeNameStart >= 0 && offset >= closeNameStart && offset <= closeNameStart + el.name.length;
  const range = offset >= el.nameStart && offset <= el.nameEnd ? { start: el.nameStart, end: el.nameEnd } : { start: closeNameStart, end: closeNameStart + el.name.length };
  const uri = expandName(el, el.name);
  if (onName && uri) {
    if (el.parent === a.root) {
      const c = index.classDef(uri, a.active);
      if (c) return { markdown: classMarkdown(a, c), ...range };
      if (isHeaderType(uri)) return { markdown: `**${el.name}** \u2014 model header`, ...range };
      return void 0;
    }
    const p = index.propDef(uri, a.active);
    if (p) return { markdown: propMarkdown(a, p), ...range };
    return void 0;
  }
  const at = el.attrs.find((x) => offset >= x.valueStart && offset <= x.valueEnd);
  if (at?.name === "rdf:resource") {
    const v = at.value.trim();
    const r = { start: at.valueStart, end: at.valueEnd };
    const ev = index.classDef(v.replace(/\.[^.#/]*$/, ""));
    if (ev?.enumValues?.includes(v)) {
      return { markdown: `**${localName(v)}** \u2014 value of ${qname(a, ev.uri)}

${ev.comment ?? ""}`, ...r };
    }
    const target = a.refs.get(v)?.[0];
    if (target) return { markdown: objectSummary(a, target), ...r };
  }
  return void 0;
}
function objectSummary(a, o) {
  const lines = [`**${o.name ?? (o.id ?? o.about)}** \u2014 ${o.type ? qname(a, o.type) : o.el.name}`];
  const id = o.id !== void 0 ? `rdf:ID="${o.id}"` : `rdf:about="${o.about}"`;
  lines.push("", "`" + id + "`");
  return lines.join("\n");
}
function definitionAt(a, offset) {
  const el = elementAt(a.doc, offset);
  const at = el?.attrs.find((x) => x.name === "rdf:resource" && offset >= x.valueStart && offset <= x.valueEnd);
  return at ? a.refs.get(at.value.trim())?.[0] : void 0;
}
function referencesAt(a, offset) {
  let target = definitionAt(a, offset);
  if (!target) {
    const el = elementAt(a.doc, offset);
    target = objectOf(a, el);
  }
  if (!target) return [];
  const keys = /* @__PURE__ */ new Set();
  if (target.id !== void 0) keys.add("#" + target.id);
  if (target.about !== void 0) keys.add(target.about);
  const out = [];
  for (const o of a.objects) for (const c of o.el.children) {
    const r = c.attrs.find((x) => x.name === "rdf:resource");
    if (r && keys.has(r.value.trim())) out.push({ start: r.valueStart, end: r.valueEnd });
  }
  return out;
}

// src/core/rdfs.ts
function resolve(base, ref) {
  if (/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(ref)) return ref;
  const b = base.replace(/#.*$/, "");
  if (ref.startsWith("#")) return b + ref;
  if (ref === "") return b;
  const slash = b.lastIndexOf("/");
  return (slash >= 0 ? b.slice(0, slash + 1) : b) + ref;
}
function readTriples(text) {
  const doc = parseXml(text);
  const root = doc.root;
  const subjects = /* @__PURE__ */ new Map();
  const namespaces = {};
  if (!root) return { subjects, namespaces };
  for (const [p, u] of root.ns) if (p) namespaces[p] = u;
  const baseOf = (el) => {
    for (let e = el; e; e = e.parent) {
      const b = attr(e, "xml:base");
      if (b) return b.value.trim();
    }
    return "";
  };
  const add = (s, p, o) => {
    let subj = subjects.get(s);
    if (!subj) {
      subj = { uri: s, props: /* @__PURE__ */ new Map() };
      subjects.set(s, subj);
    }
    let list = subj.props.get(p);
    if (!list) {
      list = [];
      subj.props.set(p, list);
    }
    list.push(o);
  };
  for (const node of root.children) {
    const base = baseOf(node);
    const about = attr(node, "rdf:about");
    const id = attr(node, "rdf:ID");
    let s;
    if (about) s = resolve(base, about.value.trim());
    else if (id) s = resolve(base, "#" + id.value.trim());
    else continue;
    const nodeType = expandName(node, node.name);
    if (nodeType && nodeType !== NS.rdf + "Description") add(s, NS.rdf + "type", { res: nodeType });
    for (const p of node.children) {
      const pred = expandName(p, p.name);
      if (!pred) continue;
      const r = attr(p, "rdf:resource");
      if (r) add(s, pred, { res: resolve(baseOf(p), r.value.trim()) });
      else add(s, pred, textContent(doc, p).trim());
    }
  }
  return { subjects, namespaces };
}
var first = (s, p) => s?.props.get(p)?.[0];
var lit = (s, p) => {
  const v = first(s, p);
  return typeof v === "string" ? v : v?.res;
};
var res = (s, p) => {
  const v = first(s, p);
  return typeof v === "string" ? void 0 : v?.res;
};
var all = (s, p) => s?.props.get(p) ?? [];
var resAll = (s, p) => all(s, p).flatMap((o) => typeof o === "string" ? [] : [o.res]);
function stereotypes(s) {
  return all(s, NS.cims + "stereotype").map((o) => typeof o === "string" ? o : localName(o.res));
}
function parseMultiplicity(m) {
  if (!m) return { min: 0, max: 1 };
  const t = m.replace(/^.*M:/, "");
  const [a, b] = t.split("..");
  const min = parseInt(a, 10);
  if (b === void 0) return a === "n" ? { min: 0, max: "n" } : { min, max: min };
  return { min: isNaN(min) ? 0 : min, max: b === "n" || b === "*" ? "n" : parseInt(b, 10) };
}
var KNOWN_KEYWORDS = [
  [/^EquipmentBoundary/i, "EQBD"],
  [/^TopologyBoundary/i, "TPBD"],
  [/^Equipment/i, "EQ"],
  [/^Topology/i, "TP"],
  [/^SteadyStateHypothesis/i, "SSH"],
  [/^StateVariable/i, "SV"],
  [/^DiagramLayout/i, "DL"],
  [/^GeographicalLocation/i, "GL"],
  [/^Dynamics/i, "DY"],
  [/^FileHeader/i, "FH"]
];
function parseRdfs(text, file) {
  const { subjects, namespaces } = readTriples(text);
  const types = (s) => resAll(s, NS.rdf + "type");
  const classes = {};
  const properties = {};
  let ontology;
  for (const s of subjects.values()) {
    const t = types(s);
    if (t.includes(NS.owl + "Ontology")) ontology = s;
    if (t.includes(NS.rdfs + "Class")) {
      const st = stereotypes(s);
      classes[s.uri] = {
        uri: s.uri,
        label: lit(s, NS.rdfs + "label") ?? localName(s.uri),
        comment: lit(s, NS.rdfs + "comment") || void 0,
        superClasses: resAll(s, NS.rdfs + "subClassOf"),
        stereotypes: st,
        concrete: st.includes("concrete")
      };
    }
  }
  for (const s of subjects.values()) {
    for (const t of types(s)) {
      const c = classes[t];
      if (c && c.stereotypes.includes("enumeration")) (c.enumValues ??= []).push(s.uri);
    }
  }
  const rawProps = [];
  for (const s of subjects.values()) if (types(s).includes(NS.rdf + "Property")) rawProps.push(s);
  for (const c of Object.values(classes)) {
    if (c.stereotypes.includes("Primitive")) c.datatype = { primitive: c.label };
  }
  for (const s of rawProps) {
    const domain = res(s, NS.rdfs + "domain");
    const c = domain ? classes[domain] : void 0;
    if (!c || !c.stereotypes.includes("CIMDatatype")) continue;
    const name = localName(s.uri).split(".").pop();
    c.datatype ??= { primitive: "String" };
    if (name === "value") {
      const dt = res(s, NS.cims + "dataType");
      c.datatype.primitive = dt ? classes[dt]?.label ?? localName(dt) : "String";
    } else if (name === "unit") c.datatype.unit = lit(s, NS.cims + "isFixed");
    else if (name === "multiplier") c.datatype.multiplier = lit(s, NS.cims + "isFixed");
  }
  const isDatatypeClass = (u) => {
    const c = classes[u];
    return !!c && (c.stereotypes.includes("CIMDatatype") || c.stereotypes.includes("Primitive"));
  };
  for (const s of rawProps) {
    const domain = res(s, NS.rdfs + "domain");
    if (!domain) continue;
    if (isDatatypeClass(domain)) continue;
    const range = res(s, NS.rdfs + "range");
    const dataType = res(s, NS.cims + "dataType");
    const used = lit(s, NS.cims + "AssociationUsed");
    const m = parseMultiplicity(res(s, NS.cims + "multiplicity") ?? lit(s, NS.cims + "multiplicity"));
    const label = localName(s.uri);
    const p = {
      uri: s.uri,
      label,
      domain,
      comment: lit(s, NS.rdfs + "comment") || void 0,
      kind: "attribute",
      min: m.min,
      max: m.max,
      used: used === void 0 ? true : used.toLowerCase() !== "no",
      inverse: res(s, NS.cims + "inverseRoleName"),
      fixed: lit(s, NS.cims + "isFixed")
    };
    const target = dataType ?? range;
    const targetClass = target ? classes[target] : void 0;
    if (targetClass?.enumValues || targetClass?.stereotypes.includes("enumeration")) {
      p.kind = "enum";
      p.range = target;
    } else if (dataType || range && isDatatypeClass(range)) {
      p.kind = "attribute";
      p.dataType = target;
      p.primitive = targetClass?.datatype?.primitive ?? (target ? localName(target) : "String");
    } else if (range) {
      p.kind = "association";
      p.range = range;
    } else {
      p.primitive = "String";
    }
    properties[s.uri] = p;
  }
  const fileBase = file.replace(/^.*[\\/]/, "");
  let keyword = lit(ontology, NS.dcat + "keyword");
  const profileURIs = [];
  let version = lit(ontology, NS.owl + "versionInfo");
  const versionIRI = res(ontology, NS.owl + "versionIRI");
  if (versionIRI) profileURIs.push(versionIRI);
  for (const p of Object.values(properties)) {
    const c = classes[p.domain];
    if (!c || !/Version$/.test(c.label) || p.fixed === void 0) continue;
    const name = p.label.split(".").pop() ?? "";
    if (/URI/i.test(name) && /^https?:/.test(p.fixed) && !/DifferenceModel|ModelDescription/.test(p.fixed)) profileURIs.push(p.fixed);
    if (name === "shortName" && !keyword) keyword = p.fixed;
    if (name === "entsoeUML" && !version) version = p.fixed.replace(/^entsoe_v/, "");
  }
  if (!keyword) keyword = KNOWN_KEYWORDS.find(([re]) => re.test(fileBase))?.[1];
  if (!keyword) keyword = fileBase.replace(/Profile.*$/, "").replace(/[^A-Z]/g, "") || fileBase;
  for (const c of Object.values(classes)) {
    if (/Version$/.test(c.label) && Object.values(properties).some((p) => p.domain === c.uri && p.fixed !== void 0)) {
      delete classes[c.uri];
      for (const p of Object.values(properties)) if (p.domain === c.uri) delete properties[p.uri];
    }
  }
  const pkg = [...subjects.values()].find((s) => types(s).includes(NS.cims + "ClassCategory"));
  const title = lit(ontology, "http://purl.org/dc/terms/#title") ?? lit(ontology, "http://purl.org/dc/terms/title") ?? lit(pkg, NS.rdfs + "label") ?? fileBase;
  return {
    profile: { keyword, title: title || fileBase, version, versionIRI, file: fileBase, profileURIs, classes, properties },
    namespaces
  };
}

// src/core/shacl.ts
var import_n3 = __toESM(require_lib());
var RDF_FIRST = NS.rdf + "first";
var RDF_REST = NS.rdf + "rest";
var RDF_NIL = NS.rdf + "nil";
var SH = NS.sh;
function parseShacl(text, extract = { byPath: {}, notesByClass: {} }) {
  let quads;
  try {
    quads = new import_n3.Parser().parse(text);
  } catch {
    return extract;
  }
  const nodes = /* @__PURE__ */ new Map();
  const key = (t) => t.termType === "Literal" ? '"' + t.value : t.termType === "BlankNode" ? "_:" + t.value : t.value;
  for (const q of quads) {
    const s = key(q.subject);
    let node = nodes.get(s);
    if (!node) {
      node = { props: /* @__PURE__ */ new Map() };
      nodes.set(s, node);
    }
    const p = q.predicate.value;
    const list2 = node.props.get(p) ?? [];
    list2.push(key(q.object));
    node.props.set(p, list2);
  }
  const get = (s, p) => nodes.get(s)?.props.get(p) ?? [];
  const one = (s, p) => get(s, p)[0];
  const val = (v) => v === void 0 ? void 0 : v.startsWith('"') ? v.slice(1) : v;
  const num = (v) => {
    const s = val(v);
    if (s === void 0) return void 0;
    const n = Number(s);
    return isNaN(n) ? void 0 : n;
  };
  const list = (head) => {
    const out = [];
    for (let h = head, guard = 0; h && h !== RDF_NIL && guard < 1e4; h = one(h, RDF_REST), guard++) {
      const f = one(h, RDF_FIRST);
      if (f !== void 0) out.push(val(f));
    }
    return out;
  };
  const targetsOf = /* @__PURE__ */ new Map();
  for (const [s] of nodes) {
    const t = get(s, SH + "targetClass").map((v) => val(v));
    if (t.length) targetsOf.set(s, t);
  }
  const shapeTargets = (shape) => {
    const direct = targetsOf.get(shape);
    if (direct) return direct;
    const out = [];
    for (const [ns, ts] of targetsOf) if (get(ns, SH + "property").includes(shape) || get(ns, SH + "sparql").includes(shape)) out.push(...ts);
    return out;
  };
  for (const [s] of nodes) {
    const msg = val(one(s, SH + "message"));
    const sparql = get(s, SH + "sparql");
    if (sparql.length || get(s, NS.rdf + "type").includes(SH + "SPARQLConstraint")) {
      const note = {
        name: val(one(s, SH + "name")) ?? s.replace(/^.*[#/]/, ""),
        description: val(one(s, SH + "description")),
        message: msg ?? val(one(sparql[0] ?? "", SH + "message")),
        severity: val(one(s, SH + "severity"))?.replace(SH, "")
      };
      for (const c of shapeTargets(s)) {
        const arr = extract.notesByClass[c] ??= [];
        if (!arr.some((n) => n.name === note.name)) arr.push(note);
      }
      continue;
    }
    const path2 = one(s, SH + "path");
    if (path2?.startsWith("_:")) {
      const steps = list(path2);
      const inHead2 = one(s, SH + "in");
      if (steps.length === 2 && steps[1] === NS.rdf + "type" && inHead2) {
        const info2 = extract.byPath[steps[0]] ??= {};
        info2.targetTypes = list(inHead2);
        if (msg) (info2.messages ??= {}).targetTypes = msg;
      }
      continue;
    }
    if (!path2 || path2.startsWith('"')) continue;
    if (get(s, SH + "inversePath").length) continue;
    const info = extract.byPath[path2] ??= {};
    const set = (k, v, kind) => {
      if (v === void 0) return;
      info[k] = v;
      if (msg) (info.messages ??= {})[kind] = msg;
    };
    set("minCount", num(one(s, SH + "minCount")), "minCount");
    set("maxCount", num(one(s, SH + "maxCount")), "maxCount");
    set("datatype", val(one(s, SH + "datatype")), "datatype");
    set("pattern", val(one(s, SH + "pattern")), "pattern");
    set("minInclusive", num(one(s, SH + "minInclusive")), "range");
    set("maxInclusive", num(one(s, SH + "maxInclusive")), "range");
    set("minExclusive", num(one(s, SH + "minExclusive")), "range");
    set("maxExclusive", num(one(s, SH + "maxExclusive")), "range");
    set("maxLength", num(one(s, SH + "maxLength")), "maxLength");
    const inHead = one(s, SH + "in");
    if (inHead) set("in", list(inHead), "in");
    const cls = get(s, SH + "class").map((v) => val(v));
    if (cls.length) set("class", cls, "class");
    if (!Object.keys(info).length) delete extract.byPath[path2];
  }
  return extract;
}
function applyShacl(profiles, ex) {
  for (const p of profiles) {
    for (const [path2, info] of Object.entries(ex.byPath)) {
      const prop = p.properties[path2];
      if (prop) prop.shacl = { ...prop.shacl, ...info, messages: { ...prop.shacl?.messages, ...info.messages } };
    }
    for (const [cls, notes] of Object.entries(ex.notesByClass)) {
      const c = p.classes[cls];
      if (c) c.extraRules = [...c.extraRules ?? [], ...notes.filter((n) => !c.extraRules?.some((e) => e.name === n.name))];
    }
  }
}

// src/core/bundle.ts
function profileStem(file) {
  const base = file.replace(/^.*[\\/]/, "");
  const m = /^(?:\d+[-\d]*[_-])?([A-Za-z]+?)(?:Profile|-AP|_AP|_v\d|RDFS|SHACL|CustomConstraints|\.)/.exec(base);
  return (m ? m[1] : base).toLowerCase();
}
function singular(stem) {
  return stem.replace(/s$/, "");
}
function versionScore(p, version) {
  return p.version && p.version.startsWith(version) ? 1 : 0;
}
function compareVersions(a = "", b = "") {
  const pa = a.split(".").map(Number), pb = b.split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d;
  }
  return 0;
}
function conditional(file) {
  return /-Con-Complex-/i.test(file);
}
function valueRulesOnly(ex) {
  const byPath = {};
  for (const [path2, info] of Object.entries(ex.byPath)) {
    const { minCount, maxCount, messages, ...rest } = info;
    if (!Object.keys(rest).length) continue;
    const kept = messages && Object.fromEntries(Object.entries(messages).filter(([k]) => k !== "minCount" && k !== "maxCount"));
    byPath[path2] = kept && Object.keys(kept).length ? { ...rest, messages: kept } : rest;
  }
  return { byPath, notesByClass: ex.notesByClass };
}
function buildBundle(meta, rdfs, shapes = []) {
  const namespaces = {};
  const byKeyword = /* @__PURE__ */ new Map();
  const variants = /* @__PURE__ */ new Map();
  for (const f of rdfs) {
    let parsed;
    try {
      parsed = parseRdfs(f.text, f.name);
    } catch {
      continue;
    }
    const { profile, namespaces: ns } = parsed;
    if (!Object.keys(profile.classes).length) continue;
    for (const [k, v] of Object.entries(ns)) if (!(k in namespaces)) namespaces[k] = v;
    variants.set(profile.keyword, [...variants.get(profile.keyword) ?? [], profile]);
    const prev = byKeyword.get(profile.keyword);
    if (!prev) {
      byKeyword.set(profile.keyword, profile);
      continue;
    }
    const score = (p) => [versionScore(p, meta.version), Object.keys(p.properties).length];
    const [a1, a2] = score(profile), [b1, b2] = score(prev);
    if (a1 > b1 || a1 === b1 && (a2 > b2 || a2 === b2 && compareVersions(profile.version, prev.version) > 0)) {
      byKeyword.set(profile.keyword, profile);
    }
  }
  const profiles = [...byKeyword.values()];
  for (const p of profiles) tagSubProfiles(p, variants.get(p.keyword) ?? []);
  for (const s of shapes) {
    const stem = singular(profileStem(s.name));
    const stems = profiles.map((p) => singular(profileStem(p.file)));
    const targets = profiles.filter((_, i) => stems[i] === stem);
    if (!targets.length && stems.some((t) => stem.startsWith(t))) continue;
    applyShacl(targets.length ? targets : profiles, conditional(s.name) ? valueRulesOnly(parseShacl(s.text)) : parseShacl(s.text));
  }
  const isNc = Object.values(namespaces).some((u) => /entsoe\.eu\/ns\/nc#|cim4\.eu\/ns\/nc#/.test(u));
  return {
    id: meta.id,
    family: meta.family,
    version: meta.version,
    label: meta.label,
    namespaces,
    idStyle: meta.idStyle ?? (isNc ? "urnUuid" : "rdfID"),
    profiles: profiles.sort((a, b) => a.keyword.localeCompare(b.keyword)),
    source: meta.source
  };
}
function tagSubProfiles(chosen, group) {
  const kind = (p) => ({ op: /Operation/i.test(p.file), sc: /ShortCircuit/i.test(p.file) });
  const core = group.find((p) => /Core/i.test(p.file) && !kind(p).op && !kind(p).sc);
  if (!core) return;
  const op = group.find((p) => kind(p).op && !kind(p).sc);
  const sc = group.find((p) => kind(p).sc && !kind(p).op);
  const tag = (uri, inCore, inOp, inSc) => {
    if (inCore) return void 0;
    if (inOp && !inSc) return "Operation";
    if (inSc && !inOp) return "ShortCircuit";
    return op && sc && !inOp && !inSc ? "Operation,ShortCircuit" : void 0;
  };
  for (const c of Object.values(chosen.classes)) {
    c.subProfile = tag(c.uri, !!core.classes[c.uri], !!op?.classes[c.uri], !!sc?.classes[c.uri]);
  }
  for (const pr of Object.values(chosen.properties)) {
    const inCore = core.properties[pr.uri];
    if (inCore && inCore.min < pr.min) {
      pr.subProfile = op?.properties[pr.uri] && op.properties[pr.uri].min === pr.min ? "Operation" : "ShortCircuit";
      pr.coreMin = inCore.min;
      continue;
    }
    pr.subProfile = tag(pr.uri, !!inCore, !!op?.properties[pr.uri], !!sc?.properties[pr.uri]);
  }
}

// src/core/validate.ts
var DEFAULT_VALIDATE_OPTIONS = {
  unresolvedReferences: "hint",
  danglingReferences: "warning",
  requiredProperties: true,
  checkIdFormat: true,
  propertyReferences: true
};
var RULE_OF_CODE = {
  xml: "file",
  "undeclared-prefix": "file",
  "unknown-header-profile": "file",
  "duplicate-id": "file",
  "missing-id": "file",
  "id-ncname": "file",
  "id-uuid": "file",
  "unresolved-reference": "file",
  range: "shacl",
  "max-length": "shacl",
  pattern: "shacl",
  "property-reference": "reference",
  "dangling-reference": "dataset"
};
function alsoShacl(p, shaclMessage, constraint) {
  p.rule = "schema";
  p.rules = ["schema", "shacl"];
  p.message += ` [also SHACL ${constraint}${shaclMessage ? `:
${shaclMessage}` : ""}]`;
  return p;
}
var UUID = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
var UUID_INSIDE = /[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}/;
var UUID_GROUPS = [8, 4, 4, 4, 12];
function explainUuid(id, prefix) {
  const rest = id.startsWith(prefix) ? id.slice(prefix.length) : void 0;
  if (rest !== void 0 && UUID.test(rest)) return void 0;
  const shape = `${prefix}xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`;
  const expected = `Expected: ${shape} (x = 0-9 or a-f; groups of 8-4-4-4-12)`;
  const found = `Found:    ${id}`;
  const say = (what) => `${what}
${found}
${expected}`;
  const body = rest ?? id;
  const m = UUID_INSIDE.exec(body);
  if (m) {
    const before = body.slice(0, m.index);
    const after = body.slice(m.index + m[0].length);
    const parts = [
      rest === void 0 ? `the identifier does not start with "${prefix}"` : "",
      before ? `extra text "${before}" before the UUID` : "",
      after ? `extra text "${after}" after the UUID` : ""
    ].filter(Boolean);
    return say(`Identifier is not "${prefix}" + UUID: ${parts.join(", ")}.`);
  }
  if (rest === void 0) return say(`Identifier is not "${prefix}" + UUID: the identifier does not start with "${prefix}".`);
  if (/^[0-9a-fA-F]{32}$/.test(rest)) {
    const dashed = [0, 8, 12, 16, 20].map((at, i) => rest.slice(at, at + UUID_GROUPS[i])).join("-");
    return say(`Identifier is not "${prefix}" + UUID: the UUID has no dashes (expected ${prefix}${dashed}).`);
  }
  const groups = rest.split("-");
  if (groups.length === 5) {
    const bad = groups.map((g, i) => {
      const n = UUID_GROUPS[i];
      if (g.length !== n) return `group ${i + 1} "${g}" has ${g.length} characters, expected ${n}`;
      const odd = g.replace(/[0-9a-fA-F]/g, "");
      return odd ? `group ${i + 1} "${g}" has non-hexadecimal "${[...new Set(odd)].join("")}"` : "";
    }).filter(Boolean);
    if (bad.length) return say(`Identifier is not "${prefix}" + UUID: ${bad.join("; ")}.`);
  }
  return say(`Identifier is not "${prefix}" + UUID: "${rest}" is not 5 groups of 8-4-4-4-12 hexadecimal digits.`);
}
var PRIMITIVE_CHECKS = {
  Float: { re: /^[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?$|^(INF|-INF|NaN)$/, hint: "a decimal number such as 1.5 or 1e-3" },
  Decimal: { re: /^[+-]?(\d+(\.\d*)?|\.\d+)$/, hint: "a decimal number such as 10.25" },
  Integer: { re: /^[+-]?\d+$/, hint: "a whole number" },
  Boolean: { re: /^(true|false)$/, hint: '"true" or "false"' },
  Date: { re: /^\d{4}-\d{2}-\d{2}(Z|[+-]\d{2}:\d{2})?$/, hint: "a date such as 2024-01-31" },
  DateTime: {
    re: /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})?$/,
    hint: "an ISO 8601 date-time such as 2024-01-31T23:00:00Z"
  },
  DateTimeStamp: {
    re: /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})$/,
    hint: "an ISO 8601 date-time with time zone such as 2024-01-31T23:00:00Z"
  },
  Duration: { re: /^-?P(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+(\.\d+)?S)?)?$/, hint: "an ISO 8601 duration such as PT15M" },
  MonthDay: { re: /^--\d{2}-\d{2}$/, hint: "a month-day such as --12-31" },
  Time: { re: /^\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})?$/, hint: "a time such as 13:30:00" },
  URI: { re: /^\S+$/, hint: "a URI without spaces" },
  IRI: { re: /^\S+$/, hint: "an IRI without spaces" },
  StringIRI: { re: /^\S+$/, hint: "an IRI without spaces" },
  URL: { re: /^\S+$/, hint: "a URL without spaces" }
};
var XSD_TO_PRIMITIVE = {
  float: "Float",
  double: "Float",
  decimal: "Decimal",
  integer: "Integer",
  int: "Integer",
  long: "Integer",
  boolean: "Boolean",
  date: "Date",
  dateTime: "DateTime",
  dateTimeStamp: "DateTimeStamp",
  duration: "Duration",
  gMonthDay: "MonthDay",
  time: "Time",
  anyURI: "URI"
};
function primitiveCheck(primitive, value) {
  if (!primitive) return void 0;
  const c = PRIMITIVE_CHECKS[primitive];
  if (!c || c.re.test(value)) return void 0;
  return `Expected ${c.hint} (${primitive}), found "${value}".`;
}
function validate(a, opts = DEFAULT_VALIDATE_OPTIONS) {
  const out = [];
  if (!a.isCim || !a.root) return out;
  const index = a.index;
  for (const p of a.doc.problems) out.push({ ...p, severity: "error", code: "xml" });
  const checkPrefix = (el) => {
    const { prefix } = splitQName(el.name);
    if (prefix && prefix !== "xml" && !el.ns.has(prefix)) {
      out.push({
        start: el.nameStart,
        end: el.nameStart + prefix.length,
        severity: "error",
        code: "undeclared-prefix",
        message: `Namespace prefix "${prefix}" is not declared.`,
        data: { prefix }
      });
    }
    for (const c of el.children) checkPrefix(c);
  };
  checkPrefix(a.root);
  if (!index) return out;
  const active = a.active;
  const full = a.profileSource === "explicit" || a.profileSource === "header" || a.profileSource === "inferred";
  const activeNames = active.map((p) => p.keyword).join(", ") || "any profile";
  if (a.header && a.unknownHeaderProfiles.length) {
    out.push({
      start: a.header.nameStart,
      end: a.header.nameEnd,
      severity: "warning",
      code: "unknown-header-profile",
      message: `Header profile(s) not found in ${index.bundle.label}: ${a.unknownHeaderProfiles.join(", ")}`
    });
  }
  const seen = /* @__PURE__ */ new Map();
  for (const o of a.objects) {
    if (o.id === void 0) continue;
    const prev = seen.get(o.id);
    if (prev && o.idAttr) {
      out.push({
        start: o.idAttr.valueStart,
        end: o.idAttr.valueEnd,
        severity: "error",
        code: "duplicate-id",
        message: `rdf:ID "${o.id}" is already used by another object in this file.`
      });
    } else seen.set(o.id, o);
  }
  const perClass = /* @__PURE__ */ new Map();
  for (const o of a.objects) {
    const el = o.el;
    const nameRange = { start: el.nameStart, end: el.nameEnd };
    if (!o.type) continue;
    if (isHeaderType(o.type)) continue;
    if (o.id === void 0 && o.about === void 0) {
      out.push({ ...nameRange, severity: "error", code: "missing-id", message: "Object has no rdf:ID or rdf:about identifier." });
    } else if (opts.checkIdFormat && o.idAttr) {
      const v = o.idAttr.value.trim();
      const r = { start: o.idAttr.valueStart, end: o.idAttr.valueEnd };
      if (o.id !== void 0) {
        if (!/^[A-Za-z_][\w.-]*$/.test(v)) out.push({ ...r, severity: "error", code: "id-ncname", message: `rdf:ID "${v}" is not a valid XML name (it must not start with a digit; CGMES uses "_" + UUID).` });
        else {
          const why = explainUuid(v, "_");
          if (why) out.push({ ...r, severity: "hint", code: "id-uuid", message: why });
        }
      } else if (v.startsWith("urn:uuid:")) {
        const why = explainUuid(v, "urn:uuid:");
        if (why) out.push({ ...r, severity: "warning", code: "id-uuid", message: why });
      }
    }
    const cls = index.classDef(o.type, active);
    const inActive = active.length === 0 || active.some((p) => p.classes[o.type]);
    if (!cls) {
      const alt = index.sameLocalName(o.type).filter((u) => index.classDef(u));
      if (alt.length) {
        out.push({
          ...nameRange,
          severity: "error",
          code: "wrong-namespace",
          message: `${el.name} is not defined in ${index.bundle.label}. Did you mean ${alt.map((u) => qname(a, u)).join(" or ")}?`,
          data: { replacements: alt.map((u) => qname(a, u)) }
        });
      } else {
        out.push({ ...nameRange, severity: "error", code: "unknown-class", message: `Unknown class ${el.name} in ${index.bundle.label}.` });
      }
      continue;
    }
    let isAbstract = false;
    if (!inActive) {
      const where = index.classProfiles(o.type).map((p) => p.keyword).join(", ");
      out.push({
        ...nameRange,
        severity: "warning",
        code: "class-not-in-profile",
        message: `${cls.label} is not part of profile ${activeNames} (it is defined in ${where}).`
      });
    } else if (!cls.concrete && active.some((p) => p.classes[o.type] && index.marksConcrete(p)) && !cls.enumValues && !cls.datatype) {
      isAbstract = true;
      out.push({
        ...nameRange,
        severity: "warning",
        code: "abstract-class",
        message: `${cls.label} is not a concrete class in ${activeNames}; instantiate one of its subclasses instead.`
      });
    }
    if (o.about?.startsWith("#") && o.idAttr && a.dataset?.fileCount) checkDescribedObject(a, index, o, opts, out);
    let byClass = perClass.get(o.type);
    if (!byClass) {
      const list = index.propertiesFor(o.type, active.length ? active : index.profiles);
      byClass = { allowed: list, byUri: new Map(list.map((p) => [p.uri, p])), required: list.filter((p) => schemaMinFor(p, a.subProfiles) > 0 || minFor(p, a.subProfiles) > 0) };
      perClass.set(o.type, byClass);
    }
    const { allowed, byUri: allowedByUri, required } = byClass;
    const counts = /* @__PURE__ */ new Map();
    for (const c of el.children) {
      const puri = expandName(c, c.name);
      if (!puri) continue;
      const pr = { start: c.nameStart, end: c.nameEnd };
      let prop = allowedByUri.get(puri);
      if (!prop) {
        const def = index.propDef(puri, active);
        if (def && !def.used) {
          out.push({
            ...pr,
            severity: "warning",
            code: "association-not-exchanged",
            message: `${def.label} is the non-exchanged end of the association${def.inverse ? `; set ${localName(def.inverse)} on the other object instead` : ""}.`
          });
          continue;
        }
        if (def && index.isA(o.type, def.domain)) {
          if (inActive) {
            const where = index.propProfiles(puri).map((p) => p.keyword).join(", ");
            out.push({
              ...pr,
              severity: "warning",
              code: "property-not-in-profile",
              message: `${def.label} is not exchanged in profile ${activeNames} (it belongs to ${where}).`
            });
          }
          prop = def;
        } else if (def) {
          out.push({
            ...pr,
            severity: "error",
            code: "property-wrong-class",
            message: `${def.label} is not a property of ${cls.label}.`
          });
          continue;
        } else {
          const alt = index.sameLocalName(puri).filter((u) => allowedByUri.has(u));
          if (alt.length) {
            out.push({
              ...pr,
              severity: "error",
              code: "wrong-namespace",
              message: `${c.name} is not defined. Did you mean ${alt.map((u) => qname(a, u)).join(" or ")}?`,
              data: { replacements: alt.map((u) => qname(a, u)) }
            });
          } else {
            const suggestion = closest(localName(puri), allowed.map((p) => p.label));
            out.push({
              ...pr,
              severity: "error",
              code: "unknown-property",
              message: `Unknown property ${c.name} for ${cls.label}.${suggestion ? ` Did you mean ${suggestion}?` : ""}`,
              data: suggestion ? { replacements: [qname(a, allowed.find((p) => p.label === suggestion).uri)] } : void 0
            });
          }
          continue;
        }
      }
      const list = counts.get(prop.uri) ?? [];
      list.push(c);
      counts.set(prop.uri, list);
      checkValue(a, c, prop, opts, out);
    }
    for (const [uri, els] of counts) {
      const prop = allowedByUri.get(uri) ?? index.propDef(uri, active);
      const max = effectiveMax(prop);
      if (max !== "n" && els.length > max) {
        const bySchema = prop.max !== "n" && els.length > prop.max;
        const byShacl = prop.shacl?.maxCount !== void 0 && els.length > prop.shacl.maxCount;
        const maxMsg = prop.shacl?.messages?.maxCount && !/missing/i.test(prop.shacl.messages.maxCount) ? prop.shacl.messages.maxCount : void 0;
        for (const extra of els.slice(max)) {
          const p = {
            start: extra.nameStart,
            end: extra.nameEnd,
            severity: "error",
            code: "too-many",
            rule: bySchema ? "schema" : "shacl",
            message: bySchema ? `${prop.label} may appear at most ${max} time(s) (multiplicity ${formatMultiplicity(effectiveMin(prop), max)}).` : `SHACL allows ${prop.label} at most ${max} time(s) (sh:maxCount ${max}).${maxMsg ? ` [SHACL: ${maxMsg}]` : ""}`
          };
          out.push(bySchema && byShacl ? alsoShacl(p, maxMsg, `sh:maxCount ${prop.shacl.maxCount}`) : p);
        }
      }
    }
    if (opts.requiredProperties && full && inActive && !isAbstract) {
      const missing = required.filter((p) => schemaMinFor(p, a.subProfiles) > (counts.get(p.uri)?.length ?? 0));
      if (missing.length) {
        const p = {
          ...nameRange,
          severity: "warning",
          code: "missing-required",
          message: `Missing required ${missing.length === 1 ? "property" : "properties"} for ${cls.label} in ${activeNames}: ${missing.map((p2) => p2.label).join(", ")}`,
          data: { properties: missing.map((p2) => p2.uri) }
        };
        const both = missing.filter((m) => m.shacl?.minCount !== void 0 && minFor(m, a.subProfiles) > (counts.get(m.uri)?.length ?? 0));
        out.push(both.length ? alsoShacl(p, void 0, `sh:minCount for ${both.length === missing.length ? "all of them" : both.map((m) => m.label).join(", ")}`) : p);
      }
      const shaclOnly = required.filter((p) => !missing.includes(p) && minFor(p, a.subProfiles) > (counts.get(p.uri)?.length ?? 0));
      if (shaclOnly.length) {
        out.push({
          ...nameRange,
          severity: "warning",
          code: "missing-required",
          rule: "shacl",
          message: `SHACL requires ${shaclOnly.length === 1 ? "property" : "properties"} for ${cls.label}: ${shaclOnly.map((p) => p.label + (p.shacl?.messages?.minCount ? ` [SHACL: ${p.shacl.messages.minCount}]` : "")).join(", ")}`,
          data: { properties: shaclOnly.map((p) => p.uri) }
        });
      }
    }
  }
  for (const p of out) {
    p.rule ??= RULE_OF_CODE[p.code] ?? "schema";
    p.rules ??= [p.rule];
  }
  return out;
}
function schemaMinFor(p, subProfiles) {
  if (!p.subProfile) return p.min;
  return p.subProfile.split(",").some((s) => subProfiles.has(s)) ? p.min : p.coreMin ?? 0;
}
function checkValue(a, c, prop, opts, out) {
  const index = a.index;
  const res2 = attr(c, "rdf:resource");
  const text = textContent(a.doc, c).trim();
  const tag = { start: c.nameStart, end: c.nameEnd };
  const shMsg = (k) => prop.shacl?.messages?.[k] ? ` [SHACL: ${prop.shacl.messages[k]}]` : "";
  if (prop.kind === "attribute") {
    if (res2) {
      out.push({
        start: res2.nameStart,
        end: res2.valueEnd + 1,
        severity: "error",
        code: "expected-literal",
        message: `${prop.label} is an attribute (${prop.primitive ?? "literal"}); write the value as element text, not rdf:resource.`
      });
      return;
    }
    const cr = contentRange(c);
    const range = cr ? trimRange(a.doc.text, cr) : tag;
    if (!text) {
      if (c.closeStart >= 0 || c.selfClosing) out.push({ ...range, severity: "warning", code: "empty-value", message: `${prop.label} has an empty value.` });
      return;
    }
    if (prop.fixed !== void 0 && prop.fixed !== text) {
      out.push({ ...range, severity: "warning", code: "fixed-value", message: `${prop.label} has the fixed value "${prop.fixed}".` });
    }
    const primitive = prop.primitive ?? (prop.shacl?.datatype ? XSD_TO_PRIMITIVE[localName(prop.shacl.datatype)] : void 0);
    const err = primitiveCheck(primitive, text);
    if (err) {
      const bySchema2 = !!prop.primitive;
      const shPrim = prop.shacl?.datatype ? XSD_TO_PRIMITIVE[localName(prop.shacl.datatype)] : void 0;
      const p2 = { ...range, severity: "error", code: "datatype", rule: bySchema2 ? "schema" : "shacl", message: err + (bySchema2 ? "" : shMsg("datatype")) };
      out.push(bySchema2 && shPrim && primitiveCheck(shPrim, text) ? alsoShacl(p2, prop.shacl?.messages?.datatype, `sh:datatype ${qnameXsd(prop.shacl.datatype)}`) : p2);
      return;
    }
    const sh = prop.shacl;
    if (sh) {
      const n = Number(text);
      const bad = sh.minInclusive !== void 0 && n < sh.minInclusive || sh.maxInclusive !== void 0 && n > sh.maxInclusive || sh.minExclusive !== void 0 && n <= sh.minExclusive || sh.maxExclusive !== void 0 && n >= sh.maxExclusive;
      if (bad) out.push({ ...range, severity: "error", code: "range", message: `${prop.label} value ${text} is out of the allowed range.${shMsg("range")}` });
      if (sh.maxLength !== void 0 && text.length > sh.maxLength) {
        out.push({ ...range, severity: "warning", code: "max-length", message: `${prop.label} is longer than ${sh.maxLength} characters.${shMsg("maxLength")}` });
      }
      if (sh.pattern) {
        try {
          if (!new RegExp(sh.pattern).test(text)) out.push({ ...range, severity: "warning", code: "pattern", message: `${prop.label} does not match the pattern ${sh.pattern}.${shMsg("pattern")}` });
        } catch {
        }
      }
    }
    return;
  }
  if (!res2) {
    out.push({
      ...tag,
      severity: "error",
      code: "expected-resource",
      message: prop.kind === "enum" ? `${prop.label} is an enumeration; use rdf:resource="${index.enumValues(prop.range)[0] ?? "\u2026"}".` : `${prop.label} is an association; reference the target with rdf:resource="#\u2026".`
    });
    return;
  }
  const v = res2.value.trim();
  const vr = { start: res2.valueStart, end: res2.valueEnd };
  if (prop.kind === "enum") {
    const schemaValues = index.enumValues(prop.range);
    const values = prop.shacl?.in?.length ? prop.shacl.in : schemaValues;
    if (values.length && !values.includes(v)) {
      if (schemaValues.includes(v)) {
        out.push({
          ...vr,
          severity: "error",
          code: "enum-value",
          rule: "shacl",
          message: `${localName(v)} is a ${localName(prop.range)} value, but SHACL only allows ${values.map(localName).join(", ")}.${shMsg("in")}`,
          data: { replacements: values }
        });
        return;
      }
      const byLocal = values.find((x) => localName(x) === localName(v));
      const near = byLocal ? void 0 : closest(localName(v), values.map(localName));
      const suggestion = byLocal ?? values.find((x) => localName(x) === near);
      const p2 = {
        ...vr,
        severity: "error",
        code: "enum-value",
        message: `"${v}" is not a value of ${localName(prop.range)}.${byLocal ? ` Use the full URI ${byLocal}.` : ` Allowed:
${values.map(localName).join(",\n")}`}`,
        data: suggestion ? { replacements: [suggestion] } : { replacements: values }
      };
      out.push(prop.shacl?.in?.length ? alsoShacl(p2, prop.shacl.messages?.in, "sh:in") : p2);
    }
    return;
  }
  if (isPropertyReference(prop) && !v.startsWith("#") && !v.startsWith("urn:uuid:")) {
    if (opts.propertyReferences ?? true) checkPropertyReference(a, prop, v, vr, out);
    return;
  }
  const local = a.refs.get(v);
  const isLocalRef = v.startsWith("#") || v.startsWith("urn:uuid:");
  let targetTypes;
  let writtenTypes;
  let where = "";
  if (local) {
    targetTypes = writtenTypes = local.map((t2) => t2.type);
  } else {
    const hits = isLocalRef ? a.dataset?.lookup(v) : void 0;
    if (!hits) {
      if (!isLocalRef) return;
      const n = a.dataset?.fileCount ?? 0;
      const absent = n > 0 ? missingModels(a) : [];
      if (n > 0 && !absent.length) {
        const sev = opts.danglingReferences ?? "warning";
        if (sev !== "off") {
          out.push({
            ...vr,
            severity: sev,
            code: "dangling-reference",
            message: `${v} is not defined in this file nor in the ${n} other CIM file${n === 1 ? "" : "s"} of ${a.dataset.scope ?? "its folder"} (dangling reference; ${prop.label} expects a ${localName(prop.range ?? "object")}).`
          });
        }
      } else if (opts.unresolvedReferences !== "off") {
        out.push({
          ...vr,
          severity: opts.unresolvedReferences,
          code: "unresolved-reference",
          message: absent.length ? `${v} is not defined in this file nor in the ${n} other CIM file${n === 1 ? "" : "s"} of ${a.dataset.scope ?? "its folder"}; it may be in ${absent.length === 1 ? "the model" : `one of the ${absent.length} models`} this file depends on that ${absent.length === 1 ? "is" : "are"} not there (e.g. the boundary set): ${absent.join(", ")}.` : `${v} is not defined in this file (it may live in another profile instance, e.g. EQ or boundary).`
        });
      }
      return;
    }
    writtenTypes = hits.map((h) => h.type);
    targetTypes = hits.map((h) => {
      if (index.classDef(h.type)) return h.type;
      const same = index.sameLocalName(h.type).filter((u) => index.classDef(u));
      return same.length === 1 ? same[0] : h.type;
    });
    where = ` (defined in ${[...new Set(hits.map((h) => h.file.replace(/^.*[\\/]/, "")))].join(", ")})`;
  }
  const allowed = prop.shacl?.targetTypes;
  let shaclRejects = false;
  if (allowed?.length) {
    const written = writtenTypes.filter((t2) => !!t2);
    const names = new Set(allowed.map(localName));
    if (written.some((t2) => allowed.includes(t2) || names.has(localName(t2)))) return;
    shaclRejects = written.length > 0;
  }
  const expected = prop.shacl?.class?.length ? prop.shacl.class : prop.range ? [prop.range] : [];
  let judge = index;
  let known = targetTypes.filter((t2) => !!t2 && !!index.classDef(t2));
  if (!known.length && expected.length) {
    const other = a.indexes.find((i) => i !== index && i.bundle.namespaces["cim"] === index.bundle.namespaces["cim"] && targetTypes.some((t2) => t2 && i.classDef(t2)) && expected.every((r) => i.classDef(r)));
    if (other) {
      judge = other;
      known = targetTypes.filter((t2) => !!t2 && !!other.classDef(t2));
    }
  }
  if (!known.length) return;
  if (!expected.length || known.some((t2) => expected.some((r) => judge.isA(t2, r)))) return;
  const t = known[0];
  const bySchema = !prop.range || !known.some((k) => judge.isA(k, prop.range));
  const byShacl = !!prop.shacl?.class?.length;
  const p = {
    ...vr,
    severity: "error",
    code: "reference-type",
    rule: bySchema ? "schema" : "shacl",
    message: bySchema ? `${prop.label} must reference a ${localName(prop.range ?? expected[0])}, but ${v} is ${an(localName(t))}${where}.` : `SHACL requires ${prop.label} to reference a ${expected.map(localName).join(" or ")}, but ${v} is ${an(localName(t))}${where}.${shMsg("class")}`
  };
  if (bySchema && byShacl) out.push(alsoShacl(p, prop.shacl?.messages?.class, `sh:class ${prop.shacl.class.map(localName).join(" or ")}`));
  else if (bySchema && shaclRejects) out.push(alsoShacl(p, prop.shacl?.messages?.targetTypes, `sh:in ${[...new Set(allowed.map(localName))].sort().join(", ")}`));
  else out.push(p);
}
function missingModels(a) {
  const ds = a.dataset;
  return ds.missingModels ?? a.dependsOn.filter((d) => !ds.hasModel(d));
}
var an = (w) => (/^[AEIOU]/i.test(w) ? "an " : "a ") + w;
function checkDescribedObject(a, index, o, opts, out) {
  const v = o.about;
  if (a.refs.get(v)?.some((x) => x !== o && x.id !== void 0)) return;
  const r = { start: o.idAttr.valueStart, end: o.idAttr.valueEnd };
  const hits = a.dataset.lookup(v);
  const cls = localName(o.type);
  if (!hits) {
    const n = a.dataset.fileCount;
    const absent = missingModels(a);
    if (absent.length) {
      if (opts.unresolvedReferences !== "off") {
        out.push({
          ...r,
          severity: opts.unresolvedReferences,
          code: "unresolved-reference",
          message: `${v} describes ${an(cls)} that is not in this folder; it may be in a model this file depends on that is not there (e.g. the boundary set): ${absent.join(", ")}.`
        });
      }
      return;
    }
    const sev = opts.danglingReferences ?? "warning";
    if (sev !== "off") {
      out.push({
        ...r,
        severity: sev,
        code: "dangling-reference",
        message: `${v} describes ${an(cls)} that is defined neither in this file nor in the ${n} other CIM file${n === 1 ? "" : "s"} of ${a.dataset.scope ?? "its folder"} (e.g. its EQ).`
      });
    }
    return;
  }
  const known = hits.map((h) => index.classDef(h.type) ? h.type : index.sameLocalName(h.type).find((u) => index.classDef(u))).filter((t) => !!t);
  if (!known.length || known.some((t) => index.isA(t, o.type) || index.isA(o.type, t))) return;
  const files = [...new Set(hits.map((h) => h.file.replace(/^.*[\\/]/, "")))].join(", ");
  out.push({
    ...r,
    severity: "error",
    code: "reference-type",
    rule: "dataset",
    message: `${v} is described here as ${an(cls)}, but it is ${an(localName(known[0]))} in ${files}.`
  });
}
function checkPropertyReference(a, prop, v, vr, out) {
  const name = propertyReferenceName(v);
  if (!/^[A-Za-z_][\w-]*\.[A-Za-z_][\w-]*$/.test(name)) {
    out.push({
      ...vr,
      severity: "error",
      code: "property-reference",
      message: `${prop.label} must end with a property name such as Class.property (e.g. ${withPropertyName("", "Switch.open")}), found "${name}".`
    });
    return;
  }
  const list = a.propertyReferences;
  const known = list?.set ?? knownPropertyNames(a.indexes);
  if (known.has(name)) return;
  const candidates = list?.names ?? [...known];
  const sameCase = candidates.find((n) => n.toLowerCase() === name.toLowerCase());
  const near = sameCase ?? closestName(name, candidates);
  out.push({
    ...vr,
    severity: list ? "error" : "warning",
    code: "property-reference",
    message: list ? `${name} is not in the PropertyReference list (${list.source}).${near ? ` Did you mean ${near}?` : ""}` : `${name} is not a property of the loaded CIM profiles.${near ? ` Did you mean ${near}?` : ""} Set cgmes.propertyReferenceList to check against the ENTSO-E PropertyReference list.`,
    data: near ? { replacements: [withPropertyName(v, near)] } : void 0
  });
}
function qnameXsd(uri) {
  return uri.replace("http://www.w3.org/2001/XMLSchema#", "xsd:");
}
function trimRange(text, r) {
  let { start, end } = r;
  while (start < end && /\s/.test(text[start])) start++;
  while (end > start && /\s/.test(text[end - 1])) end--;
  return start === end ? r : { start, end };
}
var closestCache = /* @__PURE__ */ new Map();
function closest(word, candidates) {
  const key = word + "\0" + candidates.join("");
  if (closestCache.has(key)) return closestCache.get(key);
  if (closestCache.size > 5e3) closestCache.clear();
  const r = computeClosest(word, candidates);
  closestCache.set(key, r);
  return r;
}
function computeClosest(word, candidates) {
  const w = word.toLowerCase();
  let best;
  let bestD = Infinity;
  for (const c of candidates) {
    const cl = c.toLowerCase();
    const tail = cl.slice(cl.lastIndexOf(".") + 1);
    const d = Math.min(lev(w, cl), lev(w.slice(w.lastIndexOf(".") + 1), tail));
    if (d < bestD) {
      bestD = d;
      best = c;
    }
  }
  return best !== void 0 && bestD <= Math.max(2, Math.floor(word.length / 4)) ? best : void 0;
}
function closestName(word, candidates) {
  const w = word.toLowerCase();
  let best;
  let bestD = Infinity;
  for (const c of candidates) {
    const d = lev(w, c.toLowerCase());
    if (d < bestD) {
      bestD = d;
      best = c;
    }
  }
  return bestD <= Math.max(2, Math.floor(word.length / 5)) ? best : void 0;
}
function lev(a, b) {
  if (Math.abs(a.length - b.length) > 6) return 99;
  const dp = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    let prev = dp[0];
    dp[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const tmp = dp[j];
      dp[j] = Math.min(dp[j] + 1, dp[j - 1] + 1, prev + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = tmp;
    }
  }
  return dp[b.length];
}

// src/core/crossIndex.ts
function normalizeRef(v) {
  let s = v.trim();
  if (s.startsWith("urn:uuid:")) s = s.slice(9);
  else if (s.startsWith("#")) s = s.slice(1);
  else if (/^[a-z][\w+.-]*:/i.test(s)) return void 0;
  if (s.startsWith("_")) s = s.slice(1);
  return s ? s.toLowerCase() : void 0;
}
var HEADER_END = /<\/[A-Za-z_][\w.-]*:(?:FullModel|Dataset)\s*>/;
var HEADER_DEP = /<[A-Za-z_][\w.-]*:(?:Model\.DependentOn|DependentOn|requires|references)\b[^>]*?rdf:resource\s*=\s*["']([^"']+)["']/g;
var HEADER_PROFILE = /<[A-Za-z_][\w.-]*:(?:Model\.profile|conformsTo)\b[^>]*>([^<]+)</g;
var HEADER_TIME = /<[A-Za-z_][\w.-]*:(?:Model\.scenarioTime|startDate)\b[^>]*>([^<]+)</;
var NS_DECL = /xmlns:([A-Za-z_][\w.-]*)\s*=\s*["']([^"']*)["']/g;
var OBJECT_TAG = /<([A-Za-z_][\w.-]*):([A-Za-z_][\w.-]*)\s[^>]*?\brdf:(ID|about)\s*=\s*["']([^"']*)["']/g;
var ObjectScanner = class {
  constructor(file) {
    this.file = file;
  }
  file;
  carry = "";
  ns;
  notCim = false;
  types = [];
  typeIdx = /* @__PURE__ */ new Map();
  ids = /* @__PURE__ */ new Map();
  models = [];
  /** Text after the root start tag until the header is complete (then undefined). */
  head = "";
  header = {};
  /** False once the text turned out not to be CIM/XML (no rdf:RDF root near the start). */
  get ok() {
    return !this.notCim;
  }
  push(chunk) {
    if (this.notCim) return;
    let text = this.carry + chunk;
    let fresh = chunk;
    if (!this.ns) {
      const rootAt = text.indexOf("<rdf:RDF");
      const rootEnd = rootAt < 0 ? -1 : text.indexOf(">", rootAt);
      if (rootEnd < 0) {
        if (text.length > 2e4) {
          this.notCim = true;
          this.carry = "";
        } else this.carry = text;
        return;
      }
      if (!looksLikeCim(text.slice(rootAt, Math.min(text.length, rootAt + 2e4)))) {
        this.notCim = true;
        this.carry = "";
        return;
      }
      this.ns = /* @__PURE__ */ new Map();
      for (const m of text.slice(rootAt, rootEnd).matchAll(NS_DECL)) this.ns.set(m[1], m[2]);
      text = text.slice(rootEnd + 1);
      fresh = text;
    }
    if (this.head !== void 0) this.readHeader(fresh);
    const cut = text.lastIndexOf("<");
    if (cut < 0) {
      this.carry = "";
      return;
    }
    this.carry = text.slice(cut);
    this.scan(text.slice(0, cut));
  }
  end() {
    if (this.carry && this.ns) this.scan(this.carry + " ");
    if (this.head !== void 0 && this.ns) this.readHeader("", true);
    this.carry = "";
    return this.ns ? { file: this.file, types: this.types, ids: this.ids, models: this.models, ...this.header } : void 0;
  }
  /** Header facts, read once the header element is complete (or 64 KB in, whichever comes first). */
  readHeader(text, last = false) {
    const head = this.head + text;
    const end = HEADER_END.exec(head);
    if (!end && !last && head.length < 65536) {
      this.head = head;
      return;
    }
    const h = end ? head.slice(0, end.index) : head.slice(0, 65536);
    this.head = void 0;
    const own = (v) => Buffer.from(v, "utf8").toString("utf8");
    this.header.dependsOn = [...h.matchAll(HEADER_DEP)].map((m) => normalizeRef(m[1])).filter((v) => !!v).map(own);
    this.header.profiles = [...h.matchAll(HEADER_PROFILE)].map((m) => own(m[1].trim()));
    const t = HEADER_TIME.exec(h);
    if (t) this.header.time = own(t[1].trim());
  }
  scan(text) {
    const ns = this.ns;
    const re = new RegExp(OBJECT_TAG.source, "g");
    for (let m = re.exec(text); m; m = re.exec(text)) {
      const [, prefix, local, , value] = m;
      if (prefix === "rdf") continue;
      const type = (ns.get(prefix) ?? prefix + ":") + local;
      const ref = normalizeRef(value);
      if (!ref) continue;
      const key = Buffer.from(ref, "utf8").toString("utf8");
      if (isHeaderType(type)) {
        this.models.push(key);
        continue;
      }
      let t = this.typeIdx.get(type);
      if (t === void 0) {
        t = this.types.length;
        this.types.push(type);
        this.typeIdx.set(type, t);
      }
      if (!this.ids.has(key)) this.ids.set(key, t);
    }
  }
};
function objectsFromAnalysis(a, file) {
  const types = [];
  const typeIdx = /* @__PURE__ */ new Map();
  const ids = /* @__PURE__ */ new Map();
  for (const o of a.objects) {
    if (!o.type) continue;
    const key = normalizeRef(o.id ?? o.about ?? "");
    if (!key) continue;
    let t = typeIdx.get(o.type);
    if (t === void 0) {
      t = types.length;
      types.push(o.type);
      typeIdx.set(o.type, t);
    }
    if (!ids.has(key)) ids.set(key, t);
  }
  const header = a.header && normalizeRef((attr(a.header, "rdf:about") ?? attr(a.header, "rdf:ID"))?.value ?? "");
  return { file, types, ids, models: header ? [header] : [], dependsOn: normalizedDeps(a.dependsOn), profiles: a.headerProfiles };
}
function normalizedDeps(deps) {
  return deps.map(normalizeRef).filter((v) => !!v);
}
function dependencyClosure(deps, files) {
  const byModel = /* @__PURE__ */ new Map();
  for (const f of files) for (const m of f.models ?? []) if (!byModel.has(m)) byModel.set(m, f);
  const found = [];
  const missing = [];
  const seen = /* @__PURE__ */ new Set();
  const queue = [...deps];
  while (queue.length) {
    const m = queue.shift();
    if (seen.has(m)) continue;
    seen.add(m);
    const f = byModel.get(m);
    if (!f) {
      missing.push(m);
      continue;
    }
    if (!found.includes(f)) {
      found.push(f);
      queue.push(...f.dependsOn ?? []);
    }
  }
  return { files: found, missing };
}
function datasetLookup(files, exclude, preferred, scope, missingModels2) {
  const list = [...files].filter((f) => f.file !== exclude);
  let models;
  return {
    fileCount: list.length,
    scope,
    missingModels: missingModels2,
    hasModel(ref) {
      models ??= new Set(list.flatMap((f) => f.models ?? []));
      const key = normalizeRef(ref);
      return !!key && models.has(key);
    },
    lookup(ref) {
      const key = normalizeRef(ref);
      if (!key) return void 0;
      let hits;
      for (const f of list) {
        const t = f.ids.get(key);
        if (t !== void 0) (hits ??= []).push({ type: f.types[t], file: f.file });
      }
      if (hits && preferred?.size && hits.length > 1) {
        const mine = hits.filter((h) => preferred.has(h.file));
        if (mine.length) return mine;
      }
      return hits;
    }
  };
}

// src/worker.ts
var utf16Offset = (s, bytes) => Buffer.from(s).subarray(0, bytes).toString("utf8").length;
var byteOffset = (s, chars) => Buffer.byteLength(s.slice(0, chars));
function snippet(s) {
  let text = "";
  const fields = [];
  const re = /\\([\\$},|])|\$\{(\d+)(?::((?:\\.|[^}])*))?(?:\|((?:\\.|[^}])*?)\|)?\}|\$(\d+)/g;
  let last = 0;
  const defaults = /* @__PURE__ */ new Map();
  for (const m of s.matchAll(re)) {
    text += s.slice(last, m.index);
    last = m.index + m[0].length;
    if (m[1]) {
      text += m[1];
      continue;
    }
    const index = Number(m[2] ?? m[5]);
    const choices = m[4]?.split(/(?<!\\),/).map((x) => x.replace(/\\([\\$},|])/g, "$1"));
    const value = m[3]?.replace(/\\([\\$},|])/g, "$1") ?? choices?.[0] ?? defaults.get(index) ?? "";
    defaults.set(index, value);
    const start = Buffer.byteLength(text);
    text += value;
    fields.push({ index, start, end: Buffer.byteLength(text), ...choices ? { choices } : {} });
  }
  text += s.slice(last);
  return { text, fields };
}
var expandSnippet = (s) => snippet(s).text;
var Engine = class {
  constructor(root, config, workspace = root) {
    this.root = root;
    this.config = config;
    this.workspace = workspace;
    this.reload();
  }
  root;
  config;
  workspace;
  indexes = [];
  propertyReferences;
  settings = {};
  overrides = {};
  selected = [];
  cache = /* @__PURE__ */ new Map();
  resolve(s) {
    return path.resolve(this.settings.workspaceFolder ?? this.workspace, s.replace(/^~(?=[\\/])/, process.env.USERPROFILE ?? process.env.HOME ?? "~"));
  }
  reload() {
    this.settings = fs.existsSync(this.config) ? JSON.parse(fs.readFileSync(this.config, "utf8")) : {};
    this.overrides = this.settings.documentOverrides ?? {};
    this.selected = this.settings.datasetFiles ?? [];
    this.indexes = [];
    const walk = (dir, re) => fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => e.isSymbolicLink() ? [] : e.isDirectory() ? walk(path.join(dir, e.name), re) : re.test(e.name) ? [{ name: e.name, text: fs.readFileSync(path.join(dir, e.name), "utf8") }] : []);
    for (const f of this.settings.schemaFolders ?? []) {
      const folder = this.resolve(f.folder), version = f.version ?? (/(\d+(?:\.\d+)+)/.exec(folder)?.[1] ?? path.basename(folder)), family = f.family ?? (/ncp|nc\b/i.test(folder) ? "NCP" : "CGMES");
      const rdfs = walk(folder, /\.rdf$/i).filter((s) => !/SHACL/i.test(s.name) && !/<sh:NodeShape|sh:PropertyShape/.test(s.text.slice(0, 2e4)));
      this.indexes.push(new ProfileIndex(buildBundle({ id: f.id ?? `${family.toLowerCase()}-${version}`, version, family, label: f.label ?? f.folder }, rdfs, walk(folder, /\.ttl$/i))));
    }
    for (const f of fs.readdirSync(path.join(this.root, "profiles")).filter((f2) => f2.endsWith(".json"))) {
      const b = JSON.parse(fs.readFileSync(path.join(this.root, "profiles", f), "utf8"));
      if (!this.indexes.some((i) => i.bundle.id === b.id)) this.indexes.push(new ProfileIndex(b));
    }
    const ref = this.settings.propertyReferenceList ? this.resolve(this.settings.propertyReferenceList) : path.join(this.root, "profiles", "property-references.rdf");
    this.propertyReferences = fs.existsSync(ref) ? parsePropertyReferenceList(fs.readFileSync(ref, "utf8"), path.basename(ref)) : void 0;
    this.cache.clear();
  }
  save() {
    fs.mkdirSync(path.dirname(this.config), { recursive: true });
    fs.writeFileSync(this.config, JSON.stringify({ ...this.settings, documentOverrides: this.overrides, datasetFiles: this.selected }, null, 2));
  }
  analysis(text, file) {
    return analyze(text, { indexes: this.indexes, version: this.overrides[file]?.version ?? this.settings.version ?? "auto", profiles: this.overrides[file]?.profiles, idStyle: this.settings.idStyle ?? "auto", propertyReferences: this.propertyReferences });
  }
  async dataset(r, a) {
    if (this.settings["crossFile.enabled"] === false) return [];
    const files = new Set(this.selected.map((f) => this.resolve(f)));
    if (!this.selected.length) for (const folder of [path.dirname(r.file), ...(this.settings["crossFile.extraFolders"] ?? []).map((f) => this.resolve(f))]) {
      if (!path.isAbsolute(folder) || !fs.existsSync(folder)) continue;
      for (const f of fs.readdirSync(folder, { withFileTypes: true })) if (f.isFile() && /\.(xml|rdf|cimxml)$/i.test(f.name)) files.add(path.join(folder, f.name));
    }
    const buffers = new Map((r.buffers ?? []).map((b) => [b.file, b.text]));
    buffers.set(r.file, r.text);
    const out = [];
    let total = 0;
    for (const file of files) {
      if (buffers.has(file)) {
        const analysis = this.analysis(buffers.get(file), file);
        if (analysis.isCim) out.push(objectsFromAnalysis(analysis, file));
        continue;
      }
      try {
        const st = await fs.promises.stat(file);
        total += st.size;
        if (total > (this.settings["crossFile.maxTotalSizeMB"] ?? 1e3) * 1048576) throw new Error("Dataset exceeds crossFile.maxTotalSizeMB; select a smaller dataset.");
        const stamp = `${st.mtimeMs}:${st.size}`;
        let c = this.cache.get(file);
        if (!c || c.stamp !== stamp) {
          const scan = new ObjectScanner(file);
          for await (const chunk of fs.createReadStream(file, { encoding: "utf8", highWaterMark: 1048576 })) scan.push(chunk);
          c = { stamp, objects: scan.end() };
          this.cache.set(file, c);
        }
        if (c.objects) out.push(c.objects);
      } catch (e) {
        if (e.code !== "ENOENT") throw e;
      }
    }
    const deps = dependencyClosure(normalizedDeps(a.dependsOn), out);
    a.dataset = datasetLookup(out, r.file, new Set(deps.files.map((f) => f.file)), this.selected.length ? "the selected dataset" : "its folder", deps.missing);
    return out;
  }
  fixes(a, p) {
    const results = [];
    const edit = (start, end, text) => ({ start: byteOffset(a.doc.text, start), end: byteOffset(a.doc.text, end), ...snippet(text) });
    for (const replacement of (p.data?.replacements ?? []).slice(0, 12)) {
      const edits = [edit(p.start, p.end, replacement)];
      const el = elementAt(a.doc, p.start);
      if ((p.code === "wrong-namespace" || p.code === "unknown-property") && el && el.closeStart >= 0 && el.nameStart === p.start) edits.push(edit(el.closeStart + 2, el.closeStart + 2 + el.name.length, replacement));
      results.push({ label: `Change to ${replacement}`, edits });
    }
    if (p.code === "undeclared-prefix" && a.root && a.index) {
      const prefix = p.data?.prefix, uri = a.index.bundle.namespaces[prefix];
      if (uri) results.push({ label: `Declare ${prefix}`, edits: [edit(a.root.nameEnd, a.root.nameEnd, ` xmlns:${prefix}="${uri}"`)] });
    }
    if (p.code === "missing-required" && a.index) {
      const el = elementAt(a.doc, p.start - 1);
      if (el) {
        const props = (p.data?.properties ?? []).map((u) => a.index.propDef(u, a.active)).filter((p2) => !!p2);
        const body = props.map((p2, i) => "  <" + propertySnippet(a, p2, i + 1)).join("\n");
        if (el.selfClosing) results.push({ label: "Insert required properties", edits: [edit(el.startTagEnd - 2, el.startTagEnd, `>
${body}
</${el.name}>`)] });
        else if (el.closeStart >= 0) results.push({ label: "Insert required properties", edits: [edit(el.closeStart, el.closeStart, `
${body}
`)] });
      }
    }
    return results;
  }
  async handle(r) {
    if (r.command === "reload") this.reload();
    if (r.command === "setProfile") {
      this.overrides[r.file] = r.argument;
      this.save();
    }
    if (r.command === "dataset") {
      this.selected = r.argument ?? [];
      this.save();
    }
    if (r.command === "datasetFolder") {
      const folder = this.resolve(r.argument);
      this.selected = fs.readdirSync(folder, { withFileTypes: true }).filter((f) => f.isFile() && /\.(xml|rdf|cimxml)$/i.test(f.name)).map((f) => path.join(folder, f.name));
      this.save();
    }
    if (r.command === "openDatasetSelection") {
      const buffers = new Map((r.buffers ?? []).map((b) => [b.file, b.text]));
      buffers.set(r.file, r.text);
      const selected = new Set(this.selected.map((f) => path.resolve(this.resolve(f)).toLowerCase()));
      const items2 = [...buffers].flatMap(([file, text]) => {
        if (!path.isAbsolute(file) || !/\.(xml|rdf|cimxml)$/i.test(file) || !this.analysis(text, file).isCim) return [];
        const label = `${path.basename(file)} (${path.dirname(file)})${/\.xml$/i.test(file) ? "" : " \u2014 reference only"}`;
        return [{ file, label, checked: this.selected.length ? selected.has(path.resolve(file).toLowerCase()) : true }];
      });
      return { kind: "datasetSelection", items: items2 };
    }
    if (r.command === "profiles" || r.command === "versions" || r.command === "new") return { kind: "choices", items: [...r.command === "new" ? [] : [{ label: "Automatic", command: "setProfile", argument: {} }], ...this.indexes.flatMap((i) => r.command === "versions" ? [{ label: i.bundle.label, command: "setProfile", argument: { version: i.bundle.id } }] : i.profiles.map((p) => ({ label: `${i.bundle.label} / ${p.keyword}`, command: r.command === "new" ? "newText" : "setProfile", argument: r.command === "new" ? snippet(documentSnippet(i, [p])) : { version: i.bundle.id, profiles: [p.keyword] } })))] };
    const a = this.analysis(r.text, r.file), offset = utf16Offset(r.text, r.position);
    const range = (start, end) => ({ start: byteOffset(r.text, start), end: byteOffset(r.text, end) });
    if (r.command === "findDefinitionById" || r.command === "findReferencesById") {
      const requested = String(r.argument ?? "").trim(), key = normalizeRef(requested);
      if (!key) return { kind: "searchResults", status: "Enter a CIM mRID such as _123, #_123 or urn:uuid:123.", items: [] };
      const indexed2 = await this.dataset(r, a), buffers = new Map((r.buffers ?? []).map((b) => [b.file, b.text]));
      buffers.set(r.file, r.text);
      const items2 = [];
      for (const file of indexed2) {
        if (r.command === "findDefinitionById" && !file.ids.has(key)) continue;
        const text = buffers.get(file.file) ?? await fs.promises.readFile(file.file, "utf8"), source = this.analysis(text, file.file);
        if (!source.isCim) continue;
        const lineStarts = [0];
        for (let i = 0; i < text.length; i++) if (text.charCodeAt(i) === 10) lineStarts.push(i + 1);
        const lineAt = (position) => {
          let low = 0, high = lineStarts.length;
          while (low + 1 < high) {
            const middle = low + high >>> 1;
            if (lineStarts[middle] <= position) low = middle;
            else high = middle;
          }
          return low + 1;
        };
        if (r.command === "findDefinitionById") {
          for (const object of source.objects) if (normalizeRef(object.id ?? object.about ?? "") === key) {
            const start = object.el.nameStart, end = object.el.nameEnd, line = lineAt(start);
            items2.push({ label: `${path.basename(file.file)}:${line} \u2014 ${object.el.name} \u2014 ${requested}`, detail: file.file, file: file.file, start: byteOffset(text, start), end: byteOffset(text, end) });
          }
        } else {
          const visit = (element, owner) => {
            for (const attribute of element.attrs) if (attribute.name === "rdf:resource" && normalizeRef(attribute.value) === key) {
              const start = attribute.valueStart, end = attribute.valueEnd, line = lineAt(start);
              items2.push({ label: `${path.basename(file.file)}:${line} \u2014 ${owner}.${element.name} \u2192 ${requested}`, detail: file.file, file: file.file, start: byteOffset(text, start), end: byteOffset(text, end) });
            }
            for (const child of element.children) visit(child, owner);
          };
          if (source.doc.root) for (const child of source.doc.root.children) visit(child, child.name);
        }
      }
      const subject = r.command === "findDefinitionById" ? "definitions" : "references";
      return { kind: "searchResults", status: `${items2.length} ${subject} for ${requested} in ${indexed2.length} dataset files.`, items: items2 };
    }
    const trimmed = r.text.trim(), unfinishedTag = /<[^>]*$/.test(trimmed);
    if (!a.isCim && r.command !== "datasetMembers" && (a.root || trimmed.length > 0 && !unfinishedTag)) {
      if (r.command === "complete") return { kind: "completion", items: [] };
      if (r.command === "hover") return { kind: "hover", text: "" };
      if (["outline", "definition", "references"].includes(r.command)) return { kind: "locations", items: [] };
      if (r.command === "fix") return { kind: "fixes", items: [] };
      return { kind: "issues", status: "Not a supported CIM file", items: [] };
    }
    if (r.command === "complete") return { kind: "completion", items: complete(a, offset, { insertRequired: this.settings["completion.insertRequiredProperties"] !== false }).sort((x, y) => (x.sortText ?? x.label).localeCompare(y.sortText ?? y.label)).map((c) => ({ label: c.label, detail: c.documentation ?? c.detail ?? "", edits: [{ ...range(c.replaceStart, c.replaceEnd), ...snippet(c.insertText) }] })) };
    if (r.command === "hover") return { kind: "hover", text: hover(a, offset)?.markdown ?? "" };
    if (r.command === "outline") return { kind: "locations", items: a.objects.map((o) => ({ label: `${o.el.name}  ${o.name ?? o.id ?? o.about ?? ""}`, file: r.file, ...range(o.el.start, o.el.end) })).sort((x, y) => x.label.localeCompare(y.label)) };
    if (r.command === "definition") {
      const o = definitionAt(a, offset);
      return { kind: "locations", items: o ? [{ label: o.name ?? o.id ?? o.about, file: r.file, ...range(o.el.start, o.el.end) }] : [] };
    }
    if (r.command === "references") return { kind: "locations", items: referencesAt(a, offset).map((p) => ({ label: `Line ${r.text.slice(0, p.start).split("\n").length}`, file: r.file, ...range(p.start, p.end) })) };
    if (r.command === "datasetMembers") {
      const indexed2 = await this.dataset(r, a);
      return { kind: "locations", items: indexed2.map((f) => ({ label: `${path.basename(f.file)} \u2014 ${(f.profiles ?? []).join(", ")} \u2014 ${f.ids.size} objects`, detail: f.file, file: f.file, start: 0, end: 0 })) };
    }
    if (a.isCim && !/\.xml$/i.test(r.file)) {
      if (r.command === "fix") return { kind: "fixes", items: [] };
      return { kind: "issues", status: "CIM validation requires a .xml file", items: [] };
    }
    const indexed = await this.dataset(r, a);
    const opts = { ...DEFAULT_VALIDATE_OPTIONS, requiredProperties: this.settings["validation.requiredProperties"] !== false, checkIdFormat: this.settings["validation.identifierFormat"] !== false, propertyReferences: this.settings["validation.propertyReferences"] !== false, unresolvedReferences: this.settings["validation.unresolvedReferences"] ?? "hint", danglingReferences: this.settings["validation.danglingReferences"] ?? "warning" };
    const problems = this.settings["validation.enabled"] === false ? [] : validate(a, opts);
    if (r.command === "fix") return { kind: "fixes", items: problems.filter((p) => p.start <= offset && p.end >= offset).flatMap((p) => this.fixes(a, p)) };
    const items = [];
    const add = (text, file, ps) => {
      const positions = /* @__PURE__ */ new Map();
      let at = 0, bytes = 0, line = 1;
      for (const offset2 of [...new Set(ps.flatMap((p) => [p.start, p.end]))].sort((a2, b) => a2 - b)) {
        const part = text.slice(at, offset2);
        bytes += Buffer.byteLength(part);
        for (let j = 0; j < part.length; j++) if (part.charCodeAt(j) === 10) line++;
        positions.set(offset2, { byte: bytes, line });
        at = offset2;
      }
      for (const p of ps) for (const rule of p.rules ?? [p.rule ?? "schema"]) items.push({ label: `[${rule}] ${p.severity} / ${p.code} / ${path.basename(file)}:${positions.get(p.start).line} \u2014 ${p.message.replace(/\n/g, " ")}`, detail: p.message, file, start: positions.get(p.start).byte, end: positions.get(p.end).byte, severity: p.severity, rule, code: p.code });
    };
    add(r.text, r.file, problems);
    if (r.command === "validateDataset") {
      for (const f of indexed) if (f.file !== r.file && /\.xml$/i.test(f.file) && fs.existsSync(f.file) && fs.statSync(f.file).size <= (this.settings["crossFile.maxValidateSizeMB"] ?? 60) * 1048576) {
        const text = r.buffers?.find((b) => b.file === f.file)?.text ?? fs.readFileSync(f.file, "utf8"), other = this.analysis(text, f.file);
        const closure = dependencyClosure(normalizedDeps(other.dependsOn), indexed);
        other.dataset = datasetLookup(indexed, f.file, new Set(closure.files.map((x) => x.file)), "the selected dataset", closure.missing);
        add(text, f.file, validate(other, opts));
      }
    }
    return { kind: "issues", status: `${a.index?.bundle.label ?? "CIM"} / ${a.active.map((p) => p.keyword).join(", ") || "automatic"} / ${problems.length} issues / ${indexed.length} dataset files`, items };
  }
};
if (require.main === module) {
  let engine;
  const config = process.argv[2] || path.join(process.env.APPDATA ?? __dirname, "CGMESNotepad", "settings.json");
  let queue = Promise.resolve();
  readline.createInterface({ input: process.stdin, crlfDelay: Infinity }).on("line", (line) => {
    queue = queue.then(async () => {
      let r = {};
      try {
        r = JSON.parse(line);
        engine ??= new Engine(__dirname, config, path.isAbsolute(r.file) ? path.dirname(r.file) : process.cwd());
        const result = await engine.handle(r);
        process.stdout.write(JSON.stringify({ id: r.id, revision: r.revision, file: r.file, ...result }) + "\n");
      } catch (e) {
        process.stdout.write(JSON.stringify({ id: r.id, revision: r.revision, file: r.file, kind: "error", text: e.message }) + "\n");
      }
    });
  });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  Engine,
  byteOffset,
  expandSnippet,
  snippet,
  utf16Offset
});
/*! Bundled license information:

safe-buffer/index.js:
  (*! safe-buffer. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> *)
*/
